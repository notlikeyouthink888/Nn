/* منصة الهندسة المدنية — واجهة المستخدم */
const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => [...r.querySelectorAll(s)];
const nf = (x, n = 2) => (x === null || x === undefined || isNaN(x)) ? '—' :
  Number(x).toLocaleString('en-US', { minimumFractionDigits: n, maximumFractionDigits: n });
const int = x => nf(x, 0);
const val = id => parseFloat($('#' + id).value) || 0;
const txt = id => $('#' + id).value;
const chk = id => $('#' + id).checked;

async function post(ep, data) {
  $('#stat').textContent = 'جارٍ الحساب…';
  try {
    const r = await fetch('/api/' + ep, { method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data) });
    const j = await r.json();
    if (!r.ok) throw new Error(j.error || 'خطأ');
    $('#stat').textContent = 'تم الحساب ✓';
    return j;
  } catch (e) { $('#stat').textContent = '✗ ' + e.message; alert('خطأ: ' + e.message); throw e; }
}

/* ---------- form helpers ---------- */
const F = (l, id, v, step = 'any', unit = '') =>
  `<div><label>${l}${unit ? ` <span style="color:#64748b">(${unit})</span>` : ''}</label>
   <input id="${id}" type="number" step="${step}" value="${v}"></div>`;
const S = (l, id, opts, v) =>
  `<div><label>${l}</label><select id="${id}">${opts.map(o => {
    const [k, t] = Array.isArray(o) ? o : [o, o];
    return `<option value="${k}"${k == v ? ' selected' : ''}>${t}</option>`; }).join('')}</select></div>`;
const C = (l, id, v) => `<div style="align-self:end"><label>&nbsp;</label>
   <label style="color:var(--tx);font-size:13px"><input type="checkbox" id="${id}" ${v ? 'checked' : ''}
   style="width:auto;margin-left:6px">${l}</label></div>`;
// أصناف التعرّض الأربعة بجدول ACI 318-19 رقم 19.3.1.1 — فئة لكل قائمة.
const EXP_CATS = [['F', 'التجمّد والذوبان'], ['S', 'الكبريتات بالتربة والماء'],
                  ['W', 'ملامسة الماء'], ['C', 'حماية حديد التسليح']];
const expSelects = () => EXP_CATS.map(([p, nm], i) => {
  const rows = (META.exposure_classes || []).filter(c => c.code[0] === p);
  const def = (META.exposure_default || [])[i] || (rows[0] || {}).code;
  return S(nm + ' (' + p + ')', 'w_exp' + p,
    rows.map(c => [c.code, c.code + ' — ' + c.desc +
      (c.fc ? ' · f\'c ≥ ' + c.fc : '') + (c.wcm ? ' · w/cm ≤ ' + c.wcm : '')]), def);
}).join('');
const expPick = () => EXP_CATS.map(([p]) => txt('w_exp' + p)).filter(Boolean);
// معرّف HTML آمن لجهة البروز ('x+' → 'xp') — الرمزان + و− لا يصلحان بمحدّد CSS
const csid = k => k.replace('+', 'p').replace('-', 'm');
const kpi = (l, v, cls = '') => `<div class="kpi ${cls}"><div class="v">${v}</div><div class="l">${l}</div></div>`;
const tag = ok => ok ? '<span class="tag t-ok">مقبول ✓</span>' : '<span class="tag t-bad">غير مقبول ✗</span>';
const rcol = r => r <= 0.7 ? '#34d399' : r <= 0.9 ? '#a3e635' : r <= 1.0 ? '#fbbf24' : '#f87171';
/* الوسيط الثالث (اختياري): نمط CSS لكل صف — يُستعمل لتمييز الصف المنطبق على
   المشروع بجداول القرار، فيراه المهندس بلمحة بدل أن يقرأ العمود الأخير. */
const table = (heads, rows, styles) => `<div style="overflow-x:auto"><table><thead><tr>${
  heads.map(x => `<th>${x}</th>`).join('')}</tr></thead><tbody>${
  rows.map((r, i) => `<tr${styles && styles[i] ? ` style="${styles[i]}"` : ''}>${
    r.map(c => `<td>${c}</td>`).join('')}</tr>`).join('')}</tbody></table></div>`;

/* ---------- SVG plot ---------- */
function plot(o) {
  const W = 860, H = o.h || 210, ml = 52, mr = 14, mt = 22, mb = 26;
  const xs = o.x, all = o.series.flatMap(s => s.y);
  let y0 = Math.min(0, ...all), y1 = Math.max(0, ...all);
  if (y1 - y0 < 1e-9) { y1 = 1; y0 = -1; }
  const pad = (y1 - y0) * .12; y0 -= pad; y1 += pad;
  const x0 = Math.min(...xs), x1 = Math.max(...xs);
  const X = v => ml + (v - x0) / (x1 - x0 || 1) * (W - ml - mr);
  const Y = v => o.invert ? mt + (v - y0) / (y1 - y0) * (H - mt - mb)
                          : H - mb - (v - y0) / (y1 - y0) * (H - mt - mb);
  let g = '';
  for (let i = 0; i <= 4; i++) {
    const v = y0 + (y1 - y0) * i / 4;
    g += `<line x1="${ml}" x2="${W - mr}" y1="${Y(v)}" y2="${Y(v)}" stroke="#22304f" stroke-width="1"/>
      <text x="${ml - 6}" y="${Y(v) + 4}" fill="#93a4c0" font-size="10" text-anchor="end">${nf(v, 1)}</text>`;
  }
  g += `<line x1="${ml}" x2="${W - mr}" y1="${Y(0)}" y2="${Y(0)}" stroke="#64748b" stroke-width="1.4"/>`;
  for (let i = 0; i <= 6; i++) {
    const v = x0 + (x1 - x0) * i / 6;
    g += `<text x="${X(v)}" y="${H - 8}" fill="#93a4c0" font-size="10" text-anchor="middle">${nf(v, 1)}</text>`;
  }
  o.series.forEach(s => {
    const pts = xs.map((x, i) => `${X(x)},${Y(s.y[i])}`).join(' ');
    if (s.fill) g += `<polygon points="${X(x0)},${Y(0)} ${pts} ${X(x1)},${Y(0)}" fill="${s.color}22"/>`;
    g += `<polyline points="${pts}" fill="none" stroke="${s.color}" stroke-width="2"/>`;
  });
  const mx = o.series[0], im = mx.y.indexOf(Math.max(...mx.y)), in_ = mx.y.indexOf(Math.min(...mx.y));
  [im, in_].forEach(i => { if (Math.abs(mx.y[i]) > 1e-6)
    g += `<circle cx="${X(xs[i])}" cy="${Y(mx.y[i])}" r="3" fill="#fff"/>
      <text x="${X(xs[i])}" y="${Y(mx.y[i]) + (o.invert ? 14 : -7)}" fill="#fff" font-size="10"
      text-anchor="middle">${nf(mx.y[i], 1)}</text>`; });
  return `<svg viewBox="0 0 ${W} ${H}"><text x="${W - mr}" y="14" fill="#e6edf7" font-size="11.5"
    text-anchor="end">${o.title}</text>${g}</svg>`;
}

/* ---------- section drawing ---------- */
function sectionSVG(b, h, opt) {
  const S = 185 / Math.max(b, h), W = 330, HH = 240;
  const bw = b * S, hh = h * S, ox = (W - bw) / 2 - 30, oy = 22;
  const cov = 40 * S;
  let g = `<rect x="${ox}" y="${oy}" width="${bw}" height="${hh}" fill="#1e3a5f" stroke="#7dd3fc" stroke-width="1.6"/>
   <rect x="${ox + cov}" y="${oy + cov}" width="${bw - 2 * cov}" height="${hh - 2 * cov}" fill="none"
   stroke="#fbbf24" stroke-width="1.6" rx="6"/>`;
  const bar = (x, y, d) => `<circle cx="${x}" cy="${y}" r="${Math.max(2.6, d * S / 2)}" fill="#f87171" stroke="#fff" stroke-width=".6"/>`;
  (opt.rows || []).forEach(r => {
    const n = r.n, d = r.db, y = oy + (r.top ? cov + 6 : hh - cov - 6);
    for (let i = 0; i < n; i++) {
      const x = ox + cov + 8 + (bw - 2 * cov - 16) * (n === 1 ? .5 : i / (n - 1));
      g += bar(x, y, d);
    }
    g += `<text x="${ox + bw + 8}" y="${y + 4}" fill="#fca5a5" font-size="11">${n}Ø${d}</text>`;
  });
  (opt.layers || []).forEach(l => {
    const y = oy + l[0] * S, n = l[2] || 2, d = opt.db || 20;
    for (let i = 0; i < n; i++) {
      const x = ox + cov + 8 + (bw - 2 * cov - 16) * (n === 1 ? .5 : i / (n - 1));
      g += bar(x, y, d);
    }
  });
  g += `<text x="${ox + bw / 2}" y="${oy + hh + 16}" fill="#93a4c0" font-size="11" text-anchor="middle">b = ${b} مم</text>
   <text x="${ox - 10}" y="${oy + hh / 2}" fill="#93a4c0" font-size="11" text-anchor="end">h = ${h}</text>`;
  if (opt.stirrups) g += `<text x="${W - 8}" y="14" fill="#fbbf24" font-size="11" text-anchor="end">أساور ${opt.stirrups}</text>`;
  return `<svg viewBox="0 0 ${W} ${HH}" style="max-width:340px">${g}</svg>`;
}

/* ================================ PAGES ================================== */
let META = { live: [], dens: [], cities: [], systems: [] };
const PAGES = {};

PAGES.home = {
  ic: '🏠', name: 'الرئيسية', ttl: 'منصة التحليل والتصميم الإنشائي',
  sub: 'حسابات مطابقة لـ ACI 318-19 والكود العراقي للأحمال والقوى — تحليل مصفوفي كامل',
  html: () => `<div class="hero"><h2>مكتب هندسي رقمي متكامل 🏗️</h2>
    <p>تحليل إنشائي بطريقة الصلابة المباشرة (Direct Stiffness) للجسور والإطارات، وتصميم خرساني مسلح
    وفق <b>ACI 318-19</b>، وأحمال حية وزلزالية ورياح وفق <b>الكود العراقي للأحمال والقوى</b>،
    مع فحص شعاعي (X-Ray) لكامل الهيكل يُظهر نسبة الإجهاد في كل عنصر.</p></div>
  <div class="grid g3" style="margin-top:16px">${Object.entries(PAGES).filter(([k]) => k !== 'home')
    .map(([k, p]) => `<div class="feat" onclick="go('${k}')"><div class="ic">${p.ic}</div>
      <div><b>${p.name}</b><span>${p.desc || p.sub}</span></div></div>`).join('')}</div>
  <div class="grid g4" style="margin-top:16px">
    ${kpi('طريقة التحليل', 'Stiffness')}${kpi('كود التصميم', 'ACI 318-19')}
    ${kpi('كود الأحمال', 'العراقي')}${kpi('الوحدات', 'SI · kN·m')}</div>`,
  init: () => {}
};

/* ------------------------------- الأحمال -------------------------------- */
PAGES.loads = {
  ic: '⚖️', name: 'الأحمال', ttl: 'الأحمال الميتة والحية',
  sub: 'الكود العراقي للأحمال والقوى — جداول الأحمال الحية والكثافات وحاسبة تركيب الطابق',
  desc: 'جداول الكود العراقي + حاسبة أحمال الطابق',
  html: () => `<div class="grid g2">
    <div class="card"><h3>حاسبة أحمال الطابق</h3><div class="f">
      ${F('سمك البلاطة', 'l_slab', 150, 5, 'مم')}${F('طبقة الرمل', 'l_sand', 50, 5, 'مم')}
      ${F('المونة', 'l_mortar', 25, 5, 'مم')}${F('الكاشي/السيراميك', 'l_tiles', 25, 5, 'مم')}
      ${F('البلاستر', 'l_plaster', 20, 5, 'مم')}${F('القواطع', 'l_part', 1.0, .1, 'kN/m²')}
      ${F('أحمال إضافية', 'l_extra', 0, .1, 'kN/m²')}
      ${S('الاستعمال (حمل حي)', 'l_use', META.live.map(x => [x.v, x.name + ' — ' + x.v]), 2)}</div>
      <div class="row"><button class="btn" onclick="PAGES.loads.run()">احسب</button></div>
      <div id="l_out" style="margin-top:12px"></div></div>
    <div class="card"><h3>الأحمال الحية — الكود العراقي</h3>
      ${table(['نوع الإشغال', 'kN/m²'], META.live.map(x => [x.name, nf(x.v, 1)]))}</div>
    <div class="card"><h3>كثافات المواد</h3>
      ${table(['المادة', 'kN/m³'], META.dens.map(x => [x.name, nf(x.v, 1)]))}</div>
    <div class="card"><h3>تراكيب الأحمال — ACI 318-19 / ASCE 7</h3>
      ${table(['#', 'التركيب'], [[1, 'U = 1.4D'], [2, 'U = 1.2D + 1.6L + 0.5(Lr أو S)'],
        [3, 'U = 1.2D + 1.6(Lr أو S) + (1.0L أو 0.5W)'], [4, 'U = 1.2D + 1.0W + 1.0L + 0.5Lr'],
        [5, 'U = 1.2D + 1.0E + 1.0L'], [6, 'U = 0.9D + 1.0W'], [7, 'U = 0.9D + 1.0E']])}
      <div class="note">معاملات الخفض φ: انحناء 0.90 (مشدود) · قص 0.75 · أعمدة مطوّقة 0.65 · حمل مركزي 0.65</div>
    </div></div>`,
  run: async () => {
    const r = await post('floor', { slab: val('l_slab'), sand: val('l_sand'), mortar: val('l_mortar'),
      tiles: val('l_tiles'), plaster: val('l_plaster'), partitions: val('l_part'),
      extra: val('l_extra'), live: parseFloat(txt('l_use')) });
    $('#l_out').innerHTML = `<div class="grid g3">${kpi('الحمل الميت D', nf(r.D) + ' kN/m²')}
      ${kpi('الحمل الحي L', nf(r.L) + ' kN/m²')}${kpi('wu = 1.2D+1.6L', nf(r.wu) + ' kN/m²', 'ok')}</div>
      <div style="margin-top:10px">${table(['المكوّن', 'kN/m²'], r.items.map(i => [i.name, nf(i.v)]))}</div>
      <div style="margin-top:10px">${table(['التركيب', 'kN/m²'], r.combos.map(i => [i.name, nf(i.v)]))}</div>`;
  },
  init: () => PAGES.loads.run()
};

/* ------------------------------- الزلازل -------------------------------- */
PAGES.seismic = {
  ic: '🌊', name: 'التحليل الزلزالي', ttl: 'القوى الزلزالية — طريقة القوة الجانبية المكافئة',
  sub: 'ASCE 7-16 ELF المعتمدة في الكود العراقي للمقاومة الزلزالية',
  desc: 'قص القاعدة وتوزيع القوى على الطوابق',
  html: () => `<div class="card"><h3>المعطيات</h3><div class="f">
      ${S('المحافظة', 's_city', META.cities.map(c => c.name), 'بغداد')}
      ${S('صنف الموقع', 's_site', [['A', 'A — صخر صلد'], ['B', 'B — صخر'], ['C', 'C — تربة كثيفة'],
        ['D', 'D — تربة متماسكة (افتراضي)'], ['E', 'E — تربة رخوة']], 'D')}
      ${S('النظام الإنشائي', 's_sys', META.systems.map(s => s.name), META.systems[1] && META.systems[1].name)}
      ${F('عدد الطوابق', 's_n', 5, 1)}${F('ارتفاع الطابق', 's_h', 3.2, .1, 'م')}
      ${F('وزن الطابق W', 's_w', 2500, 10, 'kN')}${F('معامل الأهمية Ie', 's_ie', 1.0, .25)}</div>
      <div class="row"><button class="btn" onclick="PAGES.seismic.run()">احسب القوى الزلزالية</button></div>
      <div class="note">قيم Ss و S1 المدرجة استرشادية للاستئناس — يجب تدقيقها من خرائط الكود العراقي للمقاومة الزلزالية المعتمدة.</div>
    </div><div id="s_out" style="margin-top:16px"></div>`,
  run: async () => {
    const n = Math.max(1, Math.round(val('s_n'))), hh = val('s_h'), w = val('s_w');
    const st = []; for (let i = 1; i <= n; i++) st.push({ name: 'طابق ' + i, w: w, h: hh * i });
    const r = await post('seismic', { city: txt('s_city'), site: txt('s_site'), system: txt('s_sys'),
      hn: hh * n, W: w * n, Ie: val('s_ie'), stories: st });
    const F_ = r.dist.map(d => d.Fx), Hs = r.dist.map(d => d.h);
    $('#s_out').innerHTML = `<div class="grid g4">
      ${kpi('قص القاعدة V', nf(r.V, 1) + ' kN', 'ok')}${kpi('Cs المستخدم', nf(r.Cs_use, 4))}
      ${kpi('SDS', nf(r.SDS, 3))}${kpi('SD1', nf(r.SD1, 3))}
      ${kpi('الزمن الدوري Ta', nf(r.Ta, 3) + ' ث')}${kpi('معامل R', nf(r.R, 1))}
      ${kpi('صنف التصميم الزلزالي', r.sdc)}${kpi('الوزن الفعّال W', int(r.W) + ' kN')}</div>
      <div class="grid g2" style="margin-top:16px">
      <div class="card"><h3>توزيع القوى على الطوابق</h3>${table(['الطابق', 'الارتفاع (م)', 'الوزن (kN)', 'Cvx', 'Fx (kN)', 'القص Vx (kN)'],
        r.dist.slice().reverse().map(d => [d.level, nf(d.h, 1), int(d.w), nf(d.cvx, 3), nf(d.Fx, 1), nf(d.Vx, 1)]))}</div>
      <div class="card"><h3>مخطط القوى الجانبية</h3>${plot({ x: Hs, series: [{ y: F_, color: '#38bdf8', fill: 1 }],
        title: 'Fx (kN) مقابل الارتفاع (م)', h: 230 })}
        <div class="hint">${r.note}</div></div>
      <div class="card"><h3>المعاملات المستخدمة</h3>${table(['المعامل', 'القيمة'], [['Ss', nf(r.Ss, 3)], ['S1', nf(r.S1, 3)],
        ['Fa', nf(r.Fa, 2)], ['Fv', nf(r.Fv, 2)], ['SMS', nf(r.SMS, 3)], ['SM1', nf(r.SM1, 3)],
        ['Cs الأساسي', nf(r.Cs, 4)], ['Cs الأعلى', nf(r.Cs_max, 4)], ['Cs الأدنى', nf(r.Cs_min, 4)],
        ['k (التوزيع)', nf(r.k, 2)], ['النظام', r.system]])}</div></div>`;
  },
  init: () => PAGES.seismic.run()
};

/* -------------------------------- الرياح -------------------------------- */
PAGES.wind = {
  ic: '💨', name: 'أحمال الرياح', ttl: 'ضغط الرياح على المبنى',
  sub: 'qz = 0.613·Kz·Kzt·Kd·V²  —  ASCE 7 / الكود العراقي',
  desc: 'ضغوط الرياح وتوزيعها مع الارتفاع',
  html: () => `<div class="card"><h3>المعطيات</h3><div class="f">
      ${F('سرعة الرياح الأساسية V', 'w_v', 34, 1, 'م/ث')}
      ${S('تصنيف التعرّض', 'w_exp', [['B', 'B — حضري'], ['C', 'C — مفتوح'], ['D', 'D — ساحلي']], 'B')}
      ${F('ارتفاع المبنى', 'w_h', 18, .5, 'م')}${F('عرض الواجهة', 'w_b', 20, .5, 'م')}</div>
      <div class="row"><button class="btn" onclick="PAGES.wind.run()">احسب</button></div></div>
      <div id="w_out" style="margin-top:16px"></div>`,
  run: async () => {
    const r = await post('wind', { V: val('w_v'), exposure: txt('w_exp'), h: val('w_h'), B: val('w_b') });
    $('#w_out').innerHTML = `<div class="grid g3">${kpi('ضغط السرعة عند القمة qh', nf(r.qh, 3) + ' kN/m²')}
      ${kpi('ضغط الجهة المقابلة', nf(r.p_lee, 3) + ' kN/m²')}${kpi('القوة الكلية التقريبية', nf(r.F_total, 1) + ' kN', 'ok')}</div>
      <div class="grid g2" style="margin-top:16px"><div class="card"><h3>الضغط مع الارتفاع</h3>
      ${plot({ x: r.levels.map(l => l.z), series: [{ y: r.levels.map(l => l.pw), color: '#22d3ee', fill: 1 }],
        title: 'ضغط الجهة المواجهة (kN/m²)', h: 230 })}</div>
      <div class="card"><h3>الجدول</h3>${table(['z (م)', 'Kz', 'qz (kN/m²)', 'ضغط مواجه (kN/m²)'],
        r.levels.map(l => [nf(l.z, 1), nf(l.Kz, 3), nf(l.qz, 3), nf(l.pw, 3)]))}
        <div class="hint">${r.note} — G=0.85، Cp = 0.8 مواجه / −0.5 مقابل، Kd=0.85</div></div></div>`;
  },
  init: () => PAGES.wind.run()
};

/* -------------------------------- الجسور -------------------------------- */
function spanRow(L, D, Lv) {
  return `<div class="sp"><input type="number" step="0.1" value="${L}" data-k="L" placeholder="الطول م">
   <input type="number" step="0.5" value="${D}" data-k="wD" placeholder="ميت kN/m">
   <input type="number" step="0.5" value="${Lv}" data-k="wL" placeholder="حي kN/m">
   <button class="btn gh" onclick="this.parentNode.remove()">✕</button></div>`;
}
function beamElevation(r) {
  const W = 860, H = 165, ml = 40, tot = r.total_L;
  const X = x => ml + x / tot * (W - 2 * ml), yT = 46, yB = 96;
  let g = `<rect x="${X(0)}" y="${yT}" width="${X(tot) - X(0)}" height="${yB - yT}" fill="#1e3a5f" stroke="#7dd3fc"/>`;
  let x = 0; const nodes = [0];
  r.spans.forEach(L => { x += L; nodes.push(x); });
  nodes.forEach((nx, i) => {
    g += `<polygon points="${X(nx)},${yB} ${X(nx) - 9},${yB + 15} ${X(nx) + 9},${yB + 15}" fill="#94a3b8"/>
      <line x1="${X(nx) - 13}" x2="${X(nx) + 13}" y1="${yB + 15}" y2="${yB + 15}" stroke="#94a3b8" stroke-width="2"/>`;
    const s = r.supports[i];
    if (s && s.flex) g += `<line x1="${X(Math.max(0, nx - (r.spans[i - 1] || 0) * .3))}" x2="${X(Math.min(tot, nx + (r.spans[i] || 0) * .3))}"
      y1="${yT + 8}" y2="${yT + 8}" stroke="#f87171" stroke-width="3"/>
      <text x="${X(nx)}" y="${yT - 6}" fill="#fca5a5" font-size="11" text-anchor="middle">${s.flex.bars.label} علوي</text>`;
  });
  r.design.forEach((d, i) => {
    const a = nodes[i], b = nodes[i + 1];
    g += `<line x1="${X(a) + 6}" x2="${X(b) - 6}" y1="${yB - 8}" y2="${yB - 8}" stroke="#34d399" stroke-width="3"/>
      <text x="${X((a + b) / 2)}" y="${yB + 34}" fill="#6ee7b7" font-size="11" text-anchor="middle">${d.flex.bars.label} سفلي</text>
      <text x="${X((a + b) / 2)}" y="${yB + 48}" fill="#93a4c0" font-size="10.5" text-anchor="middle">L=${nf(d.L, 2)} م · ${d.shear.label}</text>`;
  });
  return `<svg viewBox="0 0 ${W} ${H}">${g}</svg>`;
}
PAGES.beam = {
  ic: '📏', name: 'تحليل وتصميم الجسور', ttl: 'الجسور الخرسانية — تحليل وتصميم',
  sub: 'تحليل مصفوفي للجسور المستمرة مع تحميل نمطي (Pattern Loading) وتصميم ACI 318-19',
  desc: 'عزوم وقصّ وهطول + تسليح كامل',
  html: () => `<div class="grid g2">
    <div class="card"><h3>الفضاءات والأحمال</h3>
      <div class="hint" style="margin:0 0 6px">الطول (م) · الحمل الميت (kN/m) · الحمل الحي (kN/m) — الوزن الذاتي يُضاف تلقائياً</div>
      <div class="spans" id="spans">${spanRow(6, 20, 12) + spanRow(6, 20, 12) + spanRow(6, 20, 12)}</div>
      <div class="row"><button class="btn gh" onclick="$('#spans').insertAdjacentHTML('beforeend', spanRow(6,20,12))">+ إضافة فضاء</button>
        ${C('تثبيت الطرف الأيسر', 'b_fl', 0)}${C('تثبيت الطرف الأيمن', 'b_fr', 0)}</div></div>
    <div class="card"><h3>المقطع والمواد</h3><div class="f">
      ${F('العرض b', 'b_b', 300, 10, 'مم')}${F('العمق h', 'b_h', 600, 10, 'مم')}
      ${F("f'c", 'b_fc', 25, 1, 'MPa')}${F('fy', 'b_fy', 420, 10, 'MPa')}
      ${F('الغطاء الخرساني', 'b_cov', 40, 5, 'مم')}
      ${S('قطر الحديد الرئيسي', 'b_db', [12, 16, 20, 25, 32], 16)}
      ${S('قطر الأساور', 'b_ds', [8, 10, 12], 10)}</div>
      <div class="row"><button class="btn" onclick="PAGES.beam.run()">تحليل وتصميم</button></div></div></div>
    <div id="b_out" style="margin-top:16px"></div>`,
  run: async () => {
    const spans = $$('#spans .sp').map(r => { const o = {}; $$('input', r).forEach(i => o[i.dataset.k] = parseFloat(i.value) || 0); return o; });
    if (!spans.length) return alert('أضف فضاءً واحداً على الأقل');
    const r = await post('beam', { spans, b: val('b_b'), h: val('b_h'), fc: val('b_fc'), fy: val('b_fy'),
      cover: val('b_cov'), db_main: parseFloat(txt('b_db')), db_stirrup: parseFloat(txt('b_ds')),
      fix_left: chk('b_fl'), fix_right: chk('b_fr') });
    const X = [], Mx = [], Mn_ = [], V = [], Df = [];
    r.env.forEach((sp, k) => sp.forEach((p, i) => { if (k && i === 0) return;
      X.push(p.x); Mx.push(p.Mmax); Mn_.push(p.Mmin); V.push(p.Vmax); Df.push(r.defl[k][i].d); }));
    const maxM = Math.max(...Mx), minM = Math.min(...Mn_), maxV = Math.max(...V.map(Math.abs));
    const dmax = Math.min(...r.design.map(d => d.d_long)), okAll = r.design.every(d => d.flex.ok && d.shear.ok && d.defl_ok);
    $('#b_out').innerHTML = `<div class="grid g4">
      ${kpi('أقصى عزم موجب', nf(maxM, 1) + ' kN·m')}${kpi('أقصى عزم سالب', nf(minM, 1) + ' kN·m')}
      ${kpi('أقصى قص', nf(maxV, 1) + ' kN')}${kpi('الهطول بعيد المدى', nf(dmax, 1) + ' مم', okAll ? 'ok' : 'warn')}
      ${kpi('العمق الفعّال d', nf(r.d, 0) + ' مم')}${kpi('الوزن الذاتي', nf(r.sw, 2) + ' kN/m')}
      ${kpi('Ec', int(r.Ec) + ' MPa')}${kpi('الحالة', okAll ? 'مقبول ✓' : 'يحتاج مراجعة', okAll ? 'ok' : 'bad')}</div>
    <div class="card" style="margin-top:16px"><h3>المخططات (مغلّف التحميل النمطي)</h3>
      ${plot({ x: X, series: [{ y: Mx, color: '#38bdf8', fill: 1 }, { y: Mn_, color: '#f87171', fill: 1 }],
        title: 'مخطط العزوم BMD (kN·m) — الموجب للأسفل', invert: 1, h: 240 })}
      ${plot({ x: X, series: [{ y: V, color: '#a78bfa', fill: 1 }], title: 'مخطط القص SFD (kN)', h: 200 })}
      ${plot({ x: X, series: [{ y: Df, color: '#34d399' }], title: 'الهطول الآني تحت (D+L) بالمليمتر', h: 190 })}
      <div class="legend"><span><i style="background:#38bdf8"></i>عزم موجب (شد سفلي)</span>
        <span><i style="background:#f87171"></i>عزم سالب (شد علوي)</span>
        <span><i style="background:#a78bfa"></i>قص</span><span><i style="background:#34d399"></i>هطول</span></div></div>
    <div class="card" style="margin-top:16px"><h3>مخطط التسليح التفصيلي</h3>${beamElevation(r)}</div>
    <div class="grid g2" style="margin-top:16px">
      <div class="card"><h3>تصميم الفضاءات</h3>${table(['الفضاء', 'Mu+ (kN·m)', 'As (مم²)', 'التسليح السفلي', 'φMn', 'Vu (kN)', 'الأساور', 'هطول/الحد', 'الحالة'],
        r.design.map(d => [d.idx, nf(d.Mpos, 1), int(d.flex.As_req), d.flex.bars.label, nf(d.flex.phiMn, 1),
          nf(d.Vu, 1), d.shear.label, nf(Math.abs(d.d_long), 1) + '/' + nf(d.d_limit, 1),
          tag(d.flex.ok && d.shear.ok && d.defl_ok)]))}</div>
      <div class="card"><h3>تصميم المساند (عزوم سالبة)</h3>${table(['المسند', 'Mu− (kN·m)', 'As (مم²)', 'التسليح العلوي', 'φMn'],
        r.supports.map(s => [s.idx + 1, nf(s.M, 1), s.flex ? int(s.flex.As_req) : '—',
          s.flex ? s.flex.bars.label : 'أقل تسليح', s.flex ? nf(s.flex.phiMn, 1) : '—']))}
        <div class="note">طول الرباط ld: علوي ${nf(r.ld_top, 0)} مم · سفلي ${nf(r.ld_bot, 0)} مم (ACI 25.4.2)</div></div>
      <div class="card"><h3>مقطع الفضاء</h3>${sectionSVG(r.b, r.h,
        { rows: [{ n: r.design[0].flex.bars.n, db: r.design[0].flex.bars.db, top: 0 }, { n: 2, db: 12, top: 1 }],
          stirrups: r.design[0].shear.label })}</div>
      <div class="card"><h3>مقطع المسند</h3>${(() => { const s = r.supports.find(s => s.flex);
        return s ? sectionSVG(r.b, r.h, { rows: [{ n: s.flex.bars.n, db: s.flex.bars.db, top: 1 }, { n: 2, db: 12, top: 0 }],
          stirrups: r.design[0].shear.label }) : '<div class="hint">لا توجد عزوم سالبة</div>'; })()}</div></div>`;
  },
  init: () => PAGES.beam.run()
};

/* ------------------------------- الأعمدة -------------------------------- */
PAGES.column = {
  ic: '🏛️', name: 'تصميم الأعمدة', ttl: 'الأعمدة الخرسانية — منحني التفاعل',
  sub: 'منحني تفاعل بالتوافق الانفعالي (Strain Compatibility) + فحص النحافة ACI 318-19',
  desc: 'منحني P–M وفحص النحافة والتطويق',
  html: () => `<div class="grid g2"><div class="card"><h3>المقطع والتسليح</h3><div class="f">
      ${F('العرض b', 'c_b', 400, 10, 'مم')}${F('العمق h', 'c_h', 500, 10, 'مم')}
      ${F("f'c", 'c_fc', 28, 1, 'MPa')}${F('fy', 'c_fy', 420, 10, 'MPa')}
      ${S('قطر السيخ', 'c_db', [16, 20, 25, 32], 20)}
      ${F('عدد الأسياخ بالوجه العلوي/السفلي', 'c_nb', 3, 1)}
      ${F('عدد الأسياخ بالوجه الجانبي', 'c_nh', 3, 1)}</div></div>
    <div class="card"><h3>الأحمال والنحافة</h3><div class="f">
      ${F('Pu', 'c_pu', 1800, 10, 'kN')}${F('Mu', 'c_mu', 150, 5, 'kN·m')}
      ${F('M1 (العزم الأصغر)', 'c_m1', 0, 5, 'kN·m')}
      ${F('الطول غير المسند lu', 'c_lu', 3.2, .1, 'م')}${F('معامل الطول k', 'c_k', 1.0, .05)}
      ${C('إطار غير قابل للإزاحة الجانبية', 'c_br', 1)}</div>
      <div class="row"><button class="btn" onclick="PAGES.column.run()">تصميم وفحص</button></div></div></div>
    <div id="c_out" style="margin-top:16px"></div>`,
  run: async () => {
    const r = await post('column', { b: val('c_b'), h: val('c_h'), fc: val('c_fc'), fy: val('c_fy'),
      db: parseFloat(txt('c_db')), nb: val('c_nb'), nh: val('c_nh'), Pu: val('c_pu'), Mu: val('c_mu'),
      M1: val('c_m1'), lu: val('c_lu'), k: val('c_k'), braced: chk('c_br') });
    const W = 560, H = 380, ml = 62, mb = 42;
    const Ms = r.pts.map(p => p.M), Ps = r.pts.map(p => p.P);
    const m1 = Math.max(...Ms) * 1.15, p1 = Math.max(...Ps) * 1.1, p0 = Math.min(0, ...Ps) * 1.2;
    const X = v => ml + v / m1 * (W - ml - 20), Y = v => H - mb - (v - p0) / (p1 - p0) * (H - mb - 20);
    let g = '';
    for (let i = 0; i <= 5; i++) { const v = p0 + (p1 - p0) * i / 5;
      g += `<line x1="${ml}" x2="${W - 20}" y1="${Y(v)}" y2="${Y(v)}" stroke="#22304f"/>
        <text x="${ml - 6}" y="${Y(v) + 4}" fill="#93a4c0" font-size="10" text-anchor="end">${int(v)}</text>`; }
    for (let i = 0; i <= 5; i++) { const v = m1 * i / 5;
      g += `<line x1="${X(v)}" x2="${X(v)}" y1="20" y2="${H - mb}" stroke="#22304f"/>
        <text x="${X(v)}" y="${H - mb + 16}" fill="#93a4c0" font-size="10" text-anchor="middle">${int(v)}</text>`; }
    g += `<polyline points="${r.pts.map(p => `${X(p.M)},${Y(p.P)}`).join(' ')}" fill="#38bdf822" stroke="#38bdf8" stroke-width="2"/>`;
    g += `<line x1="${X(0)}" x2="${X(r.Mc)}" y1="${Y(r.Pu)}" y2="${Y(r.Pu)}" stroke="#64748b" stroke-dasharray="4 3"/>
      <circle cx="${X(r.Mc)}" cy="${Y(r.Pu)}" r="6" fill="${r.ok ? '#34d399' : '#f87171'}" stroke="#fff" stroke-width="1.5"/>
      <text x="${X(r.Mc) + 10}" y="${Y(r.Pu) - 8}" fill="#fff" font-size="11">(${nf(r.Mc, 0)} , ${nf(r.Pu, 0)})</text>
      <text x="${W / 2}" y="${H - 6}" fill="#93a4c0" font-size="11" text-anchor="middle">φMn (kN·m)</text>
      <text x="14" y="${H / 2}" fill="#93a4c0" font-size="11" transform="rotate(-90 14 ${H / 2})" text-anchor="middle">φPn (kN)</text>`;
    $('#c_out').innerHTML = `<div class="grid g4">
      ${kpi('نسبة الاستغلال', nf(r.ratio, 2), r.ok ? 'ok' : 'bad')}
      ${kpi('φMn عند Pu', nf(r.phiMn, 1) + ' kN·m')}${kpi('φPn,max', int(r.phiPn_max) + ' kN')}
      ${kpi('نسبة التسليح ρ', nf(r.rho * 100, 2) + '%', r.rho_ok ? 'ok' : 'bad')}
      ${kpi('النحافة klu/r', nf(r.slend, 1) + ' / ' + nf(r.slend_lim, 1), r.slender ? 'warn' : 'ok')}
      ${kpi('معامل التكبير δ', nf(r.delta, 3))}${kpi('Mc المصمم', nf(r.Mc, 1) + ' kN·m')}
      ${kpi('الحالة', r.ok ? 'مقبول ✓' : 'غير مقبول ✗', r.ok ? 'ok' : 'bad')}</div>
    <div class="grid g2" style="margin-top:16px">
      <div class="card"><h3>منحني التفاعل P–M</h3><svg viewBox="0 0 ${W} ${H}">${g}</svg>
        <div class="legend"><span><i style="background:#38bdf8"></i>منحني المقاومة المصمّمة φPn–φMn</span>
        <span><i style="background:${r.ok ? '#34d399' : '#f87171'}"></i>نقطة التحميل</span></div></div>
      <div class="card"><h3>المقطع والتفاصيل</h3>
        ${sectionSVG(r.b, r.h, { layers: r.layers.map(l => [l[0], l[1], Math.round(l[1] / (Math.PI * r.db * r.db / 4))]), db: r.db })}
        ${table(['البند', 'القيمة'], [['التسليح الطولي', r.bars], ['مساحة الحديد Ast', int(r.Ast) + ' مم²'],
          ['نسبة التسليح', nf(r.rho * 100, 2) + '% (الحد 1–8%)'], ['الأساور/التطويق', r.ties],
          ['المساحة Ag', int(r.Ag) + ' مم²'], ['P0', int(r.P0) + ' kN'],
          ['نحافة', r.slender ? 'عمود نحيف — تم التكبير' : 'عمود قصير']])}
        ${r.slender ? '<div class="note">العمود نحيف: تم تكبير العزم بطريقة تكبير العزوم (ACI 6.6.4).</div>' : ''}</div></div>`;
  },
  init: () => PAGES.column.run()
};

/* -------------------------------- الأسس --------------------------------- */
PAGES.footing = {
  ic: '🧱', name: 'تصميم الأسس', ttl: 'الأساس المنفرد تحت العمود',
  sub: 'الأبعاد وقص الثقب (Punching) والقص الأحادي والانحناء — ACI 318-19 الفصل 13',
  desc: 'أبعاد + قص ثقب + تسليح',
  html: () => `<div class="grid g2"><div class="card"><h3>الأحمال والتربة</h3><div class="f">
      ${F('الحمل الميت PD', 'f_pd', 900, 10, 'kN')}${F('الحمل الحي PL', 'f_pl', 450, 10, 'kN')}
      ${F('عزم على الأساس M', 'f_m', 0, 5, 'kN·m')}
      ${F('تحمّل التربة المسموح qa', 'f_qa', 150, 5, 'kN/m²')}
      ${F('عمق التأسيس Df', 'f_df', 1.5, .1, 'م')}</div></div>
    <div class="card"><h3>العمود والمواد</h3><div class="f">
      ${F('عرض العمود cx', 'f_cx', 400, 10, 'مم')}${F('عمق العمود cy', 'f_cy', 400, 10, 'مم')}
      ${F("f'c", 'f_fc', 25, 1, 'MPa')}${F('fy', 'f_fy', 420, 10, 'MPa')}</div>
      <div class="row"><button class="btn" onclick="PAGES.footing.run()">تصميم الأساس</button></div></div></div>
    <div id="f_out" style="margin-top:16px"></div>`,
  run: async () => {
    const r = await post('footing', { PD: val('f_pd'), PL: val('f_pl'), M: val('f_m'), qa: val('f_qa'),
      Df: val('f_df'), cx: val('f_cx'), cy: val('f_cy'), fc: val('f_fc'), fy: val('f_fy') });
    const W = 400, H = 210, S = 300 / (r.B * 1000), bw = r.B * 1000 * S, hh = r.h * S;
    const ox = (W - bw) / 2, oy = 40, cw = r.cx * S;
    const g = `<rect x="${ox}" y="${oy}" width="${bw}" height="${hh}" fill="#1e3a5f" stroke="#7dd3fc" stroke-width="1.6"/>
      <rect x="${(W - cw) / 2}" y="${oy - 30}" width="${cw}" height="30" fill="#334155" stroke="#94a3b8"/>
      <line x1="${ox + 8}" x2="${ox + bw - 8}" y1="${oy + hh - 10}" y2="${oy + hh - 10}" stroke="#f87171" stroke-width="3"/>
      <text x="${W / 2}" y="${oy + hh + 20}" fill="#93a4c0" font-size="11" text-anchor="middle">B = ${nf(r.B, 2)} م × ${nf(r.B, 2)} م</text>
      <text x="${ox + bw + 6}" y="${oy + hh / 2}" fill="#93a4c0" font-size="11">h=${int(r.h)}مم</text>
      <text x="${W / 2}" y="${oy + hh + 40}" fill="#fca5a5" font-size="11.5" text-anchor="middle">${r.bars_label}</text>
      ${[...Array(9)].map((_, i) => { const x = ox + bw * i / 8;
        return `<line x1="${x}" x2="${x}" y1="${oy + hh}" y2="${oy + hh + 8 + (i % 2 ? 4 : 0)}" stroke="#64748b"/>`; }).join('')}`;
    $('#f_out').innerHTML = `<div class="grid g4">
      ${kpi('أبعاد الأساس', nf(r.B, 2) + '×' + nf(r.B, 2) + ' م', 'ok')}${kpi('السماكة h', int(r.h) + ' مم')}
      ${kpi('ضغط التربة qu', nf(r.qu_max, 1) + ' kN/m²')}${kpi('صافي تحمّل التربة', nf(r.q_net, 1) + ' kN/m²')}
      ${kpi('نسبة قص الثقب', nf(r.punch_ratio, 2), r.punch_ratio <= 1 ? 'ok' : 'bad')}
      ${kpi('نسبة القص الأحادي', nf(r.oneway_ratio, 2), r.oneway_ratio <= 1 ? 'ok' : 'bad')}
      ${kpi('حجم الخرسانة', nf(r.conc, 2) + ' م³')}${kpi('الحالة', r.ok ? 'مقبول ✓' : 'راجع', r.ok ? 'ok' : 'bad')}</div>
    <div class="grid g2" style="margin-top:16px">
      <div class="card"><h3>مقطع الأساس</h3><svg viewBox="0 0 ${W} ${H}">${g}</svg></div>
      <div class="card"><h3>نتائج الفحوصات</h3>${table(['الفحص', 'المطلوب Vu/Mu', 'المقاومة φVn', 'الحالة'], [
        ['قص الثقب (اتجاهين)', nf(r.Vu2, 1) + ' kN', nf(r.phiVc2, 1) + ' kN', tag(r.Vu2 <= r.phiVc2)],
        ['القص الأحادي', nf(r.Vu1, 1) + ' kN', nf(r.phiVc1, 1) + ' kN', tag(r.Vu1 <= r.phiVc1)],
        ['الانحناء عند وجه العمود', nf(r.Mu, 1) + ' kN·m/م', '—', tag(true)],
        ['ارتكاز العمود', nf(r.Pu, 1) + ' kN', nf(r.bearing, 1) + ' kN', tag(r.Pu <= r.bearing)]])}
        ${table(['البند', 'القيمة'], [['حمل الخدمة Ps', nf(r.Ps, 1) + ' kN'], ['الحمل المعامل Pu', nf(r.Pu, 1) + ' kN'],
          ['العمق الفعّال d', int(r.d) + ' مم'], ['As المطلوب', int(r.As) + ' مم²/م'],
          ['As الأدنى (0.0018)', int(r.As_min) + ' مم²/م'], ['التسليح', r.bars_label],
          ['أسياخ التوصيل (Dowels)', int(r.dowels) + ' مم² (0.5% من مساحة العمود)']])}</div></div>`;
  },
  init: () => PAGES.footing.run()
};

/* ------------------------------- البلاطات ------------------------------- */
/* ------------------------------- X-RAY ---------------------------------- */
function xraySVG(r) {
  const W = 880, mgL = 70, mgR = 60, mgT = 34, mgB = 54;
  const xmax = r.xs[r.xs.length - 1], ymax = r.ys[r.ys.length - 1];
  const sc = Math.min((W - mgL - mgR) / xmax, 430 / ymax);
  const H = ymax * sc + mgT + mgB;
  const X = x => mgL + x * sc, Y = y => H - mgB - y * sc;
  let g = `<defs><pattern id="hz" width="9" height="9" patternTransform="rotate(45)"
    patternUnits="userSpaceOnUse"><line x1="0" y1="0" x2="0" y2="9" stroke="#475569" stroke-width="2"/></pattern></defs>`;
  g += `<line x1="${X(0) - 30}" x2="${X(xmax) + 30}" y1="${Y(0)}" y2="${Y(0)}" stroke="#64748b" stroke-width="2"/>
    <rect x="${X(0) - 30}" y="${Y(0)}" width="${X(xmax) - X(0) + 60}" height="14" fill="url(#hz)" opacity=".8"/>`;
  r.members.forEach(m => {
    const a = r.nodes[m.ni], b = r.nodes[m.nj], c = rcol(m.ratio);
    const w = m.kind === 'col' ? 9 : 7;
    g += `<line x1="${X(a.x)}" y1="${Y(a.y)}" x2="${X(b.x)}" y2="${Y(b.y)}" stroke="${c}"
      stroke-width="${w}" stroke-linecap="round" opacity=".92"><title>${m.kind === 'col' ? 'عمود' : 'جسر'} ${m.story}-${m.pos} — نسبة ${nf(m.ratio, 2)}</title></line>`;
    const mx = (X(a.x) + X(b.x)) / 2, my = (Y(a.y) + Y(b.y)) / 2;
    g += `<text x="${mx}" y="${my + (m.kind === 'col' ? 0 : -9)}" fill="#0b1220" font-size="9.5"
      font-weight="700" text-anchor="middle" stroke="#e2e8f0" stroke-width="2.4" paint-order="stroke">${nf(m.ratio, 2)}</text>`;
  });
  r.nodes.forEach(n => { g += `<circle cx="${X(n.x)}" cy="${Y(n.y)}" r="3.4" fill="#0b1220" stroke="#94a3b8" stroke-width="1.4"/>`; });
  r.ys.forEach((y, j) => { if (j) g += `<text x="${X(0) - 12}" y="${Y(y) + 4}" fill="#93a4c0" font-size="10.5"
    text-anchor="end">ط${j} (${nf(y, 1)}م)</text>`; });
  r.xs.forEach((x, i) => { if (i < r.xs.length - 1) g += `<text x="${(X(x) + X(r.xs[i + 1])) / 2}" y="${H - 30}"
    fill="#93a4c0" font-size="10.5" text-anchor="middle">${nf(r.xs[i + 1] - x, 1)} م</text>`; });
  if (r.seismic) r.seismic.dist.forEach((d, j) => {
    const y = Y(r.ys[j + 1]), x = X(0);
    g += `<line x1="${x - 46}" x2="${x - 8}" y1="${y}" y2="${y}" stroke="#fbbf24" stroke-width="2"
      marker-end="url(#ar)"/><text x="${x - 48}" y="${y - 5}" fill="#fbbf24" font-size="9.5" text-anchor="end">${nf(d.Fx, 0)} kN</text>`;
  });
  g += `<defs><marker id="ar" markerWidth="7" markerHeight="7" refX="6" refY="3.5" orient="auto">
    <polygon points="0,0 7,3.5 0,7" fill="#fbbf24"/></marker></defs>`;
  return `<svg viewBox="0 0 ${W} ${H}">${g}</svg>`;
}
/* ------------------------------- الكميات -------------------------------- */
/* ------------------------------- المرجع --------------------------------- */
PAGES.ref = {
  ic: '📚', name: 'مرجع الكود', ttl: 'المرجع الفني والمعادلات المعتمدة',
  sub: 'ما الذي يحسبه البرنامج بالضبط، ووفق أي بند من الكود',
  desc: 'المعادلات والمراجع والفرضيات',
  html: () => `<div class="grid g2">
    <div class="card ref"><h3>التحليل الإنشائي</h3>
      <h4>طريقة الصلابة المباشرة</h4><ul>
      <li>إطار مستوي بثلاث درجات حرية لكل عقدة (ux, uy, θz) وحلّ <code>K·u = P</code> بطريقة غاوس.</li>
      <li>عزوم التثبيت للحمل الموزع: <code>±wL²/12</code> وردود <code>wL/2</code>.</li>
      <li>القوى الداخلية: <code>V(x)=Vi+w·x</code> و <code>M(x)=−Mi+Vi·x+w·x²/2</code>.</li>
      <li>الهطول بدوال Hermite مع الحل الخاص <code>w·x²(L−x)²/24EI</code>.</li>
      <li>تحميل نمطي (Pattern Loading) لاستخراج مغلّف العزوم في الجسور المستمرة.</li>
      <li>صلابة مشقّقة: جسور 0.35Ig، أعمدة 0.70Ig (ACI 6.6.3.1.1).</li></ul>
      <h4>تم التحقق من المحلل مقابل</h4><ul>
      <li>جسر بسيط الإسناد: M=wL²/8 و δ=5wL⁴/384EI ✓</li>
      <li>جسر مثبت الطرفين: ∓wL²/12 و +wL²/24 ✓</li>
      <li>كابولي ومسنود-مثبت (wL²/8) ومستمر بفضاءين (wL²/8، R=1.25wL) ✓</li></ul></div>
    <div class="card ref"><h3>تصميم الخرسانة — ACI 318-19</h3><ul>
      <li>β1 = 0.85 لـ f'c ≤ 28 MPa، ثم <code>0.85−0.05(f'c−28)/7 ≥ 0.65</code> (22.2.2.4.3).</li>
      <li>φ الانحناء 0.90 للمقاطع المشدودة، ويتدرّج إلى 0.65 حسب εt (21.2.2).</li>
      <li>As,min = <code>max(0.25√f'c/fy , 1.4/fy)·b·d</code> (9.6.1.2).</li>
      <li>القص: <code>Vc = 0.17λ√f'c·bw·d</code>، φ=0.75، <code>Vs ≤ 0.66√f'c·bw·d</code> (22.5).</li>
      <li>تباعد الأساور ≤ d/2 أو 600مم، ويُنصّف عند Vs كبير (9.7.6.2.2).</li>
      <li>طول الرباط ld وفق <b>25.4.2.3(a)</b> ومعاملات <b>جدول 25.4.2.4</b>:
        ψt=1.3 علوي · ψe=1.5/1.2 مطلي · ψs=0.8 <b>لقضيب رقم 19 فأصغر (db ≤ 19.1 مم)</b>
        فـ Ø20 يأخذ 1.0 · وحاصل ψt·ψe ≤ 1.7.</li>
      <li>العكفة ldh وفق <b>25.4.3.1</b> ومعاملات <b>جدول 25.4.3.2</b>: ψc=0.7 بغطاء ≥65مم ·
        ψr=0.8 لعكفة 90° مُطوَّقة — وتُحسب معها صيغة 2019 ويُؤخذ الأكبر.</li>
      <li>الأعمدة: منحني تفاعل بالتوافق الانفعالي (εcu=0.003)، <code>φPn,max=0.80φP0</code> للمطوّقة (22.4.2.1).</li>
      <li>النحافة: <code>klu/r ≤ 34−12(M1/M2)</code> وإلا تكبير العزوم (6.6.4).</li>
      <li><b>الالتواء (22.7)</b>: عتبة <code>Tth = 0.083λ√f'c·Acp²/pcp</code>، وتصميم بمنظومة
        الجَمَلون الفراغي <code>At/s = Tu/(φ·2Ao·fyt·cotθ)</code> مع <code>Ao = 0.85Aoh</code>
        وθ = 45°، وحديد طولي <code>Aℓ = (At/s)·ph·(fyt/fy)</code>، وحدّ المقطع 22.7.7.1،
        وكانات مغلقة بتباعد ≤ min(ph/8 , 300مم) (9.7.6.3.3).</li>
      <li><b>قص العقدة (18.8.4)</b>: <code>Vn = γλ√f'c·Aj</code> مع γ = 1.7/1.2/1.0 حسب
        الحصر، وφ = 0.85، وقوة الحديد بإجهاد <b>1.25fy</b> (18.8.2.1)، وعكفة العقدة
        <code>ldh = fy·db/(5.4λ√f'c)</code> (18.8.5.1).</li>
      <li><b>الترخيم (جدول 24.2.2)</b>: Ie بطريقة Branson (24.2.3.5)، ومعامل الزمن
        <code>λΔ = ξ/(1+50ρ′)</code> (24.2.4.1.1) مضروباً بالترخيم الفوري <b>للحمل الدائم
        وحده</b>، والحدود L/180 و L/360 و <b>L/480</b> و L/240 حسب الحالة.</li>
      <li><b>الديمومة (19.3)</b>: أصناف التعرّض F·S·W·C (جدول 19.3.1.1) وما تفرضه من
        أدنى f'c وأقصى w/cm ونوع أسمنت (جدول 19.3.2.1) — والأشدّ يحكم حين تجتمع.</li>
      <li>البلاطات: السماكات الدنيا (7.3.1.1 و8.3.1.1)، معاملات العزوم التقريبية (6.5.2)، DDM (8.10).</li>
      <li>الأسس: قص الثقب (22.6) والقص الأحادي (22.5) وحديد أدنى 0.0018 (7.6.1.1).</li></ul></div>
    <div class="card ref"><h3>الأحمال — الكود العراقي</h3><ul>
      <li>جدول الأحمال الحية حسب الإشغال (سكني 2.0 · مكاتب 2.5 · مدارس 3.0 · أدراج 4.0 kN/m²…).</li>
      <li>كثافات المواد المحلية (خرسانة مسلحة 24 · طابوق 18 · ثرمستون 8 kN/m³…).</li>
      <li>تراكيب الأحمال وفق ASCE 7 المعتمدة في ACI 318-19 الفصل 5.</li>
      <li>الزلازل: طريقة القوة الجانبية المكافئة — <code>V = Cs·W</code>، <code>Cs = SDS/(R/Ie)</code>
        مع الحدين الأعلى <code>SD1/(T·R/Ie)</code> والأدنى <code>0.044·SDS·Ie ≥ 0.01</code>،
        <code>Ta = Ct·hn^x</code>، والتوزيع <code>Fx = V·wx·hx^k/Σ</code>.</li>
      <li>الرياح: <code>qz = 0.613·Kz·Kzt·Kd·V²</code> مع G=0.85 و Cp=+0.8/−0.5.</li></ul>
      <div class="note">قيم Ss و S1 لكل محافظة مُدرجة كقيم استرشادية للاستئناس فقط؛ الاعتماد يكون على
      خرائط الكود العراقي للمقاومة الزلزالية المعتمدة رسمياً.</div></div>
    <div class="card ref"><h3>الفرضيات والحدود</h3><ul>
      <li>الوحدات: kN، متر، مليمتر، MPa. الخرسانة عادية الوزن (λ=1.0).</li>
      <li>التحليل مستوي ثنائي الأبعاد (2D Frame) — لا يشمل التحليل الديناميكي الطيفي. الالتواء يُصمَّم بالباب 22.7 على الجسر الطرفي من عزم طرف البلاطة (جدول 6.5.2)، لا من تحليل فراغي للالتواء.</li>
      <li>الأعمدة تُفحص للانحناء أحادي المحور؛ للانحناء ثنائي المحور استخدم طريقة Bresler يدوياً.</li>
      <li>النتائج أداة مساعدة للمهندس ولا تُغني عن تدقيق مهندس مُجاز ومصادقة الجهات الرسمية.</li></ul></div></div>`,
  init: () => {}
};

/* ------------------------------- الراوتر -------------------------------- */
function go(id) {
  const p = PAGES[id]; if (!p) return;
  location.hash = id;
  $$('#nav button').forEach(b => b.classList.toggle('on', b.dataset.id === id));
  $('#ttl').textContent = p.ttl; $('#sub').textContent = p.sub;
  $('#view').innerHTML = p.html();
  $('#stat').textContent = 'جاهز';
  try { p.init && p.init(); } catch (e) { console.error(e); }
  try { window.LAYERS && LAYERS.onPage(id); } catch (e) { console.error(e); }   // طبقة الفهم (دليل الصفحة) — إضافية
  window.scrollTo(0, 0);
}

/* ======================= حزمة ما تحت الصفر (المرحلة ١) ==================== */
let WZ = null, V3 = null;      // آخر نتيجة معالج + العارض

function pickPanel(u) {
  const p = document.getElementById('v3info');
  if (u && u.gk) labSelect(u);              // الضغط على عمود/جسر يختاره للتجربة
  if (!p) return;
  if (!u || !u.title) { p.innerHTML = '<h4>اضغط على أي عنصر</h4><div style="color:var(--mut)">لعرض تفاصيله'
    + ' — الطبقات والأسس والركائز والأعمدة</div>'; return; }
  p.innerHTML = `<h4>${u.title}</h4><table><tbody>${(u.rows || []).map(r =>
    `<tr><td style="color:var(--mut)">${r[0]}</td><td><b>${r[1]}</b></td></tr>`).join('')}</tbody></table>`;
  // دليل العنصر (إضافة): كيف حُسب + تفاصيل الحديد الكاملة وفحوص ACI 318-19
  try {
    if (window.DOSSIER && DOSSIER.supports(u)) {
      const b = document.createElement('button');
      b.className = 'btn dos-open'; b.type = 'button'; b.textContent = '📘 الدليل: كيف حُسب؟ وتفاصيل الحديد';
      b.onclick = () => DOSSIER.open(u);
      p.appendChild(b);
    }
  } catch (e) { console.error(e); }
}
let REBAR_ON = false, XRAY_ON = false, MOM_ON = false, PUN_ON = false, DEF_ON = false;
function mount3D(data, hostId) {
  const host = document.getElementById(hostId || 'v3d');
  const D = data || WZ;
  if (!host || !D) return;
  REBAR_ON = XRAY_ON = MOM_ON = PUN_ON = DEF_ON = HUM_ON = false;
  SOIL_ON = STRESS_ON = ADD_ON = false;
  V3 = Viewer3D(host, D, pickPanel);
  pickPanel(null);
  const sl = document.getElementById('v3clip');
  if (sl && V3) { sl.min = -V3.R * 1.5; sl.max = V3.R * 1.5; sl.value = V3.R * 1.5;
    sl.oninput = () => V3.clip(+sl.value); }
  $$('#v3groups input').forEach(c => { if (V3) V3.group(c.dataset.g, c.checked); });
}
/* ----- شريط حالة فوق المجسم: على أي شيء بُني هذا المبنى؟ ----- */
function planStrip() {
  const g = (WZ && WZ.grid) || null;
  if (!g) return '';
  const src = g.source || 'auto';
  if (src === 'frame' || src === 'plan') {
    const sp = (g.spans_x || []).slice(0, 5).map(v => nf(v, 2)).join(' / ');
    const sy = (g.spans_y || []).slice(0, 5).map(v => nf(v, 2)).join(' / ');
    return `<div class="pstrip on" id="pstrip">
      <span>📐 <b>مبني على مخططك</b>${PLD && PLD.name ? ': ' + PLD.name : ''} —
        <b>${int(g.cols)}</b> عمود · ${nf(WZ.footprint, 1)} م²${
        sp ? ' · بحور X ' + sp + ' م' : ''}${sy ? ' · Y ' + sy + ' م' : ''}${
        (WZ.model && WZ.model.stairs && WZ.model.stairs.flights || []).length
          ? ' · ' + (WZ.model.stairs.flights || []).length + ' قلبة درج' : ''}</span>
      <span class="sp"></span>
      <button class="btn gh" onclick="wtab('plan')">📐 تبويب الأوتوكاد</button>
      <button class="btn gh" onclick="clearPlanGrid()">↩️ رجّع التلقائي</button></div>`;
  }
  return `<div class="pstrip" id="pstrip">
    <span>الشبكة <b>تلقائية من المساحة</b> — ${int(g.cols)} عمود · ${g.nx} × ${g.ny} بحر
      بمسافة ${nf(g.sx, 2)} × ${nf(g.sy, 2)} م. ارفع مخطط DWG/DXF ليُبنى المشروع على أعمدتك الحقيقية.</span>
    <span class="sp"></span>
    <button class="btn" onclick="wtab('plan')">📐 الأوتوكاد</button></div>`;
}
/* ------- شريط أدوات المجسم: تعريف واحد يُستعمل بكل المساحات ------- */
function v3bar(o) {
  o = o || {};
  const fl = o.floors || 1;
  return planStrip() + `<div class="v3bar">
    <button onclick="V3&&V3.reset()">↻ إعادة الزاوية</button>
    <button onclick="V3&&V3.top()">⬓ مسقط علوي</button>
    <button onclick="V3&&V3.soffit()">⬒ بطن السقف</button>
    ${o.rebar === false ? '' : '<button id="btnRebar" onclick="toggleRebar()">🧵 إظهار التسليح</button>'}
    <button id="btnXray" onclick="toggleXray()">🩻 وضع الأشعة</button>
    ${o.analysis ? `<button id="btnMom" onclick="toggleMoments()">📈 العزوم</button>
      <select id="momMode" onchange="V3&&V3.fieldMode(this.value)" style="display:none">
        <option value="gov">الحاكم (الأكبر مطلقاً)</option>
        <option value="x">Mx — أسياخ باتجاه X</option>
        <option value="y">My — أسياخ باتجاه Y</option></select>
      <button id="btnPun" onclick="togglePunch()">🎯 قص الثقب</button>
      <button id="btnDef" onclick="toggleDefl()">〰️ الهطول</button>` : ''}
    <button id="btnHum" onclick="toggleHuman()">🧍 إنسان 1.85 م</button>
    <button id="btnPlan" onclick="togglePlan()">📐 مخطط DWG</button>
    <button id="btnSoil" onclick="toggleSoil()">🌍 التربة والطبقات</button>
    <button id="btnSite" onclick="toggleSite()">🏗️ وضع البناء</button>
    <button id="btnStress" onclick="toggleStress()">🎨 الشد والضغط</button>
    <button id="btnAdd" onclick="toggleAddCol()">➕ أضف عمود</button>
    <button id="btnLift" onclick="toggleAddLift()">🛗 أضف مصعد</button>
    <button onclick="V3&&V3.zoomSel()">🔍 تقريب المحدد</button>
    <button id="btnPerf" onclick="V3SET&&V3SET.toggle()"
      title="جودة الرسم والأداء — لا يغيّر التصميم">⚙️ العرض والأداء</button>
    <select id="v3floor" onchange="V3&&V3.floor(this.value==='all'?'all':+this.value)"
      style="width:auto;padding:5px 9px;font-size:11.5px">
      <option value="all">كل الطوابق</option>
      ${Array.from({ length: fl }, (_, i) => `<option value="${i + 1}">طابق ${i + 1}</option>`).join('')}
    </select></div>`;
}
const v3chips = list => list.map(([k, t, on]) =>
  `<label><input type="checkbox" data-g="${k}" ${on ? 'checked' : ''}
    onchange="V3&&V3.group('${k}',this.checked);refreshStats()"> ${t}</label>`).join('');
const v3legend = () => `<div class="legend"><span><i style="background:#e8443a"></i>أسياخ التسليح</span>
  <span><i style="background:#ff9f1c"></i>أتاري وأساور</span>
  <span><i style="background:#facc15"></i>كانتيليفر — علوي (شدّ)</span>
  <span><i style="background:#60a5fa"></i>كانتيليفر — سفلي (انكماش)</span>
  <span><i style="background:#22d3ee"></i>تسليح إضافي</span>
  <span><i style="background:#86efac"></i>كراسي</span>
  <span><i style="background:#c084fc"></i>دولات</span>
  <span><i style="background:#d9c08a"></i>بلوك الهوردي</span>
  <span><i style="background:#e8443a"></i>منطقة شدّ</span>
  <span><i style="background:#2f6fb8"></i>منطقة ضغط</span>
  <span><i style="background:#c9a86a"></i>تربة حاملة</span>
  <span><i style="background:#2f9bd8"></i>ماء جوفي</span>
  <span><i style="background:#a8bcd4"></i>سقوف</span><span><i style="background:#7f97b8"></i>جسور</span>
  <span><i style="background:#8ea6c4"></i>أعمدة</span><span><i style="background:#3f6fa5"></i>أساس</span></div>`;

/* ================== إضافة عمود بيدك من داخل المجسم ==================
   الفكرة كما طلبها المستخدم: مؤشّران يشتغلان مثل مؤشّر «قص المقطع» تماماً —
   الأول يحدّد X والثاني يحدّد Y، والنقطة (X , Y) هي **مركز العمود**.
   شبح أزرق شفاف يتحرك معهما بالمجسم فترى مكان العمود قبل تثبيته. */
const SHAPES = [['circ', 'دائري (O)'], ['sq', 'مربع'], ['rect', 'مستطيل'],
                ['L', 'زاوية (L)'], ['T', 'تي (T)']];
let ADD_ON = false;

function colExtent() {                      // مدى إحداثيات المشروع لضبط المؤشّرين
  const fr = WZ && WZ.model && WZ.model.frame;
  if (fr && fr.nodes && fr.nodes.length) {
    const xs = fr.nodes.map(n => n.x), ys = fr.nodes.map(n => n.y);
    const mx = Math.min(...xs), Mx = Math.max(...xs);
    const my = Math.min(...ys), My = Math.max(...ys);
    const pad = Math.max(1, (Mx - mx + My - my) / 20);
    return { x0: mx - pad, x1: Mx + pad, y0: my - pad, y1: My + pad, frame: true };
  }
  const g = (WZ && WZ.grid) || { L: 20, B: 12 };
  return { x0: -1, x1: g.L + 1, y0: -1, y1: g.B + 1, frame: false };
}

function addColPanel() {
  const e = colExtent(), st = Math.max(0.05, Math.round((e.x1 - e.x0) / 400 * 100) / 100);
  return `<div class="addbox" id="addbox" hidden>
    <div class="pdec-r">
      <b style="color:var(--acc)">➕ عمود جديد</b>
      <label>الشكل</label>
      <select id="ac_shape" onchange="acDims();acGhost()">
        ${SHAPES.map(([k, t]) => `<option value="${k}"${k === 'sq' ? ' selected' : ''}>${t}</option>`).join('')}
      </select>
      <span id="ac_dim"></span>
      <span class="sp"></span>
      <button class="btn" onclick="addColCommit()">✅ ثبّت العمود</button>
      <button class="btn gh" onclick="addColClear()">🗑️ امسح المضافة</button>
      <button class="btn gh" onclick="toggleAddCol()">إغلاق</button>
    </div>
    <div class="slider"><span style="font-size:11.5px;color:var(--mut);min-width:74px">↔️ المحور X</span>
      <input type="range" id="ac_x" min="${e.x0}" max="${e.x1}" step="${st}"
        value="${((e.x0 + e.x1) / 2).toFixed(2)}" oninput="acGhost()">
      <b id="ac_xv" style="color:var(--acc2);min-width:70px;font-size:12px"></b></div>
    <div class="slider"><span style="font-size:11.5px;color:var(--mut);min-width:74px">↕️ المحور Y</span>
      <input type="range" id="ac_y" min="${e.y0}" max="${e.y1}" step="${st}"
        value="${((e.y0 + e.y1) / 2).toFixed(2)}" oninput="acGhost()">
      <b id="ac_yv" style="color:var(--acc2);min-width:70px;font-size:12px"></b></div>
    <div class="note" id="ac_list"></div></div>`;
}

function acDims() {                          // حقول المقاس تتبع الشكل المختار
  const sh = txt('ac_shape'), e = $('#ac_dim');
  if (!e) return;
  e.innerHTML = sh === 'circ'
    ? `<label>القطر</label><input type="number" id="ac_D" value="500" step="50"
         style="width:90px;padding:5px 8px;font-size:11.5px" oninput="acGhost()"><span class="pdec-s">مم</span>`
    : `<label>المقطع</label><input type="number" id="ac_b" value="400" step="50"
         style="width:78px;padding:5px 8px;font-size:11.5px" oninput="acGhost()">
       <span class="pdec-s">×</span>
       <input type="number" id="ac_h" value="${sh === 'sq' ? 400 : 600}" step="50"
         style="width:78px;padding:5px 8px;font-size:11.5px" ${sh === 'sq' ? 'disabled' : ''}
         oninput="acGhost()"><span class="pdec-s">مم</span>`;
}

function acRead() {
  const sh = txt('ac_shape');
  const o = { x: +$('#ac_x').value, y: +$('#ac_y').value, shape: sh === 'sq' ? 'rect' : sh };
  if (sh === 'circ') { o.D = +($('#ac_D') || {}).value || 500; o.b = o.h = o.D; }
  else {
    o.b = +($('#ac_b') || {}).value || 400;
    o.h = sh === 'sq' ? o.b : (+($('#ac_h') || {}).value || o.b);
  }
  o.form = sh;
  return o;
}

function acGhost() {
  if (!V3 || !V3.ghost) return;
  const o = acRead();
  $('#ac_xv').textContent = nf(o.x, 2) + ' م';
  $('#ac_yv').textContent = nf(o.y, 2) + ' م';
  if ($('#ac_h')) $('#ac_h').disabled = (txt('ac_shape') === 'sq');
  V3.ghost(o);
}

function toggleAddCol() {
  const bx = $('#addbox');
  if (!bx) return;
  ADD_ON = !ADD_ON;
  bx.hidden = !ADD_ON;
  tgl('btnAdd', ADD_ON);
  if (ADD_ON) { acDims(); acGhost(); acList(); }
  else if (V3 && V3.ghost) V3.ghost(null);
}

function acList() {
  const e = $('#ac_list'), a = window.__added_cols || [];
  if (!e) return;
  e.innerHTML = a.length
    ? '<b>الأعمدة المضافة (' + a.length + '):</b> ' + a.map((c, i) =>
        `<span class="tag t-ok" style="cursor:pointer" onclick="acDrop(${i})">
          ${c.shape === 'circ' ? 'Ø' + int(c.D) : int(c.b) + '×' + int(c.h)}
          عند (${nf(c.x, 2)} , ${nf(c.y, 2)}) ✕</span>`).join(' ')
      + '<br>اضغط على أي واحد لحذفه ثم يُعاد التصميم.'
    : 'ما ثبّتّ أي عمود بعد — حرّك المؤشّرين لمكان العمود ثم اضغط «ثبّت العمود».';
}

async function addColCommit() {
  const o = acRead();
  window.__added_cols = (window.__added_cols || []).concat([
    { x: o.x, y: o.y, shape: o.shape, b: o.b, h: o.h, D: o.D || null }]);
  msgTop('➕ أُضيف عمود ' + (o.shape === 'circ' ? 'Ø' + int(o.D) : int(o.b) + '×' + int(o.h))
    + ' عند (' + nf(o.x, 2) + ' , ' + nf(o.y, 2) + ') — يُعاد بناء الهيكل…');
  await PAGES.wizard.run();
  setTimeout(() => { if (ADD_ON) { toggleAddCol(); toggleAddCol(); } showChange(); }, 400);
}

async function acDrop(i) {
  const a = window.__added_cols || [];
  a.splice(i, 1);
  window.__added_cols = a.length ? a : null;
  await PAGES.wizard.run();
  setTimeout(() => { if (ADD_ON) { toggleAddCol(); toggleAddCol(); } showChange(); }, 400);
}

async function addColClear() {
  if (!(window.__added_cols || []).length) return;
  window.__added_cols = null;
  await PAGES.wizard.run();
  setTimeout(() => { if (ADD_ON) { toggleAddCol(); toggleAddCol(); } showChange(); }, 400);
}

/* ================== إضافة مصعد — نواة قصّ لا فتحة ==================
   نفس آليّة إضافة العمود: مؤشّران لموضع مركز البئر، ثم إعادة تصميم كاملة.
   والفرق أن المصعد **يشارك بالمنشأ**: وزنه ينزل على الأساس، وجدرانه تجذب
   حصة من القوة الجانبية بنسبة صلابتها، وفتحته تقطع حديد كل سقف. */
let LIFT_ON = false;
const LIFT_CAPS = [[320, '320 كغم — 4 ركاب'], [450, '450 كغم — 6 ركاب'],
  [630, '630 كغم — 8 ركاب (الأشيع سكنياً)'], [800, '800 كغم — 10 ركاب'],
  [1000, '1000 كغم — 13 راكباً'], [1275, '1275 كغم — 17 راكباً']];

function addLiftPanel() {
  const e = colExtent(), st = Math.max(0.05, Math.round((e.x1 - e.x0) / 400 * 100) / 100);
  return `<div class="addbox" id="liftbox" hidden>
    <div class="pdec-r">
      <b style="color:var(--acc)">🛗 مصعد جديد</b>
      <label>العدد</label>
      <select id="lf_n" onchange="lfGhost()">
        <option value="1" selected>مصعد واحد — بئر واحد</option>
        <option value="2">مصعدان — بئران بنواة واحدة</option>
      </select>
      <label>السعة</label>
      <select id="lf_q" onchange="lfGhost()">
        ${LIFT_CAPS.map(([k, t]) => `<option value="${k}"${k === 630 ? ' selected' : ''}>${t}</option>`).join('')}
      </select>
      <label>سماكة الجدار</label>
      <input type="number" id="lf_t" value="200" step="25" min="150"
        style="width:78px;padding:5px 8px;font-size:11.5px" oninput="lfGhost()">
      <span class="pdec-s">مم</span>
      <span class="sp"></span>
      <button class="btn" onclick="addLiftCommit()">✅ ثبّت المصعد</button>
      <button class="btn gh" onclick="dropLift()">🗑️ احذف المصعد</button>
      <button class="btn gh" onclick="toggleAddLift()">إغلاق</button>
    </div>
    <div class="slider"><span style="font-size:11.5px;color:var(--mut);min-width:74px">↔️ المحور X</span>
      <input type="range" id="lf_x" min="${e.x0}" max="${e.x1}" step="${st}"
        value="${((e.x0 + e.x1) / 2).toFixed(2)}" oninput="lfGhost()">
      <b id="lf_xv" style="color:var(--acc2);min-width:70px;font-size:12px"></b></div>
    <div class="slider"><span style="font-size:11.5px;color:var(--mut);min-width:74px">↕️ المحور Y</span>
      <input type="range" id="lf_y" min="${e.y0}" max="${e.y1}" step="${st}"
        value="${((e.y0 + e.y1) / 2).toFixed(2)}" oninput="lfGhost()">
      <b id="lf_yv" style="color:var(--acc2);min-width:70px;font-size:12px"></b></div>
    <div class="note" id="lf_note"></div></div>`;
}
function lfRead() {
  const Q = +txt('lf_q') || 630;
  const sh = { 320: [1.50, 1.60], 450: [1.50, 1.75], 630: [1.60, 1.75],
               800: [1.80, 1.90], 1000: [1.90, 2.10], 1275: [2.00, 2.30] }[Q];
  return { Q: Q, x: +$('#lf_x').value, y: +$('#lf_y').value, n: +txt('lf_n') || 1,
           t: +($('#lf_t') || {}).value || 200, w: sh[0], h: sh[1] };
}
function lfGhost() {
  if (!V3 || !V3.ghost) return;
  const o = lfRead();
  $('#lf_xv').textContent = nf(o.x, 2) + ' م';
  $('#lf_yv').textContent = nf(o.y, 2) + ' م';
  const n = $('#lf_note');
  const wo = o.n * o.w + (o.n + 1) * o.t / 1000, ho = o.h + 2 * o.t / 1000;
  if (n) n.innerHTML = `${o.n === 1 ? 'بئر واحد' : '<b>بئران</b> جنباً إلى جنب يفصلهما جدار'}
    <b>${nf(o.w, 2)} × ${nf(o.h, 2)} م</b> داخلي للبئر، جدار <b>${int(o.t)} مم</b>،
    فالنواة <b>${nf(wo, 2)} × ${nf(ho, 2)} م</b> خارجياً. النواة تُبنى بكامل
    الارتفاع وتنزل بحفرة (Pit) تحت منسوب التأسيس.${o.n === 2 ? ` والمصعدان
    ليسا شكلين: العرض بالأُس الثالث بعزم القصور، فصلابة النواة باتجاه X تقفز
    وتجذب حصة أكبر من القوة الجانبية، ويتضاعف حمل الماكينة وصدم المصدّات،
    وتتّسع فتحة السقف فيزيد تطويقها.` : ''}
    حرّك المؤشّرين لمركز النواة ثم اضغط «ثبّت المصعد».`;
  V3.ghost({ x: o.x, y: o.y, shape: 'rect', b: wo * 1000, h: ho * 1000, form: 'rect' });
}
function toggleAddLift() {
  const bx = $('#liftbox');
  if (!bx) return;
  LIFT_ON = !LIFT_ON;
  bx.hidden = !LIFT_ON;
  tgl('btnLift', LIFT_ON);
  if (LIFT_ON) lfGhost(); else if (V3 && V3.ghost) V3.ghost(null);
}
async function addLiftCommit() {
  const o = lfRead();
  window.__elevator = o;
  msgTop('🛗 أُضيف ' + (o.n === 2 ? 'بنك مصعدين ' : 'مصعد ') + o.Q + ' كغم عند ('
    + nf(o.x, 2) + ' , ' + nf(o.y, 2)
    + ') — يُعاد التصميم بحمله وصلابته وفتحته…');
  await PAGES.wizard.run();
  setTimeout(() => { if (LIFT_ON) { toggleAddLift(); toggleAddLift(); } showChange(); }, 400);
}
async function dropLift() {
  if (!window.__elevator) return;
  window.__elevator = null;
  await PAGES.wizard.run();
  setTimeout(() => { if (LIFT_ON) { toggleAddLift(); toggleAddLift(); } showChange(); }, 400);
}

function msgTop(t) {
  const s2 = $('#pstrip');
  if (s2) { s2.classList.add('flash'); setTimeout(() => s2.classList.remove('flash'), 1600); }
  const e = $('#v3stats'); if (e) e.textContent = t;
}

function tgl(id, st) { const b = $('#' + id); if (b) b.classList.toggle('hot', st); }
let HUM_ON = false;
function toggleHuman() { if (!V3 || !V3.human) return; HUM_ON = !HUM_ON; V3.human(HUM_ON); tgl('btnHum', HUM_ON); }
let SOIL_ON = false;
/* ---- وضع البناء الواقعي: أرض وعشب وشدّة وطابوق وظلال شمس ----
   وشريط مراحل يمشي بترتيب التنفيذ لا بإظهار الطبقات. */
let SITE_ON = false, SITE_STEP = 0;
function toggleSite() {
  if (!V3) return;
  SITE_ON = !SITE_ON;
  V3.site(SITE_ON);
  tgl('btnSite', SITE_ON);
  const bar = $('#siteBar');
  if (bar) bar.hidden = !SITE_ON;
  // **يُفتح على المبنى المكتمل** لا على الأرض الفارغة. كان يبدأ من المرحلة
  // الأولى (أرض خضراء بلا شيء) فيبدو الزر معطّلاً — والمتوقّع من «وضع البناء»
  // أن يُظهر المشهد الواقعي أولاً، ثم يُرجعك بالمراحل إن أردت.
  if (SITE_ON) {
    const n = V3.movieScenes().filter(x => x.site).length;
    SITE_STEP = Math.max(0, n - 1);
    siteStep(0);
  } else { SITE_PLAY = 0; if (bar) bar.innerHTML = ''; }
}
let SITE_PLAY = 0;
function sitePlay() {
  if (!SITE_ON) return;
  if (SITE_PLAY) { clearInterval(SITE_PLAY); SITE_PLAY = 0; siteStep(0); return; }
  const n = V3.movieScenes().filter(x => x.site).length;
  SITE_STEP = 0; siteStep(0);
  SITE_PLAY = setInterval(() => {
    if (!SITE_ON || SITE_STEP >= n - 1) { clearInterval(SITE_PLAY); SITE_PLAY = 0; siteStep(0); return; }
    siteStep(1);
  }, 1700);
}
function siteGo(i) { if (!SITE_ON) return; SITE_STEP = +i; siteStep(0); }
function siteStep(d) {
  if (!V3 || !SITE_ON) return;
  const sc = V3.movieScenes().filter(x => x.site);
  SITE_STEP = Math.max(0, Math.min(sc.length - 1, SITE_STEP + d));
  const s = sc[SITE_STEP];
  V3.playScene(s, true);
  const bar = $('#siteBar');
  if (!bar) return;
  bar.innerHTML = `
    <button class="btn gh" onclick="siteStep(-1)" ${SITE_STEP ? '' : 'disabled'}>◀</button>
    <button class="btn ${SITE_PLAY ? '' : 'gh'}" onclick="sitePlay()"
      title="تشغيل مراحل البناء بالترتيب">${SITE_PLAY ? '⏸ إيقاف' : '▶ تشغيل'}</button>
    <div style="flex:1;min-width:0">
      <div style="font-size:13px;font-weight:700;color:var(--acc2)">${s.title}</div>
      <div style="font-size:11.5px;color:var(--mut)">${s.sub || ''}</div>
      <input type="range" min="0" max="${sc.length - 1}" value="${SITE_STEP}"
        oninput="siteGo(this.value)" style="width:100%;margin-top:5px">
    </div>
    <span style="font-size:11px;color:var(--mut);align-self:center">
      ${SITE_STEP + 1} / ${sc.length}</span>
    <button class="btn gh" onclick="siteStep(1)"
      ${SITE_STEP >= sc.length - 1 ? 'disabled' : ''}>▶</button>`;
}

function toggleSoil() {
  if (!V3 || !V3.soil) return;
  SOIL_ON = !SOIL_ON;
  const st = V3.soil(SOIL_ON);
  tgl('btnSoil', SOIL_ON);
  const so = WZ && WZ.soil, ew = WZ && WZ.earth;
  $('#v3stats').innerHTML = SOIL_ON && so
    ? `🌍 <b>${so.name}</b> (${so.kind_ar}) · تحمّل ${int(so.qa)} kPa · `
      + `قاع الأساس ${nf(so.found_bot, 2)} م · `
      + (so.gwt != null ? `💧 الماء الجوفي ${nf(so.gwt, 2)} م ` : 'بلا ماء جوفي مُدخل ')
      + (ew ? `· جلمود ${nf(ew.boulder, 1)} م³ (${ew.boulder_layers} طبقة) · `
            + `سبيس ${nf(ew.subbase, 1)} م³ (${ew.subbase_layers} طبقة)` : '')
    : '';
  if (SOIL_ON && !XRAY_ON) toggleXray();     // التربة تحت المبنى — تُرى بالأشعة
}
let STRESS_ON = false;
function toggleStress() {
  if (!V3 || !V3.stress) return;
  STRESS_ON = !STRESS_ON;
  const st = V3.stress(STRESS_ON);
  tgl('btnStress', STRESS_ON);
  $('#v3stats').innerHTML = STRESS_ON
    ? '<span style="color:#e8443a">🔴 شدّ</span> — الحديد يوضع هنا · '
      + '<span style="color:#2f6fb8">🔵 ضغط</span> — الخرسانة تكفي · '
      + int(st.n) + ' منطقة معروضة. وسط البحر: سفلي شدّ وعلوي ضغط · فوق المسند: بالعكس.'
    : '';
  if (STRESS_ON && !XRAY_ON) toggleXray();
}
let PLAN_ON = false;
function togglePlan() {
  if (!V3 || !V3.plan) return;
  if (!V3.planHas()) {
    if (!PLD) { wtab('plan'); return alert('ارفع مخطط DWG أو DXF أولاً من تبويب «📐 الأوتوكاد»'); }
    drawPlan();
  }
  PLAN_ON = !PLAN_ON; V3.plan(PLAN_ON); tgl('btnPlan', PLAN_ON);
  if (PLAN_ON && !XRAY_ON) toggleXray();   // وإلا خبّأته السقوف المصمتة
}
function toggleMoments() { if (!V3) return; MOM_ON = !MOM_ON; V3.moments(MOM_ON); tgl('btnMom', MOM_ON);
  const sel = $('#momMode'); if (sel) sel.style.display = MOM_ON ? '' : 'none';
  if (MOM_ON && !XRAY_ON) toggleXray(); }
function togglePunch() { if (!V3) return; PUN_ON = !PUN_ON; V3.punch(PUN_ON); tgl('btnPun', PUN_ON); }
function toggleDefl() { if (!V3) return; DEF_ON = !DEF_ON; V3.defl(DEF_ON); tgl('btnDef', DEF_ON); }
function toggleRebar() {
  if (!V3) return;
  REBAR_ON = !REBAR_ON;
  const t0 = performance.now();
  const st = V3.rebar(REBAR_ON);
  const b = $('#btnRebar');
  b.classList.toggle('hot', REBAR_ON);
  b.textContent = REBAR_ON ? '🧵 إخفاء التسليح' : '🧵 إظهار التسليح';
  if (REBAR_ON && !XRAY_ON) toggleXray();
  if (REBAR_ON) $('#v3stats').innerHTML =
    `${int(st.bars)} سيخ معروض · ${nf(st.weight / 1000, 1)} طن حديد · ${nf(performance.now() - t0, 0)} مللي ثانية`;
  else $('#v3stats').textContent = '';
}
function refreshStats() {
  if (!V3 || !REBAR_ON) return;
  const st = V3.stats();
  $('#v3stats').innerHTML = `${int(st.bars)} سيخ معروض · ${nf(st.weight / 1000, 1)} طن حديد`;
}
function toggleXray() {
  if (!V3) return;
  XRAY_ON = !XRAY_ON; V3.xray(XRAY_ON);
  $('#btnXray').classList.toggle('hot', XRAY_ON);
}
function sectionSVG2(ew) {
  const st = ew.stack.slice().sort((a, b) => a.bottom - b.bottom);
  const lo = Math.min(...st.map(s => s.bottom)), hi = Math.max(...st.map(s => s.top));
  const W = 900, H = Math.max(300, 46 * st.length), ml = 210, mr = 200, mt = 24;
  const Y = v => mt + (hi - v) / (hi - lo || 1) * (H - mt - 20);
  let g = '';
  st.forEach(s => {
    const y1 = Y(s.top), y2 = Y(s.bottom);
    g += `<rect x="${ml}" y="${y1}" width="${W - ml - mr}" height="${Math.max(2, y2 - y1)}"
      fill="${s.color}" stroke="#0b1220" stroke-width="1"/>
      <text x="${ml - 8}" y="${(y1 + y2) / 2 + 4}" fill="#e6edf7" font-size="11" text-anchor="end">${s.name}</text>
      <text x="${W - mr + 8}" y="${(y1 + y2) / 2 + 4}" fill="#93a4c0" font-size="10.5">${s.t.toFixed(2)} م${
        s.layers ? ' · ' + s.layers + ' طبقة' : ''} · ${s.volume.toFixed(1)} م³</text>`;
  });
  const mark = (v, t, c) => `<line x1="${ml - 60}" x2="${W - mr}" y1="${Y(v)}" y2="${Y(v)}" stroke="${c}"
    stroke-dasharray="5 3"/><text x="${ml - 64}" y="${Y(v) - 3}" fill="${c}" font-size="10.5" text-anchor="end">${t} (${v >= 0 ? '+' : ''}${v.toFixed(2)})</text>`;
  g += mark(ew.levels.bm, 'منسوب التشطيب BM', '#34d399');
  g += mark(ew.levels.ground, 'الأرض الطبيعية', '#fbbf24');
  if (Math.abs(ew.levels.existing - ew.levels.ground) > 0.01) g += mark(ew.levels.existing, 'قعر الهدم القديم', '#f87171');
  g += mark(ew.levels.found_bot, 'قاعدة الأساس', '#38bdf8');
  return `<svg viewBox="0 0 ${W} ${H}" class="sect">${g}</svg>`;
}

/* ---------- لوحة «التسليح والتفاصيل» داخل مساحة العمل ---------- */
function detailPanel(r) {
  return `
    <div class="grid g2" style="margin-top:16px">
      <div class="card"><h3>قص الثقب (Punching Shear) عند الأعمدة</h3>
        ${table(['العمود', 'الموقع', 'b0 (مم)', 'd (مم)', 'Vu (kN)', 'φVc (kN)', 'النسبة', 'الحالة'],
          r.punching.slice(0, 12).map((q, i) => ['C' + (i + 1), q.kind, int(q.found.b0), int(q.found.d),
            nf(q.found.Vu, 0), nf(q.found.phiVc, 0),
            `<b style="color:${rcol(q.found.ratio)}">${nf(q.found.ratio, 2)}</b>`,
            q.found.ok ? '<span class="tag t-ok">مقبول</span>' : '<span class="tag t-bad">راجع</span>']))}
        <div class="note">الفحص عند ${r.punching[0].found.where} وفق ACI 22.6 — المقطع الحرج على d/2 من وجه العمود.
          ${r.punching.every(q => q.found.ok) ? 'كل الأعمدة مقبولة.' : r.punching.find(q => !q.found.ok).found.rec}
          <br>عند السقف: النظام جسور-بلاطة فالحمل ينتقل عبر الجسور، والقيمة المعروضة للاستئناس فقط.</div></div>
      <div class="card"><h3>الكراسي والوصلات والبسكويت</h3>
        ${table(['البند', 'التفصيل'], [
          ['كراسي السقف', r.chairs.slab.label + ' — عدد ' + int(r.chairs.slab.n * r.model.floors)],
          ['وزن كراسي السقوف', nf(r.chairs.slab.weight * r.model.floors, 2) + ' طن'],
          ['كراسي الأساس', r.chairs.found.n
            ? r.chairs.found.label + ' — عدد ' + int(r.chairs.found.n)
            : 'لا كراسي — القاعدة بلا شبكة علوية تُحمَل'],
          ['بسكويت الغطاء السفلي', int(r.chairs.slab.spacers * r.model.floors) + ' قطعة'],
          ['طول السيخ بالسوق', nf(r.model.stock, 0) + ' م — كل ما زاد يُقطّع ويُوصل'],
          ['عكفة بداية السيخ', '<b>20 سم</b> — تُثنى ببداية كل سيخ مستقيم ومضافة لطول القطع بالجدول']].concat(
          Object.entries(r.laps).map(([db, v]) => ['وصلة Ø' + db,
            '<b>' + nf(v.bottom, 2) + ' م</b> — كودية ' + nf(v.code, 2) + ' م · 60·db = ' + nf(v.site, 2) + ' م'])))}
        <div class="note">القاعدة المعتمدة: <b>${r.detail.lap.label}</b> ·
          الكودية = صنف B (1.3·ld) وفق ACI 25.5.2.1 · وصلات الأعمدة فوق كل سقف ومتبادلة 50% ·
          <b>عكفة البداية 20 سم</b> مضافة لكل سيخ مستقيم بجدول التقطيع (الأساور والكراسي
          والحلزون شكلها المغلق يحوي عكفاته أصلاً فلا تُضاف لها).</div></div>
    </div>

    <div class="grid g2" style="margin-top:16px">
      <div class="card"><h3>📏 الغطاء الخرساني (Concrete Cover)</h3>
        ${table(['العنصر', 'الغطاء (مم)'], [
          ['السقف — الوجهان', int(r.detail.covers.slab)],
          ['الجسور (للأساور)', int(r.detail.covers.beam)],
          ['الأعمدة (للأتاري)', int(r.detail.covers.column)],
          ['الأساس — الوجه السفلي على التربة', int(r.detail.covers.footing_bottom)],
          ['الأساس — الوجه العلوي', int(r.detail.covers.footing_top)]])}
        ${table(['جدول ACI 318-19 (20.5.1.3)', 'مم', 'المرجع'],
          r.detail.covers.table.map(c => [c.name, int(c.v), c.ref]))}
        <div class="note">القاعدة العملية بالموقع: البوتوم 5–7.5 سم (على التربة) والتوب 3–5 سم —
          وهي مطابقة لجدول الكود أعلاه.</div></div>

      <div class="card"><h3>✂️ نقاط قطع وثني الحديد بالجسور</h3>
        ${['x', 'y'].map(d => { const t = r.detail.curtail[d]; return `
        <h4 style="margin:10px 0 4px">جسور الاتجاه ${d.toUpperCase()} — البحر ${nf(t.span, 2)} م
          (Ln = ${nf(t.ln, 2)} م)</h4>
        ${table(['البند', 'القيمة'], [
          ['علوي — الطبقة الأولى', 'L/3 = ' + nf(t.top1, 2) + ' م لكل جهة · طول السيخ ' + nf(t.top1_len, 2) + ' م'],
          ['علوي — الطبقة الثانية', 'L/5 = ' + nf(t.top2, 2) + ' م · طول السيخ ' + nf(t.top2_len, 2) + ' م'],
          ['نقطة الثني', 'L/7 = ' + nf(t.bend_at, 2) + ' م من وجه المسند'],
          ['الأسياخ المثنية', t.bent ? t.n_bent + ' سيخ بزاوية 45° — ' + t.bar.label : 'بدون ثني'],
          ['عكفة الأساور', t.hook_stirrup.label + ' (نصف قطر ثنية ' + int(t.hook_stirrup.bend_r) + ' مم)'],
          ['الوصلات', 'سفلي ' + nf(t.lap_bottom, 2) + ' م · علوي ' + nf(t.lap_top, 2) + ' م'],
          ['الغطاء', int(t.cover) + ' مم']])}`; }).join('')}
        <div class="note">${r.detail.curtail.x.rows.map(x => x[0] + ': ' + x[1]).join(' · ')}</div></div>

      <div class="card"><h3>🧱 ترتيب نشر حديد السقف (فرش ثم غطاء)</h3>
        ${table(['الطبقة', 'التسليح', 'العمق الفعّال d', 'العدد', 'طول السيخ', 'التقطيع'],
          r.model.slab.layout.map(l => [l.name, 'Ø' + l.db + ' @ ' + int(l.s) + ' مم',
            l.d ? int(l.d) + ' مم' : '—', '<b>' + int(l.n) + '</b> سيخ', nf(l.length, 2) + ' م',
            l.pieces > 1 ? l.pieces + ' قطعة' : 'قطعة واحدة']))}
        <div class="note">العدد = ⌈العرض ÷ التباعد⌉ + 1 — نفس طريقة التنفيذ بالموقع.
          الفرش هو الاتجاه القصير ويوضع أولاً (أكبر عمق فعّال)، والغطاء فوقه بالاتجاه الطويل.
          <br>التسليح العلوي فوق الأعمدة والمساند فقط ويمتد L/4 لكل جهة —
          طول السيخ ${nf(r.model.slab.top_len.x, 2)} م بالاتجاه X و ${nf(r.model.slab.top_len.y, 2)} م بالاتجاه Y.</div></div>

      <div class="card"><h3>🔩 الدولات (Dowel Bars) — ربط العمود بالأساس</h3>
        ${table(['البند', 'القيمة'], r.detail.dowels.rows.map(x => [x[0], x[1]]))}
        ${r.detail.dowels.warn ? `<div class="note" style="border-color:#f87171;color:#fca5a5">
          ⚠️ ${r.detail.dowels.warn} — قاعدة 16·db أقصر من الحد الكودي؛ إما تزاد لـ
          ${int(r.detail.dowels.ldc)} مم أو تُستعمل عكفة 90° بقاع الأساس.</div>`
          : '<div class="note">الدفن مطابق للحد الكودي ✓</div>'}</div>
    </div>

    <div class="grid g2" style="margin-top:16px">
      <div class="card"><h3>🏛️ تصنيف الأعمدة واستمراريتها</h3>
        <div style="max-height:320px;overflow:auto">${table(
          ['العمود', 'المحور', 'الموقع', 'استمرارية X', 'استمرارية Y', 'Pu (kN)'],
          r.detail.cols.map((c, i) => ['C' + (i + 1), '(' + c.i + ', ' + c.j + ')',
            `<span class="tag ${c.kind === 'داخلي' ? 't-ok' : 't-warn'}">${c.kind}</span>`,
            c.cont_x ? 'مستمر' : 'طرفي', c.cont_y ? 'مستمر' : 'طرفي', int(c.Pu)]))}</div>
        <div class="note">العمود الركني والجار (الحافة) يتلقّى عزماً غير متوازن من جهة واحدة، فيحتاج
          تسليحاً علوياً أطول بالجسر الطرفي وتطويقاً أشد — بينما العمود الداخلي عزومه متوازنة.
          <br>نقاط قطع الحديد L/3 و L/5 والثني L/7 مطبّقة على كل الجسور أعلاه.</div></div>

      <div class="card"><h3>🏗️ نوع السقف — المختار والبدائل</h3>
        ${table(['النوع', 'المدى المناسب', 'الملاحظة', ''], r.slab.types.map(t =>
          [t.name, t.span, t.note, t.chosen ? '<span class="tag t-ok">المختار ✓</span>' : '']))}
        <div class="note"><b>التوصية:</b> ${r.slab.recommend.options.map(o => o.name + ' — ' + o.why).join(' · ')}
          <br>المختار: <b>${r.model.slab.name}</b> بسماكة ${int(r.model.slab.h)} مم ووزن ذاتي
          ${nf(r.floor.slab_sw, 2)} kN/m².
          <button class="btn gh" style="margin-top:8px" onclick="wtab('slabs')">قارن كل الأنواع بالتفصيل</button></div></div>
      ${barMapPanel(r)}
      ${beamTypePanel(r)}
      ${liftPanel(r)}
      ${fieldPanel(r)}
      ${extraPanel(r)}
      ${tiePanel(r)}
      ${beamRebarPanel(r)}
      ${cantiPanel(r)}
      ${pilePanel(r)}
      ${stairPanel(r)}
    </div>
`;
}

/* ---------- الدرج وتسليحه — أخطر تفصيل بالمبنى يُنفَّذ خطأً ---------- */
function stairPanel(r) {
  const SP = r.stairs;
  if (!SP || !(SP.flights || []).length)
    return `<div class="card"><h3>🪜 الدرج وتسليحه</h3>
      <div class="note">لا يوجد درج بالمشروع — يُستخرج من المخطط (DWG) تلقائياً
        عند رفعه، أو يُضاف من بطاقة المخطط.</div></div>`;
  const f = SP.flights[0], R2 = f.rebar;
  if (!R2) return '';
  const bar = (x, col) => `<div style="padding:9px 11px;background:${col}22;
    border-right:3px solid ${col};border-radius:8px;margin-bottom:7px">
    <b style="color:${col}">${x.name}</b>
    <div style="font-size:17px;font-weight:700;margin:3px 0">${x.label ||
      ('Ø' + x.db + (x.s ? ' @ ' + Math.round(x.s) + ' مم' : ''))}</div>
    <div style="font-size:11.5px;color:var(--mut);line-height:1.75">${x.note}</div></div>`;
  return `
    <div class="card"><h3>🪜 الدرج وتسليحه — قلبة ${SP.flights.length > 1 ?
      '(' + SP.flights.length + ' قلبات)' : ''}</h3>
      <div class="grid g4">
        ${kpi('الدرجات', f.steps + ' × ' + (f.rise * 100).toFixed(0) + '/' +
          (f.tread * 100).toFixed(0) + ' سم')}
        ${kpi('زاوية الميل', nf(f.angle, 1) + '°')}
        ${kpi('سماكة الوِتر', int(f.waist) + ' مم')}
        ${kpi('البحر', nf(f.span, 2) + ' م')}</div>
      <div class="grid g2" style="margin-top:12px;gap:10px">
        <div>${bar(R2.main, '#e8443a')}${bar(R2.dist, '#22d3ee')}</div>
        <div>${bar(R2.top, '#ff9f1c')}${bar(R2.starter, '#c084fc')}</div></div>
      <div class="rec" style="margin:4px 0 12px;border-right:3px solid #f87171">
        <h3 style="margin-top:0">⚠️ الانكسار — القاعدة التي تُعكس بالموقع</h3>
        ${R2.corners.map(c2 => `<div style="margin:8px 0;font-size:13px;line-height:1.9">
          <b style="color:${c2.kind === 're' ? '#f87171' : 'var(--ok)'}">${c2.name}</b><br>
          ${c2.rule}<br><span style="color:var(--mut)">${c2.why}</span></div>`).join('')}
      </div>
      ${table(['البند', 'القيمة', 'المرجع'], [
        ['طول الرباط ld', int(R2.ld) + ' مم', 'ACI 25.4.2'],
        ['طول الوصلة (صنف B)', nf(R2.lap.len, 2) + ' م', 'ACI 25.5.2.1'],
        ['موضع الوصلة', R2.lap.note, 'ACI 25.5.2.1'],
        ['العكفة', R2.hook.label, 'ACI جدول 25.3.1'],
        ['أساور الربط', R2.stirrup.label, R2.stirrup.why],
        ['طول الحديد العلوي', nf(R2.top.zone, 2) + ' م لكل جهة من الانكسار', 'عزم سالب موضعي'],
      ])}
      ${table(['بند التصميم', 'القيمة'], f.rows.map(x => [x[0], x[1]]))}
      <div class="note">شغّل <b>«التسليح»</b> بالمجسم وقرّب على الدرج: الرئيسي
        <b style="color:#e8443a">أحمر سفلي</b> على الميل · التوزيع
        <b style="color:#22d3ee">سماوي</b> فوقه · الشنّاطات
        <b style="color:#ff9f1c">برتقالية علوية</b> عند الانكسارين · أسياخ الانتظار
        <b style="color:#c084fc">بنفسجية</b> من البسطة.</div></div>`;
}

/* ---------- تركيب الكانات والأتاري: ماذا تفعل ولماذا هي هنا بالذات ---------- */
function tiePanel(r) {
  const cr = r.model.col.rebar, br = (r.aci_extra && r.aci_extra.beam_rules) || null;
  const sup = cr.support || {}, tr = cr.tie_rule || {}, hk = cr.tie_hook || {};
  const ct = br && br.rows[0] ? br.rows[0].crosstie : null;
  return `
    <div class="card"><h3>🌀 تركيب الكانات والأتاري — ولماذا هي هنا بالذات</h3>
      <div class="rec" style="margin:0 0 12px">
        <h3 style="margin-top:0">الأسوار لا توضع «لتربط الحديد»</h3>
        <div style="font-size:13px;line-height:1.9">هذا أشيع سوء فهم بالموقع. للأسوار
          <b>ثلاث وظائف إنشائية</b>، والربط ليس منها:
          <ol style="padding-right:20px;margin:8px 0">
            <li><b>تحمل القص</b> — الشقّ القطري يميل 45° فيقطع الأسوار، وكل سوار
              يعبره يشدّ ويمنع انفتاحه. ولهذا يُحسب تباعدها من Vs لا بالتقدير.</li>
            <li><b>تحصر لبّ الخرسانة</b> — الخرسانة المحصورة تتحمّل أكثر وتنضغط
              أطول قبل أن تنهار. هذا مصدر <b>مطاوعة</b> العمود بالزلزال كلها.</li>
            <li><b>تمنع انبعاج السيخ الطولي</b> — بعد انقشار الغطاء يصير السيخ
              عموداً نحيلاً حرّاً؛ السوار يقصّر طوله الحرّ فلا ينبعج. وهذه الوظيفة
              هي سبب المادة 25.7.2.3 كلها.</li>
          </ol>
          والوظيفة الثالثة تفسّر لماذا لا يكفي سوار محيطي وحده كلما كبر المقطع.</div></div>

      <h4 style="margin:12px 0 6px;color:var(--mut);font-size:13px">أولاً — أين تُوضع وبأي تباعد</h4>
      ${table(['العنصر', 'الموضع', 'التباعد', 'البند والسبب'], [
        ['العمود — المنطقة الحرجة',
         'على مسافة ℓo من كل طرف (أعلى وأسفل كل طابق)',
         '<b>' + (cr.conf_label || '').replace('تطويق ', '') + '</b>',
         'ACI 18.7.5 — طرفا العمود هما موضع المفصل اللدن بالزلزال، فالتطويق يُكثَّف هناك'],
        ['العمود — الوسط', 'ما بين المنطقتين الحرجتين',
         '<b>Ø' + cr.tie_db + ' @ ' + int(cr.tie_s) + ' مم</b>',
         'ACI 25.7.2.1(ب) — ' + (tr.note || '')],
        ...(br ? br.rows.map(b => ['جسر ' + b.beam + ' — المنطقة الحرجة',
          '2h = ' + (2 * b.h / 1000).toFixed(2) + ' م من وجه كل مسند',
          '<b>≤ min(d/4 , 8db , 24db الأسوار , 300) </b>',
          'ACI 18.6.4 — المفصل اللدن بالجسر يتكوّن عند وجه العمود']) : []),
        ...(br ? br.rows.map(b => ['جسر ' + b.beam + ' — الوسط', 'باقي البحر',
          '<b>' + b.stirrup.label + '</b>',
          'ACI 9.7.6.2.2 — ≤ d/2 (و d/4 عند القص العالي) وبحدّ 600 مم']) : []),
      ])}

      <h4 style="margin:14px 0 6px;color:var(--mut);font-size:13px">ثانياً — لماذا العكفة 135° لا 90°</h4>
      ${table(['البند', 'التفصيل'], [
        ['هندسة العكفة الزلزالية', '<b>' + (hk.label || '') + '</b> — ACI جدول 25.3.2'],
        ['الشرط الأول (25.3.4أ)', 'ثني <b>≥ 135°</b> لكل الأسوار غير الدائرية · و90° للحلزون الدائري'],
        ['الشرط الثاني (25.3.4ب)', 'العكفة <b>تلتفّ على سيخ طولي</b> — لا تُثنى بالهواء'],
        ['الشرط الثالث (25.3.4ب)', 'الامتداد يتّجه إلى <b>داخل</b> السوار لا خارجه'],
        ['لماذا', 'الغطاء الخرساني ينقشر أول ما يصل العمود لحدّه. العكفة 90° ' +
          'يمسكها الغطاء وحده، فتنفتح بمجرد انقشاره ويتحرّر السوار كله. ' +
          'العكفة 135° مثنية <b>داخل اللبّ المحصور</b> فتبقى ممسوكة بعد انقشار الغطاء.'],
        ['بالمجسم', 'العكفتان مرسومتان بركنين <b>متقابلين قطرياً</b> لا بركن واحد — ' +
          'فلو انفتحت واحدة بقيت الأخرى تمسك اللبّ. شغّل «التسليح» وقرّب على أي عمود لتراهما.'],
      ])}

      <h4 style="margin:14px 0 6px;color:var(--mut);font-size:13px">ثالثاً — الأتاري الداخلية: متى تلزم فعلاً</h4>
      ${table(['الاتجاه', 'عدد الأسياخ بالوجه', 'الخلوص بينها', 'أتاري مطلوبة', 'لماذا'], [
        ['أفقي (عرض العمود)', (sup.x && sup.x.bars) || '—',
         sup.x ? Math.round(sup.x.gap) + ' مم' : '—',
         '<b>' + ((sup.x && sup.x.n) || 0) + '</b>', (sup.x && sup.x.why) || ''],
        ['رأسي (عمق العمود)', (sup.y && sup.y.bars) || '—',
         sup.y ? Math.round(sup.y.gap) + ' مم' : '—',
         '<b>' + ((sup.y && sup.y.n) || 0) + '</b>', (sup.y && sup.y.why) || ''],
      ])}
      <div class="note">قاعدة ACI 25.7.2.3 بنصّها: <b>كل سيخ ركني وكل سيخ بديل</b> يجب أن
        يُسنَد بركن أسوار بزاوية داخلية ≤ 135°، <b>ولا يبعد أي سيخ غير مسنود أكثر من
        150 مم خلوصاً</b> عن سيخ مسنود. فحين تكون الأسياخ متقاربة (الخلوص ≤ 150 مم)
        <b>لا تلزم أتاري إطلاقاً</b> — والبرنامج يحسب الخلوص الفعلي بدل أن يفرضها
        بقاعدة تقريبية. ${ct ? '<br>وشكل الأتاري نفسه محكوم بالمادة 25.3.5: <b>' +
        ct.label + '</b>. ' + ct.why : ''}</div>

      <h4 style="margin:14px 0 6px;color:var(--mut);font-size:13px">رابعاً — قطر الأسوار</h4>
      ${table(['القاعدة', 'المطلوب', 'المستعمل'], [
        ['ACI 25.7.2.2', 'Ø10 للأسياخ الطولية Ø32 فأصغر · Ø13 لـ Ø36 فأكبر أو المحزومة',
         '<b>Ø' + cr.tie_db + '</b> (الأدنى المطلوب Ø' + (cr.tie_db_min || 10) + ')'],
        ['ACI 25.7.2.1(أ)', 'الخلوص الصافي ≥ (4/3)·مقاس الركام الأكبر',
         tr.clear_min ? '≥ ' + Math.round(tr.clear_min) + ' مم' : '—'],
      ])}</div>`;
}

/* ---------- تسليح الجسور: أين يُقطع وأين يُوصَل وأين يُمنع ---------- */
function beamRebarPanel(r) {
  const br = r.aci_extra && r.aci_extra.beam_rules;
  if (!br) return '';
  const y = ok => ok ? '<span class="tag t-ok">مطابق</span>' : '<span class="tag t-bad">راجع</span>';
  return `
    <div class="card"><h3>🧵 تسليح الجسور — أين يُقطع السيخ وأين يُوصَل وأين يُمنع</h3>
      ${br.rows.map(b => `
        <h4 style="margin:10px 0 6px;color:var(--acc2);font-size:13.5px">جسر ${b.beam}
          — ${int(b.b)}×${int(b.h)} مم · بحر ${nf(b.span, 2)} م (صافي ${nf(b.ln, 2)} م)
          · ${b.top.label} علوي · ${b.bottom.label} سفلي</h4>
        ${table(['البند', 'القاعدة', 'القيمة المحسوبة'], [
          ['9.7.3.3', 'يمتد السيخ بعد نقطة عدم الحاجة إليه = الأكبر من d و12db',
           '<b>' + nf(b.cut.ext_top, 2) + ' م</b> علوي · ' + nf(b.cut.ext_bot, 2) + ' م سفلي'],
          ['9.7.3.4', 'الحديد المستمر يمتد ld كاملاً بعد نقطة قطع جاره',
           '<b>' + nf(b.cut.ld_top, 2) + ' م</b> علوي · ' + nf(b.cut.ld_bot, 2) + ' م سفلي'],
          [b.cut.pos_into.clause, 'ما يدخل من الحديد السفلي بالمسند', b.cut.pos_into.rule],
          ['9.7.3.8.4', 'ما يتجاوز من الحديد العلوي نقطة الانقلاب',
           '<b>' + b.cut.neg_third.n + ' سيخ</b> — ' + b.cut.neg_third.rule],
          ['9.7.3.5', '<b>يُمنع</b> إنهاء حديد الشدّ بمنطقة شدّ',
           '<span style="font-size:11.5px">' + b.cut.no_cut_tension.rule + '</span>'],
        ])}
        <div class="rec" style="margin:10px 0">
          <h3 style="margin-top:0">🚫 أين يُمنع وصل حديد هذا الجسر — ACI 18.6.3.3</h3>
          <div style="font-size:13px;line-height:1.9">
            يُمنع التراكب: <b>داخل العقدة</b> · وبمسافة <b>2h = ${nf(2 * b.h / 1000, 2)} م</b>
            من وجه العقدة · وبمسافة 2h من أي مقطع يُتوقّع فيه خضوع انحنائي.<br>
            <b style="color:${b.splice.ok ? 'var(--ok)' : '#f87171'}">${b.splice.label}</b><br>
            ${b.splice.ok ? 'وتُطوَّق منطقة الوصل بكانات تباعدها ≤ الأصغر من d/4 و100 مم = <b>' +
              Math.round(b.splice.s_hoop) + ' مم</b>.' : ''}
            <div style="margin-top:8px;padding:8px;background:#7f1d1d22;border-radius:6px">
              <b>هذا البند يُخالَف بالموقع دائماً:</b> الوصلة تُوضع «فوق العمود» لأنه
              أسهل — وهو <b>بالضبط</b> المكان الممنوع، لأن العزم السالب أقصى ما يكون هناك
              وهناك يُتوقّع خضوع الحديد. ${b.splice.why}</div>
            ${spliceBar(b)}
          </div></div>
        ${table(['البند', 'الفحص الزلزالي (18.6.3)', 'المحسوب', 'الحدّ', ''],
          b.seismic.rows.map(x => ['<code style="color:var(--acc2)">' + x.clause + '</code>',
            x.name, (x.fmt ? nf(x.val, 4) : (x.unit === 'سيخ' ? x.val : int(x.val))) + ' ' + x.unit,
            (x.ge ? '≥ ' : '≤ ') + (x.fmt ? nf(x.lim, 4) : int(x.lim)) + ' ' + x.unit, y(x.ok)]))}
        <div class="note">${b.seismic.why}</div>
        ${table(['العكفة', 'الهندسة', 'الطول المضاف للقصّ'], [
          ['حديد الجسر Ø' + b.top.db + ' — عكفة 90°', b.hook_bar.label,
           '<b>' + Math.round(b.hook_bar.added) + ' مم</b> (قوس ' + Math.round(b.hook_bar.arc) +
           ' + امتداد ' + Math.round(b.hook_bar.ext) + ')'],
          ['الأسوار Ø' + b.stirrup.db + ' — عكفة زلزالية 135°', b.hook_tie.label,
           '<b>' + Math.round(b.hook_tie.added) + ' مم</b> لكل عكفة × عكفتين'],
        ])}`).join('<hr style="border:none;border-top:1px solid var(--bd);margin:16px 0">')}
      <div class="note">طول العكفة المضاف = <b>طول القوس على محور السيخ</b> + الامتداد
        المستقيم — لا الامتداد وحده كما يُحسب بالموقع. وهو مضاف فعلاً لأطوال القطع
        بجدول التقطيع.</div></div>`;
}

/* شريط بصري لمنطقة الوصل المسموحة على طول البحر */
function spliceBar(b) {
  if (!b.splice.ok) return `<div style="margin-top:10px;height:26px;border-radius:6px;
    background:repeating-linear-gradient(45deg,#7f1d1d,#7f1d1d 8px,#991b1b 8px,#991b1b 16px);
    display:flex;align-items:center;justify-content:center;color:#fecaca;font-size:11.5px">
    البحر كله منطقة منع — لا وصلة مسموحة</div>`;
  const a = (b.splice.zone[0] / b.span) * 100, c = (b.splice.zone[1] / b.span) * 100;
  return `<div style="margin-top:10px">
    <div style="position:relative;height:26px;border-radius:6px;overflow:hidden;
      background:repeating-linear-gradient(45deg,#7f1d1d,#7f1d1d 8px,#991b1b 8px,#991b1b 16px)">
      <div style="position:absolute;left:${a}%;width:${c - a}%;top:0;bottom:0;
        background:#065f46;display:flex;align-items:center;justify-content:center;
        color:#a7f3d0;font-size:11px;font-weight:700">وصل مسموح</div></div>
    <div style="display:flex;justify-content:space-between;font-size:10.5px;color:var(--mut);margin-top:3px">
      <span>مركز المسند 0.00</span><span>وسط البحر ${nf(b.span / 2, 2)} م</span>
      <span>المسند التالي ${nf(b.span, 2)} م</span></div></div>`;
}

/* ---------- الكانتيليفر ---------- */
function cantiPanel(r) {
  const c = r.canti;
  if (!c) return '';
  if (!c.on) return `<div class="card"><h3>📐 الكانتيليفر (الشناشيل والبلكونات)</h3>
    <div class="note">${c.note}</div></div>`;
  const y = ok => ok ? '<span class="tag t-ok">مطابق</span>' : '<span class="tag t-bad">راجع</span>';
  return `
    <div class="card"><h3>📐 الكانتيليفر — الشناشيل والبلكونات</h3>
      <div class="grid g4">
        ${kpi('البروز', nf(c.L, 2) + ' م')}
        ${kpi('عدد الجهات', c.items.length)}
        ${kpi('المساحة', nf(c.area, 1) + ' م²')}
        ${kpi('المطابقة', c.ok ? 'مطابق ✓' : 'راجع', c.ok ? 'ok' : 'bad')}</div>
      ${c.items.map(i => `
        <h4 style="margin:12px 0 6px;color:var(--acc2);font-size:13.5px">${i.side_name}
          — سماكة ${int(i.h)} مم · Mu ${nf(i.Mu, 1)} kN·م/م · Vu ${nf(i.Vu, 1)} kN/م</h4>
        <div class="grid g2" style="gap:10px">
          <div style="padding:10px;background:#facc1522;border-radius:8px;border-right:3px solid #facc15">
            <b style="color:#facc15">الوجه العلوي — حديد الشدّ</b>
            <div style="font-size:20px;font-weight:700;margin:4px 0">${i.top.label}</div>
            <div style="font-size:11.5px;color:var(--mut)">هنا <b>كل</b> الحديد الرئيسي.
              عزم البروز سالب على طوله كله، فالوجه المشدود هو العلوي.</div></div>
          <div style="padding:10px;background:#60a5fa22;border-radius:8px;border-right:3px solid #60a5fa">
            <b style="color:#60a5fa">الوجه السفلي — انكماش وتماسك</b>
            <div style="font-size:20px;font-weight:700;margin:4px 0">${i.bottom.label}</div>
            <div style="font-size:11.5px;color:var(--mut)">وجه <b>الضغط</b> — لا يقاوم
              عزم البروز. حديد انكماش 0.0018·Ag وتماسك يدخل المسند.</div></div></div>
        ${table(['البند', 'القاعدة', 'المحسوب', 'الحدّ', ''], i.rules.map(x =>
          ['<code style="color:var(--acc2)">' + x.c + '</code>', x.t, x.v, x.l, y(x.ok)]))}
        <div class="note">${i.rules.map(x => '<b>' + x.t.replace(/\*\*/g, '') + ':</b> ' + x.why).join('<br>')}</div>
        ${table(['التثبيت والترخيم', 'القيمة'], [
          ['نشر الحديد العلوي', i.anchor.rule],
          ['الترخيم الفوري', nf(i.d_imm, 2) + ' مم' + (i.defl.ok ? ' — ضمن حدّ ' +
            nf(i.defl.gov.limit, 1) + ' مم' : ' — <b style="color:#f87171">يتجاوز الحدّ</b>')],
          ['أدنى سماكة', int(i.hmin) + ' مم = ℓ/8 (جدول ACI 9.3.1.1) — والمنفَّذ ' + int(i.h) + ' مم'],
        ])}`).join('')}
      <div class="note">${c.note}<br>شغّل <b>«التسليح»</b> بالمجسم واختر طبقة
        <b>«كانتيليفر (شناشيل)»</b> لترى الحديد الأصفر بالأعلى والأزرق بالأسفل بعينك.</div></div>`;
}

/* ============ أنواع الإجهادات على الخرسانة — الأشكال الخمسة ============
   ما الذي يحصل للعنصر فعلاً تحت كل نمط: الضغط يقصّره ويُكرّشه، والشدّ يطيله
   ويشقّقه عرضياً، والانحناء يقوّسه فيُشدّ وجه ويُضغط الآخر، والقص يُزحلق مقطعاً
   على مقطع فيشقّ قطرياً 45°، والالتواء يلويه حول محوره فيشقّ حلزونياً.
   الرسم توضيحي للشكل، والأرقام إلى جانبه من التحليل. */
const STRESS_ART = {
  compression: { name: 'إجهاد الضغط', color: '#60a5fa',
    what: 'الحمل المحوري يقصّر العنصر ويُنتّئ جوانبه. الخرسانة قوية هنا — '
        + 'لكن إن طال العنصر ونحف **انبعج** قبل أن يُسحق، والانبعاج انهيار مفاجئ بلا إنذار.',
    fail: 'تقشّر الغطاء ثم سحق الخرسانة وانبعاج الأسياخ الطولية بين الأساور — '
        + 'ولهذا تُقارب الأساور عند طرفي العمود.' },
  tension: { name: 'إجهاد الشدّ', color: '#f87171',
    what: 'الحمل يطيل العنصر. مقاومة الخرسانة للشدّ ≈ عُشر مقاومتها للضغط، '
        + 'فتُهمل كلياً بالتصميم و**الحديد وحده** يقاوم الشدّ.',
    fail: 'شقوق عرضية عمودية على اتجاه الشدّ، متقاربة ومنتظمة — وعرضها يُتحكَّم '
        + 'به بتباعد الأسياخ (24.3.2) لا بمقاومتها.' },
  bending: { name: 'عزم الانحناء', color: '#facc15',
    what: 'العزم يقوّس العنصر: وجه يُشدّ ووجه يُضغط ومحور محايد بينهما. **إشارة '
        + 'العزم تقرّر أي وجه يُشدّ** — وهناك يوضع الحديد.',
    fail: 'شقوق شاقولية تبدأ من الوجه المشدود وتصعد نحو المحور المحايد — أوسعها '
        + 'بوسط البحر للعزم الموجب، وفوق المسند للسالب.' },
  shear: { name: 'إجهاد القص', color: '#fb923c',
    what: 'مقطع ينزلق على مقطع مجاوره. الإجهاد الرئيسي الناتج **قطري**، '
        + 'ولهذا يشقّ القص بزاوية 45° لا شاقولياً.',
    fail: 'شقّ قطري مائل قرب المسند يمتدّ بسرعة — **انهيار هشّ بلا إنذار**، '
        + 'ولهذا تُصمَّم الأساور لتعبر الشقّ المائل وتخيطه.' },
  torsion: { name: 'عزم الالتواء (الدوران)', color: '#a78bfa',
    what: 'العزم يلوي العنصر حول محوره الطولي، فتدور المقاطع بعضها على بعض '
        + 'ويعمل المقطع كأنبوب مجوّف مغلق (22.7).',
    fail: 'شقوق حلزونية تلفّ حول العنصر بزاوية 45° وتغيّر اتجاهها بكل وجه — '
        + 'ولا يقاومها إلا **أساور مغلقة** + حديد طولي موزّع على المحيط.' },
  buckling: { name: 'ضغط وانبعاج', color: '#60a5fa', alias: 'compression' },
};
function stressSvg(mode, on, col) {
  const c = on ? col : '#475569', w = on ? 2.6 : 1.8, o = on ? 1 : .5;
  const body = { fill: on ? col + '22' : '#1e293b', stroke: c };
  const A = (x1, y1, x2, y2) => `<line x1="${x1}" y1="${y1}" x2="${x2}" y2="${y2}"
      stroke="${c}" stroke-width="${w}" marker-end="url(#ar${on ? 1 : 0})"/>`;
  const shapes = {
    // ضغط: منشور مُنتّئ الجانبين + سهمان للداخل
    compression: `<path d="M22 30 Q10 60 22 90 L58 90 Q70 60 58 30 Z"
        fill="${body.fill}" stroke="${c}" stroke-width="${w}"/>
      ${A(40, 6, 40, 26)}${A(40, 114, 40, 94)}`,
    // شدّ: منشور مخصور + سهمان للخارج
    tension: `<path d="M22 30 Q34 60 22 90 L58 90 Q46 60 58 30 Z"
        fill="${body.fill}" stroke="${c}" stroke-width="${w}"/>
      ${A(40, 28, 40, 6)}${A(40, 92, 40, 114)}`,
    // انحناء: جائز مقوّس — الوجه العلوي مضغوط والسفلي مشدود، وعزمان بالطرفين
    bending: `<path d="M10 52 Q40 20 70 52 L70 74 Q40 42 10 74 Z"
        fill="${body.fill}" stroke="${c}" stroke-width="${w}"/>
      <path d="M40 34 Q40 34 40 34" fill="none"/>
      ${A(12, 40, 12, 24)}${A(68, 40, 68, 24)}
      <text x="40" y="32" text-anchor="middle" font-size="11" fill="${c}"
        font-weight="700" opacity="${on ? 1 : .6}">ضغط</text>
      <text x="40" y="96" text-anchor="middle" font-size="11" fill="${c}"
        font-weight="700" opacity="${on ? 1 : .6}">شدّ</text>
      <line x1="10" y1="63" x2="70" y2="63" stroke="${c}" stroke-width="1.2"
        stroke-dasharray="4 3" opacity=".7"/>
      <path d="M14 86 Q40 58 66 86" fill="none" stroke="${c}" stroke-width="1.4"
        stroke-dasharray="3 3" opacity=".55"/>`,
    // قص: متوازي أضلاع مُزاح + سهمان متعاكسان
    shear: `<path d="M18 88 L34 32 L64 32 L48 88 Z"
        fill="${body.fill}" stroke="${c}" stroke-width="${w}"/>
      ${A(20, 24, 62, 24)}${A(60, 98, 18, 98)}
      <line x1="24" y1="80" x2="58" y2="40" stroke="${c}" stroke-width="1.4"
        stroke-dasharray="4 3" opacity=".8"/>`,
    // التواء: منشور ملتوٍ (ساعة رملية) + سهم دائري
    torsion: `<path d="M22 30 L58 30 L30 60 L58 90 L22 90 L50 60 Z"
        fill="${body.fill}" stroke="${c}" stroke-width="${w}"/>
      <path d="M24 20 A18 9 0 1 1 56 20" fill="none" stroke="${c}"
        stroke-width="${w}" marker-end="url(#ar${on ? 1 : 0})"/>`,
  };
  const k = (STRESS_ART[mode] || {}).alias || mode;
  return `<svg viewBox="0 0 80 124" width="76" height="118" style="opacity:${o}">
    <defs><marker id="ar${on ? 1 : 0}" markerUnits="userSpaceOnUse" markerWidth="11"
      markerHeight="11" refX="9" refY="5" orient="auto">
      <path d="M0,0.6 L10,5 L0,9.4 Z" fill="${c}"/></marker></defs>
    ${shapes[k] || shapes.bending}</svg>`;
}
/* بطاقات الإجهادات الخمس — الحاكم منها مُبرَز */
function stressCards(active, ratios) {
  const ks = ['compression', 'tension', 'bending', 'shear', 'torsion'];
  const norm = m => m === 'buckling' ? 'compression' : m;
  return `<div style="display:flex;gap:10px;flex-wrap:wrap;justify-content:center">
    ${ks.map(k => {
      const on = norm(active) === k;
      const a = STRESS_ART[k];
      const rk = k === 'compression' ? 'buckling' : k;
      const rv = ratios ? ratios[rk] : null;
      return `<div style="flex:1 1 150px;min-width:150px;max-width:230px;border-radius:10px;
          padding:10px;border:1px solid ${on ? a.color : 'var(--bd,#25344d)'};
          background:${on ? a.color + '14' : 'transparent'}">
        <div style="text-align:center">${stressSvg(k, on, a.color)}</div>
        <div style="text-align:center;font-weight:700;font-size:13px;margin-top:4px;
          color:${on ? a.color : 'var(--mut)'}">${a.name}${on ? ' ◄' : ''}</div>
        ${rv !== null && rv !== undefined ? `<div style="text-align:center;font-size:12px;
          margin-top:3px">النسبة <b style="color:${rcol(rv)}">${nf(rv, 2)}</b></div>` : ''}
        <div style="font-size:11.5px;line-height:1.75;color:var(--mut);margin-top:6px">${a.what}</div>
        <div style="font-size:11.5px;line-height:1.75;margin-top:6px">
          <b style="color:${a.color}">شكل الفشل:</b> <span style="color:var(--mut)">${a.fail}</span></div>
      </div>`;
    }).join('')}</div>`;
}

/* ========== بيان الشياش: أيّها مستمر وأيّها ينقطع — وأين بالضبط ==========
   السؤال العملي بالموقع ليس «كم سيخاً» بل **أي سيخ يمشي من أوله لآخره وأيّها
   يُقطع وأين**. الرسم أدناه مقطع طولي لبحر نموذجي مبنيّ على أرقام التصميم
   نفسها: أطوال القطع من الكود (9.7.3)، ومنطقة الوصل الممنوعة من 18.6.3.3،
   ومناطق الأساور الحرجة من 18.6.4. */
function barMapSvg(R, o) {
  const sp = o.span, sw = o.sup_w, ln = o.ln;
  const X0 = 70, X1 = 880, W = X1 - X0, S = W / sp;        // بكسل لكل متر
  const m = v => X0 + v * S;
  const yT = 118, hpx = 104, yB = yT + hpx;                 // وجها الجسر
  const swp = sw * S, fL = m(sw / 2), fR = m(sp - sw / 2);  // وجها المسند
  const C = { top: '#f87171', bot: '#38bdf8', cont: '#34d399',
              tie: '#fb923c', dim: '#94a3b8', sp: '#facc15' };
  const lab = (x, y, t, c, sz, anc) => `<text x="${x}" y="${y}" fill="${c || C.dim}"
    font-size="${sz || 13}" text-anchor="${anc || 'middle'}" font-weight="600">${t}</text>`;
  const dim = (x1, x2, y, t, c) => `<line x1="${x1}" y1="${y}" x2="${x2}" y2="${y}"
      stroke="${c || C.dim}" stroke-width="1.1"/>
    <line x1="${x1}" y1="${y - 6}" x2="${x1}" y2="${y + 6}" stroke="${c || C.dim}" stroke-width="1.1"/>
    <line x1="${x2}" y1="${y - 6}" x2="${x2}" y2="${y + 6}" stroke="${c || C.dim}" stroke-width="1.1"/>
    ${lab((x1 + x2) / 2, y - 8, t, c, 12)}`;
  // ---- الأساور ----
  const zc = Math.min(2 * o.h / 1000, ln / 3);
  let ties = '';
  const tick = x => `<line x1="${x}" y1="${yT + 7}" x2="${x}" y2="${yB - 7}"
    stroke="${C.tie}" stroke-width="1.7" opacity=".85"/>`;
  for (let v = 0; v <= zc + 1e-9; v += o.s_hoop / 1000) { ties += tick(fL + v * S); ties += tick(fR - v * S); }
  for (let v = zc; v <= ln - zc + 1e-9; v += o.s / 1000) ties += tick(fL + v * S);
  // ---- الشياش ----
  const yTc = yT + 13, yT1 = yT + 26, yT2 = yT + 38;
  const yBc = yB - 13, yB1 = yB - 27;
  const bar = (x1, x2, y, c, w) => `<line x1="${x1}" y1="${y}" x2="${x2}" y2="${y}"
    stroke="${c}" stroke-width="${w || 4}" stroke-linecap="round"/>`;
  const t1 = Math.min(o.top1, ln / 2) * S, t2 = Math.min(o.top2, ln / 2) * S;
  const cut = 0.1 * ln;
  // direction:ltr وإلا بدأ التمرير من يمين الرسم (الصفحة RTL) فاختفت بدايته
  return `<div style="overflow-x:auto;direction:ltr"><svg viewBox="0 0 950 300"
      style="min-width:700px;width:100%;height:auto;background:#0b1220;border-radius:10px">
    ${lab(X0, 26, 'مقطع طولي لبحر نموذجي — جسر ' + o.dir, '#e2e8f0', 15, 'start')}
    ${lab(X1, 26, int(o.b) + ' × ' + int(o.h) + ' مم', C.dim, 13, 'end')}
    ${lab(X0, 52, '▬ مستمر', C.cont, 13, 'start')}
    ${lab(X0 + 100, 52, '▬ علوي مقطوع', C.top, 13, 'start')}
    ${lab(X0 + 235, 52, '▬ سفلي مقطوع', C.bot, 13, 'start')}
    ${lab(X0 + 370, 52, '❙ كانات', C.tie, 13, 'start')}
    ${lab(X0 + 460, 52, '▨ نطاق الوصل', C.sp, 13, 'start')}
    <!-- المساند -->
    <rect x="${fL - swp}" y="${yT}" width="${swp}" height="${hpx + 54}" fill="#1e293b" stroke="#334155"/>
    <rect x="${fR}" y="${yT}" width="${swp}" height="${hpx + 54}" fill="#1e293b" stroke="#334155"/>
    ${lab(fL - swp / 2, yB + 74, 'عمود', C.dim, 12)}
    ${lab(fR + swp / 2, yB + 74, 'عمود', C.dim, 12)}
    <!-- جسم الجسر -->
    <rect x="${fL - swp}" y="${yT}" width="${fR + 2 * swp - fL}" height="${hpx}"
      fill="#111c2e" stroke="#334155" stroke-width="1.5"/>
    ${ties}
    <!-- نطاق الوصل -->
    <rect x="${m(o.splice[0])}" y="${yT + 2}" width="${(o.splice[1] - o.splice[0]) * S}"
      height="${hpx - 4}" fill="${C.sp}" opacity=".09"/>
    <!-- علوي -->
    ${bar(fL - swp, fR + swp, yTc, C.cont, 4.6)}
    ${lab(m(sp / 2), yT - 10, '٢Ø' + int(o.top_db) + ' علوي مستمر — لا يُقطع', C.cont, 13)}
    ${o.top_n > 2 ? bar(fL - swp, fL + t1, yT1, C.top) + bar(fR - t1, fR + swp, yT1, C.top) : ''}
    ${o.top_n > 3 ? bar(fL - swp, fL + t2, yT2, C.top, 3) + bar(fR - t2, fR + swp, yT2, C.top, 3) : ''}
    ${o.top_n > 2 ? dim(fL, fL + t1, yT - 32, 'L/3 = ' + nf(o.top1, 2) + ' م', C.top) : ''}
    ${o.top_n > 3 ? dim(fR - t2, fR, yT - 32, 'L/5 = ' + nf(o.top2, 2) + ' م', C.top) : ''}
    <!-- سفلي -->
    ${bar(fL - swp, fR + swp, yBc, C.cont, 4.6)}
    ${o.bot_n > 2 ? bar(fL + cut * S, fR - cut * S, yB1, C.bot) : ''}
    ${lab(m(sp / 2), yB + 20, '٢Ø' + int(o.bot_db) + ' سفلي مستمر — يدخل العمود وينشر fy',
      C.cont, 13)}
    ${o.bot_n > 2 ? dim(fL, fL + cut * S, yB + 40, '0.1·ln = ' + nf(cut, 2) + ' م', C.bot) : ''}
    ${dim(m(o.splice[0]), m(o.splice[1]), yB + 40, 'نطاق الوصل المسموح', C.sp)}
    <!-- الأساور -->
    ${dim(fL, fL + zc * S, yB + 66, 'Ø' + int(o.tie_db) + '@' + int(o.s_hoop) + ' على 2h = '
      + nf(zc, 2) + ' م', C.tie)}
    ${dim(fL + zc * S, fR - zc * S, yB + 66, 'Ø' + int(o.tie_db) + '@' + int(o.s), C.tie)}
    ${dim(fR - zc * S, fR, yB + 66, nf(zc, 2) + ' م', C.tie)}
    ${dim(fL, fR, yB + 92, 'البحر الصافي ln = ' + nf(ln, 2) + ' م')}
  </svg></div>`;
}
function barMapPanel(r) {
  const rows = ((r.aci_extra || {}).beam_rules || {}).rows || [];
  if (!rows.length) return '';
  const body = rows.map(x => {
    const mb = r.model.beams[x.beam === 'X' ? 'x' : 'y'];
    const o = { dir: x.beam, b: x.b, h: x.h, d: x.d, span: x.span, ln: x.ln,
      sup_w: x.span - x.ln, top1: mb.detail.top1, top2: mb.detail.top2,
      top_n: mb.rebar.top.n, top_db: mb.rebar.top.db,
      bot_n: mb.rebar.bottom.n, bot_db: mb.rebar.bottom.db,
      tie_db: mb.rebar.stirrup.db, s: mb.rebar.stirrup.s,
      s_hoop: (x.splice || {}).s_hoop || mb.rebar.stirrup.s,
      splice: (x.splice || {}).zone || [x.span * 0.3, x.span * 0.7] };
    const cut = x.cut || {};
    return `<h4 style="margin:14px 0 8px;color:var(--mut);font-size:13px">
        جسر باتجاه ${x.beam} — ${int(x.b)} × ${int(x.h)} مم · بحر ${nf(x.span, 2)} م</h4>
      ${barMapSvg(r, o)}
      ${decCards([
        { title: 'علوي — الطبقة المستمرة · 2Ø' + int(o.top_db), on: true, tag: 'مستمر',
          lines: [['أين', 'يمشي على طول الجسر كله ويمرّ خلال كل عمود — لا يُقطع أبداً'],
            ['البند', 'ACI 318-19 18.6.3.1']] },
        { title: 'علوي — الطبقة الأولى المقطوعة · ' + Math.max(0, o.top_n - 2) + 'Ø' + int(o.top_db),
          on: o.top_n > 2, bad: true, tag: 'ينقطع',
          lines: [['أين ينتهي', 'على L/3 = ' + nf(o.top1, 2) + ' م من وجه المسند لكل جهة'],
            ['البند', 'ACI 318-19 9.7.3.8.4']] },
        { title: 'علوي — الطبقة الثانية', on: o.top_n > 3, bad: true, tag: 'ينقطع',
          lines: [['أين ينتهي', o.top_n > 3 ? 'تُقطع أبكر عند L/5 = ' + nf(o.top2, 2) + ' م'
            : 'غير مطلوبة بهذا المقطع'], ['البند', 'ACI 318-19 9.7.3.8.4']] },
        { title: 'امتداد ثلث الحديد العلوي بعد نقطة الانقلاب', on: true, tag: 'إلزامي',
          lines: [['المقدار', ((cut.neg_third || {}).n || 2) + ' سيخ يتجاوز نقطة الانقلاب ('
            + nf(cut.inflect || 0, 2) + ' م) بـ ' + nf((cut.neg_third || {}).ext || 0, 2)
            + ' م = الأكبر من d و12db و ln/16'],
            ['لماذا', 'نقطة الانقلاب موضع نظري يتحرّك مع نمط التحميل — فيُمدّ الحديد بعدها احتياطاً'],
            ['البند', 'ACI 318-19 9.7.3.8.4']] },
        { title: 'سفلي — الطبقة المستمرة · 2Ø' + int(o.bot_db), on: true, tag: 'مستمر',
          lines: [['أين', 'يدخل العمود و**ينشر fy عند وجهه**'],
            ['ما هو', 'حديد التماسك الإنشائي الذي يمنع الانهيار التدريجي لو فُقد مسند'],
            ['البند', 'ACI 318-19 9.7.7 + 9.7.3.8.2']] },
        { title: 'سفلي — الباقي · ' + Math.max(0, o.bot_n - 2) + 'Ø' + int(o.bot_db),
          on: o.bot_n > 2, bad: true, tag: 'ينقطع',
          lines: [['أين ينتهي', 'على بُعد 0.1·ln ≈ ' + nf(0.1 * o.ln, 2) + ' م من وجه المسند'
            + (mb.detail.bent ? ' — ونصفه يُثنى 45° عند ln/7 = ' + nf(mb.detail.bend_at, 2) + ' م' : '')],
            ['البند', 'ACI 318-19 9.7.3.8.3']] },
        { title: 'وصلات الحديد السفلي', on: true, tag: 'بمكان محدّد',
          lines: [['النطاق المسموح', nf(o.splice[0], 2) + ' – ' + nf(o.splice[1], 2)
            + ' م من مركز المسند'],
            ['الممنوع', 'الوصل قرب وجه العمود — هناك تتكوّن المفصلة اللدنة والوصلة تنزلق'],
            ['البند', 'ACI 318-19 18.6.3.3']] },
        { title: 'الكانات — المنطقة الحرجة · Ø' + int(o.tie_db) + '@' + int(o.s_hoop) + ' مم',
          on: true, tag: 'مكثّفة',
          lines: [['المدى', 'على 2h = ' + nf(Math.min(2 * o.h / 1000, o.ln / 3), 2)
            + ' م من وجه كل عمود'],
            ['العكفة', '135° تدخل لبّ الجسر — لا 90° تنفتح مع تقشّر الغطاء'],
            ['البند', 'ACI 318-19 18.6.4.1 + 25.3.4']] },
        { title: 'الكانات — باقي البحر · Ø' + int(o.tie_db) + '@' + int(o.s) + ' مم',
          on: true, tag: 'عادية',
          lines: [['أين', 'بوسط البحر حيث القص أقلّ'],
            ['الحدّ', 'التباعد لا يتجاوز d/2 = ' + int(x.d / 2) + ' مم'],
            ['البند', 'ACI 318-19 9.7.6.2.2']] },
      ])}`;
  }).join('');
  return `<div class="card"><h3>🧵 الشياش المستمرة وغير المستمرة — والكانات</h3>
    <div class="note" style="margin-bottom:10px">السؤال بالموقع ليس «كم سيخاً» بل
      <b>أي سيخ يمشي من أوله لآخره وأيّها يُقطع وأين</b>. الرسم مقطع طولي لبحر
      نموذجي مبنيّ على أرقام هذا المشروع نفسه:
      <b style="color:#34d399">الأخضر مستمر</b> ·
      <b style="color:#f87171">الأحمر علوي مقطوع</b> ·
      <b style="color:#38bdf8">الأزرق سفلي مقطوع</b> ·
      <b style="color:#fb923c">البرتقالي كانات</b> ·
      <b style="color:#facc15">الأصفر نطاق الوصل المسموح</b>.</div>
    ${body}
    <div class="note"><b>لماذا يوجد سيخ مستمر أصلاً:</b> الحديد السفلي المستمر
      الذي يدخل العمود وينشر إجهاد خضوعه هناك هو <b>حديد التماسك الإنشائي</b>
      (ACI 9.7.7): لو فُقد عمود، يتدلّى الجسر ويصير الحديد السفلي <b>شدّاً</b>
      يمسك البلاطة كالحبل بدل أن تسقط. وهذا بالضبط ما تقيسه تجربة حذف العمود
      بتبويب «الإنشائيات والتجربة».
      <br><b>ولماذا تُكثَّف الكانات عند الأعمدة:</b> القص أقصى ما يكون عند وجه
      المسند، وهناك أيضاً تتكوّن <b>المفصلة اللدنة</b> بالزلزال. الكانة المكثّفة
      تخيط الشقّ القطري وتطوّق الخرسانة وتمنع انبعاج الأسياخ الطولية — ولهذا
      عكفتها <b>135°</b> تدخل اللبّ لا 90° تنفتح مع تقشّر الغطاء.</div></div>`;
}

/* ---------- نوع الجسر: قرار إنشائي يغيّر المقطع والحديد والأساور ---------- */
function beamTypePanel(r) {
  const B = r.model && r.model.beams;
  if (!B || !B.x.btype) return '';
  const dirs = [['X', B.x], ['Y', B.y]];
  const one = (lab, bm) => {
    const t = bm.btype, s = bm.sec, reb = bm.rebar;
    const fl = t.flange;
    const pos = t.slab === 'top' ? 'يتدلّى <b>تحت</b> البلاطة'
      : t.slab === 'in' ? '<b>داخل</b> سماكة البلاطة — لا يبرز'
        : 'يصعد <b>فوق</b> البلاطة';
    return `<h4 style="margin:14px 0 6px;color:var(--mut);font-size:13px">
        جسور المحور ${lab} — ${t.name}</h4>
      ${table(['ما يقرّره النوع', 'هنا', 'القاعدة'], [
        ['موضعه من البلاطة', pos + (s.drop_below ? ' بمقدار ' + int(s.drop_below) + ' مم'
          : s.rise_above ? ' بمقدار ' + int(s.rise_above) + ' مم' : ''),
         'يُرسم بالمجسم بموضعه هذا، والحديد يتبعه'],
        ['المقطع', int(s.b) + ' × ' + int(s.h) + ' مم', t.h_rule],
        ['الشفة الضاغطة', (fl.pos ? 'مع العزم <b>الموجب</b>' : fl.neg
          ? 'مع العزم <b>السالب</b>' : 'لا شفة — مستطيل بالوجهين')
          + (fl.pos || fl.neg ? ' — bf = ' + int(fl.bf) + ' مم' : ''),
         fl.clause],
        ['عرض الشفة المستعمَل', 'للموجب ' + int(t.bf_pos) + ' مم · للسالب '
          + int(t.bf_neg) + ' مم',
         'الانحناء يُحسب بعرض الشفة، والحديد الأدنى بعرض <b>العنق</b> (9.6.1.2)'],
        ['أرجل الأساور', t.legs + ' أرجل', t.legs_rule],
        ['أقصى عرض مسموح', int(t.width_cap) + ' مم '
          + (t.width_ok ? '<span class="tag t-ok">ضمن الحدّ</span>'
            : '<span class="tag t-bad">تجاوز</span>'),
         'ACI 18.6.2.1 — ما زاد على عرض العمود + min(c₂, 0.75c₁) لكل جهة لا يصل حمله للعقدة'],
        ['الحديد المنفَّذ', reb.bottom.label + ' سفلي · ' + reb.top.label + ' علوي · '
          + reb.stirrup.label, 'هذا ما يتغيّر فعلاً بتغيّر النوع — لا الشكل وحده'],
      ])}
      ${(t.extras || []).length ? `<div class="note" style="border-right:3px solid #facc15">
        <b>تفاصيل لا توجد بغير هذا النوع:</b><ul style="margin:6px 18px 0">
        ${t.extras.map(x => '<li>' + x + '</li>').join('')}</ul></div>` : ''}
      ${reb.hanger ? `<div class="note" style="border-right:3px solid #f87171">
        <b>حديد التعليق (Hanger):</b> البلاطة تستند على الوجه <b>السفلي</b> للجسر
        المقلوب، فحملها يُعلَّق ولا يُسنَد — لولا أساور تعبر كامل العمق لانفصل
        الوجه السفلي بشقّ أفقي. المطلوب للتعليق <b>${int(reb.hanger.Av_s)} مم²/م</b>
        و<b>${int(reb.hanger.Av_s_shear || 0)} مم²/م</b> للقصّ، وهما
        <b>يُجمعان ولا يتقاسمان</b>؛ فشُدّ تباعد الأساور حتى صار المنفَّذ
        <b>${int(reb.hanger.Av_s_prov)} مم²/م</b>
        ${reb.hanger.ok ? '<span class="tag t-ok">يكفي</span>'
          : '<span class="tag t-bad">لا يكفي</span>'}.
        (${reb.hanger.clause})</div>` : ''}
      ${reb.web ? `<div class="note" style="border-right:3px solid #22d3ee">
        <b>الحديد الموزّع بالوجهين:</b> ${reb.web.label} — ${reb.web.note}
        ${t.deep_actual ? '' : '<br>⚠️ النسبة ln/h = ' + nf(t.ln / (s.h / 1000), 2)
          + ' تتجاوز 4، فالمقطع لم يعد جسراً عميقاً بتعريف 9.9.1.1.'}</div>` : ''}`;
  };
  return `<div class="card"><h3>🧱 نوع الجسر — ما الذي يتغيّر فعلاً</h3>
    ${table(['النوع', 'موضع البلاطة', 'له', 'عليه'],
      (B.types || []).map(t => [
        (t.k === B.x.btype.k || t.k === B.y.btype.k)
          ? '<b>' + t.name + '</b> <span class="tag t-ok">مستعمَل</span>' : t.name,
        t.slab === 'top' ? 'فوقه — يتدلّى تحت السقف'
          : t.slab === 'in' ? 'بمستواه — مخفي' : 'تحته — يصعد فوق السقف',
        t.pros, t.cons]))}
    ${dirs.map(([l, bm]) => one(l, bm)).join('')}
    <div class="note">غيّر النوع من <b>المعالج ← ٣-ب نوع الجسور</b> — عاماً أو لكل
      محور على حدة — ثم أعد التصميم. المقطع والحديد والأساور تُعاد جميعاً،
      ويُرسم الجسر بالمجسم بموضعه الصحيح من البلاطة وحديده تابعاً له.</div></div>`;
}

/* ---------- المصعد: نواة قصّ بحملها وعزمها وتسليحها ---------- */
function liftPanel(r) {
  const e = r.model && r.model.elevator;
  if (!e) return '';
  const w = e.wall, rg = e.rigidity, L = e.loads, y = ok => ok
    ? '<span class="tag t-ok">مقبول</span>' : '<span class="tag t-bad">راجع</span>';
  return `
    <div class="card"><h3>🛗 المصعد — نواة قصّ لا فتحة بالسقف</h3>
      <div class="grid g4">
        ${kpi('النوع', e.name || 'مصعد واحد')}
        ${kpi('السعة', e.Q + ' كغم · ' + e.persons + ' راكب')}
        ${kpi('البئر الداخلي', nf(e.w, 2) + ' × ' + nf(e.h, 2) + ' م')}
        ${kpi('النواة الخارجية', nf(e.section.wo, 2) + ' × ' + nf(e.section.ho, 2) + ' م')}
        ${kpi('سماكة الجدار', int(e.t) + ' مم')}
        ${kpi('ارتفاع النواة', nf(e.H, 2) + ' م')}
        ${kpi('حصة النواة من القوة الجانبية', nf(rg.share * 100, 0) + '%',
          rg.share > 0.5 ? 'bad' : 'ok')}
        ${kpi('الحمل على أساس الجدران', int(e.on_found) + ' kN')}
        ${kpi('الحمل على قاع البئر', int(e.on_pit) + ' kN')}
        ${kpi('عمق الحفرة (Pit)', nf(e.pit, 2) + ' م')}</div>

      <h4 style="margin:16px 0 6px;color:var(--mut);font-size:13px">
        ١ · أحماله الخاصّة — لا علاقة لها بحمل السقف</h4>
      ${table(['البند', 'القيمة'], L.rows.map(x => [x[0], x[1]]))}
      <div class="note">${L.note}</div>

      <h4 style="margin:16px 0 6px;color:var(--mut);font-size:13px">
        ٢ · لماذا يغيّر المصعد التحليل كله</h4>
      <div class="note" style="border-right:3px solid #facc15">${rg.note}</div>
      ${table(['البند', 'القيمة'], [
        ['مقطع النواة (صندوق مغلق)', 'A = ' + nf(e.section.A, 3) + ' م² · Ix = ' +
          nf(e.section.Ix, 3) + ' م⁴ · Iy = ' + nf(e.section.Iy, 3) + ' م⁴'],
        ['ثابت الالتواء J (Bredt)', nf(e.section.J, 3) + ' م⁴ — المقطع **مغلق** '
          + 'فالتواؤه أكبر من مقطع مفتوح بمراتب'],
        ['قص المستوى على الجدار Vu', int(w.Vu) + ' kN'],
        ['عزم القلب بالمستوى Mu', int(w.Mu) + ' kN·م'],
      ])}

      <h4 style="margin:16px 0 6px;color:var(--mut);font-size:13px">
        ٣ · تصميم الجدار — ACI 318-19 الفصل 11</h4>
      ${table(['البند', 'القيمة'], w.rows.map(x => [x[0], x[1]]))}
      <div class="grid g4" style="margin-top:8px">
        ${kpi('المحوري', y(w.ok_axial), w.ok_axial ? 'ok' : 'bad')}
        ${kpi('حدّ مقطع القص', y(w.ok_section), w.ok_section ? 'ok' : 'bad')}
        ${kpi('عنصر حدّ مطوَّق', w.need_boundary ? 'مطلوب (18.10.6.3)' : 'غير مطلوب',
          w.need_boundary ? 'bad' : 'ok')}
        ${kpi('عدد الشبكات', w.two_layers ? 'شبكتان' : 'شبكة واحدة')}</div>

      <h4 style="margin:16px 0 6px;color:var(--mut);font-size:13px">
        ٣-ب · تسليح النواة — أربع عائلات مرسومة بالمجسم مع بقية الحديد</h4>
      ${table(['العائلة', 'التفصيل', 'وظيفتها', 'المادة'], [
        ['رأسي موزّع', w.vert.label,
         'الحمل المحوري وشقوق الانكماش والحرارة — وليس حديد العزم',
         'ACI 11.6.1 · ρℓ = ' + nf(w.rho_l, 4)],
        ['أفقي موزّع', w.horiz.label,
         'حديد قصّ المستوى: يعبر الشقّ القطري ويعطي φVs = ' + int(w.phiVs) + ' kN',
         'ACI 11.6.2 و11.5.4.8 · ρt = ' + nf(w.rho_t, 4)],
        ['عنصر الحدّ', w.be.label + ' بكل طرف (As = ' + int(w.As_be) + ' مم²)',
         'زوج قوى بذراع 0.8·Lw يقاوم عزم القلب — φMn = ' + int(w.phiMn) + ' kN·م',
         'ACI 18.10.6 · طوله ' + int(w.L_be) + ' مم'],
        ['تطويق عنصر الحدّ', 'Ø10 @ ' + int(w.be_tie_s) + ' مم',
         'يحصر الخرسانة ويمنع انبعاج أسياخ الطرف بعد انقشار الغطاء',
         'ACI 18.10.6.4'],
      ])}
      <div class="note" style="border-right:3px solid var(--acc2)">الحديد الأدنى
        <b>ρ = 0.0012</b> وُضع للانكماش والحرارة لا لمقاومة عزم القلب. نواة تأخذ
        <b>${nf(rg.share * 100, 0)}%</b> من القوة الجانبية على ارتفاع
        <b>${nf(e.H, 1)} م</b> تولّد عزماً يتجاوز مقاومته أضعافاً — ولهذا يُصمَّم
        حديد <b>عنصر الحدّ</b> بالحساب ويُركَّز بطرفَي الجدار حيث ذراع الزوج أكبر
        ما يكون. افتح <b>«التسليح»</b> بالمجسم لترى العائلات الأربع بمواضعها.</div>

      <h4 style="margin:16px 0 6px;color:var(--mut);font-size:13px">
        ٤ · فتحة البئر بكل سقف — الحديد المقطوع يُعوَّض</h4>
      ${table(['البند', 'القيمة'], e.opening.rows.map(x => [x[0], x[1]]))}
      <div class="note">${e.opening.note}</div>

      <h4 style="margin:16px 0 6px;color:var(--mut);font-size:13px">
        ٥ · قاع البئر (Pit)</h4>
      ${table(['البند', 'القيمة'], [
        ['العمق تحت أدنى منسوب وقوف', nf(e.pit_slab.depth, 2) + ' م'],
        ['سماكة البلاطة', int(e.pit_slab.t) + ' مم'],
        ['صدم المصدّ Vu', int(e.pit_slab.Vu) + ' kN'],
        ['مقاومة الثقب φVc', int(e.pit_slab.phiVc) + ' kN ' + y(e.pit_slab.ok)],
        ['الارتفاع العلوي (Overrun)', nf(e.over, 2) + ' م فوق أعلى منسوب وقوف'],
      ])}
      <div class="note">${e.note}</div>
      <div class="note" style="border-right:3px solid #f87171">⚠️ ${e.supplier}</div></div>`;
}

/* ---------- حقل العزوم: يختلف بكل نظام سقف، وكل موضع مكتوب بقيمته ---------- */
function fieldPanel(r) {
  const F = r.model && r.model.slab && r.model.slab.field;
  if (!F) return '';
  const sign = v => v > 0 ? '<b style="color:#f87171">+' + nf(v, 2) + '</b>'
                          : '<b style="color:#60a5fa">' + nf(v, 2) + '</b>';
  const face = v => v > 0 ? 'سفلي' : 'علوي';
  const st = F.strips, to = F.torsion;
  return `
    <div class="card"><h3>🗺️ حقل العزوم على السقف — ${F.name}</h3>
      <div class="rec" style="margin:0 0 12px"><h3 style="margin-top:0">شكل الحقل بهذا النظام</h3>
        <div style="font-size:13px;line-height:1.9">${F.shape}</div>
        <div style="font-size:12.5px;line-height:1.9;color:var(--mut);margin-top:8px">
          <b>وأين يذهب الحديد:</b> ${F.rebar}</div></div>
      <div class="grid g4">
        ${kpi('أقصى موجب', nf(F.hi, 1) + ' kN·م/م', 'ok')}
        ${kpi('أقصى سالب', nf(F.lo, 1) + ' kN·م/م', 'bad')}
        ${kpi('الحمل المعامل wu', nf(F.wu, 2) + ' kN/م²')}
        ${kpi('نقاط الحقل', F.xs.length + ' × ' + F.ys.length)}</div>
      <div class="note" style="margin-top:10px"><b>توزيع الحمل بين الاتجاهين:</b> ${F.split.rule}</div>

      <h4 style="margin:16px 0 6px;color:var(--mut);font-size:13px">
        كل موضع له عزم — باسمه وإحداثيه وقيمته ووجه الحديد الذي يقاومه</h4>
      ${table(['الموضع', 'الإحداثي', 'العزم (kN·م/م)', 'وجه الشدّ', 'لماذا'],
        F.spots.map(s => [`<b>${s.name}</b>`, s.where, sign(s.M),
          s.M === 0 ? '—' : '<span class="tag">' + face(s.M) + '</span>',
          `<span style="font-size:11.5px;color:var(--mut)">${s.note}</span>`]))}

      ${st.applies ? `<h4 style="margin:16px 0 6px;color:var(--mut);font-size:13px">
        شريحة العمود والشريحة الوسطى — جدولا 8.10.5</h4>
      ${table(['الاتجاه', 'عرض الشريحة (م)', 'سالب بشريحة العمود', 'سالب بالوسطى',
               'موجب بشريحة العمود', 'موجب بالوسطى'],
        st.rows.map(x => [x.dir, 'عمود ' + nf(x.b_cs, 2) + ' · وسطى ' + nf(x.b_ms, 2),
          sign(x.neg_cs), sign(x.neg_ms), sign(x.pos_cs), sign(x.pos_ms)]))}
      <div class="note">${st.note}</div>` : `<div class="note">${st.note}</div>`}

      <h4 style="margin:16px 0 6px;color:var(--mut);font-size:13px">
        عزم الالتواء بالأركان — ${to.clause || 'ACI 8.7.3.1'}</h4>
      <div class="note" style="border-right:3px solid ${to.required ? '#facc15' : 'var(--mut)'}">
        ${to.required ? '<b>مطلوب:</b> ' + nf(to.M, 2) + ' kN·م/م على طول ' +
          nf(to.length, 2) + ' م من الركن — ' : ''}${to.note}</div>

      <div class="note" style="margin-top:12px"><b>كيف حُسب:</b> ${F.method}</div>
      <div class="hint">شغّل <b>«📈 العزوم»</b> بالمجسم لترى الحقل ملوّناً على السقف،
        وبدّل بين <b>Mx</b> و<b>My</b> و<b>الحاكم</b> من القائمة بجانب الزر.
        <b style="color:#dc2626">الأحمر موجب</b> (شدّ بالوجه السفلي ⇒ حديد سفلي) و
        <b style="color:#2563eb">الأزرق سالب</b> (شدّ بالوجه العلوي ⇒ حديد علوي) —
        وإشارة العزم هي التي تقرّر <b>وجه</b> الحديد، لا مقداره فقط.</div></div>`;
}

/* بطاقات قرار بدل جدول عريض — الجداول ذات الخمسة أعمدة تُقصّ على شاشة الموبايل
   فيختفي الحكم والعتبة وقيمة المشروع، وهي كلّ الفائدة. هنا كل صفّ بطاقة مستقلة
   تُقرأ بعرض 430 بكسل كما تُقرأ على الحاسبة. */
function decCards(rows) {
  return rows.map(r => {
    const col = r.on ? (r.bad ? '#f87171' : 'var(--ok)') : 'var(--mut)';
    const bg = r.on ? (r.bad ? 'rgba(248,113,113,.09)' : 'rgba(52,211,153,.09)') : 'transparent';
    return `<div style="border-right:3px solid ${col};background:${bg};border-radius:8px;
        padding:9px 11px;margin:7px 0">
      <div style="display:flex;justify-content:space-between;gap:10px;align-items:baseline">
        <b style="font-size:13px;line-height:1.7">${r.title}</b>
        ${r.tag === null || (r.noTag && !r.on) ? '' : `<span class="tag ${r.on ? (r.bad ? 't-bad' : 't-ok') : ''}"
          style="${r.on ? '' : 'opacity:.55'};white-space:nowrap">${
            r.on ? (r.tag || 'نعم') : 'لا'}</span>`}</div>
      ${(r.lines || []).map(([k, v]) => `<div style="font-size:12px;line-height:1.85;
        color:var(--mut);margin-top:3px"><span style="opacity:.7">${k}:</span>
        <span style="color:var(--tx)">${v}</span></div>`).join('')}
    </div>`;
  }).join('');
}

/* ---------- نطاق تحمّل التربة: هو الذي يقرّر نوع الأساس ---------- */
function bandPanel(a) {
  const b = a && a.band; if (!b) return '';
  const st = a.settle;
  return `
    <div class="card" style="margin-top:16px"><h3>🧭 لماذا هذا النوع بالذات — قرار التربة أولاً</h3>
      <div class="note" style="margin-bottom:10px">${a.rule || ''}</div>
      ${decCards((a.bands || []).map(x => ({
        title: x.span + ' — ' + x.soil, on: x.key === b.key, bad: false,
        noTag: true, tag: '◄ حالتك',
        lines: [['الحكم العملي', '<b>' + x.verdict + '</b>'],
          ['لماذا', x.why]] })))}
      <h4 style="margin:14px 0 6px;color:var(--mut);font-size:13px">خطوات القرار بالترتيب</h4>
      ${decCards((a.steps || []).map((s, i) => ({
        title: (i + 1) + ' · ' + s.t, on: false, noTag: true,
        lines: [['القيمة المحسوبة', s.v], ['الأثر', s.r]] })))}
      ${a.replace ? `<h4 style="margin:14px 0 6px;color:var(--mut);font-size:13px">
        الإحلال — يُفحص قبل اللجوء للركائز</h4>
      <div class="note" style="border-right:3px solid ${a.replace.ok ? 'var(--ok)' : '#f87171'}">
        <b>${a.replace.ok ? '✓ الإحلال يكفي — لا حاجة للركائز'
          : '✗ الإحلال لا يكفي هنا'}</b>
        <ul style="margin:6px 18px 0 0;line-height:1.9">
          ${(a.replace.why || []).map(x => '<li>' + x + '</li>').join('')}</ul>
        ${a.replace.ok ? `<div style="margin-top:8px">${a.replace.spec}</div>
          <div style="margin-top:6px;color:var(--mut)">حجم الإحلال التقريبي
            <b>${nf(a.replace.volume, 0)} م³</b> · تحمّل الطبقة بعد الدكّ
            <b>${int(a.replace.qa_new)} kPa</b></div>` : ''}
        <div style="margin-top:6px;color:var(--mut);font-size:11.5px">${a.replace.note}</div>
      </div>` : ''}
      ${st ? `<h4 style="margin:14px 0 6px;color:var(--mut);font-size:13px">تحقّق الهبوط</h4>
      ${table(['البند', 'القيمة'], st.steps.map(x => [x[0], x[1]]))}
      <div class="note">${st.note} — والتحمّل والهبوط <b>فحصان منفصلان</b>:
        قد يمرّ التحمّل ويرسب الهبوط، والهبوط هو الذي يشقّق البناء لا انهيار القص.</div>` : ''}
    </div>`;
}

/* ---------- الركائز: متى تلزم فعلاً — وقلّما تلزم ---------- */
function pilePanel(r) {
  const a = r.advisor, pl = a && a.piles;
  if (!pl) return '';
  const hit = pl.triggers || [];
  const g = (r.alts && r.alts.piles && r.alts.piles.pile) || null;
  const geo = g && g.geom;
  return `
    <div class="card"><h3>🪨 الركائز — متى تلزم فعلاً (وقلّما تلزم)</h3>
      <div class="rec" style="margin:0 0 12px;border-right:3px solid ${pl.need ? '#f87171' : 'var(--ok)'}">
        <h3 style="margin-top:0">${pl.need ? '⚠️ الركائز لازمة' : '✓ لا حاجة للركائز'}</h3>
        <div style="font-size:13px;line-height:1.9">${pl.verdict}</div></div>
      <div class="note" style="margin-bottom:10px">${pl.rule}</div>
      <h4 style="margin:4px 0 6px;color:var(--mut);font-size:13px">جدول القرار — ستة شروط، كلٌّ بعتبته</h4>
      ${decCards((pl.table || []).map(c2 => ({
        title: c2.cond, on: c2.on, bad: c2.piles,
        lines: [['الحكم', '<b>' + c2.verdict + '</b>'],
          ['عتبة الاشتعال', c2.gate],
          ['قيمة مشروعك', c2.value || '—']] })))}
      ${pl.sulfate ? `<div class="note" style="border-right:3px solid #fbbf24">
        <b>⚗️ خرسانة مقاومة للكبريتات:</b> ${pl.sulfate_note}</div>` : ''}
      <h4 style="margin:14px 0 6px;color:var(--mut);font-size:13px">أسباب التربة التي تُبطل التأسيس السطحي أصلاً</h4>
      ${decCards(pl.cases.map(c2 => ({
        title: c2.t, on: hit.indexOf(c2.t) >= 0, bad: true, noTag: true,
        lines: [['لماذا', c2.w]] })))}
      ${geo && geo.warn ? `<div class="note" style="border-right:3px solid #f87171">
        <b>⚠️ تنبيه:</b> ${geo.warn}</div>` : ''}
      ${geo ? `<h4 style="margin:14px 0 6px;color:var(--mut);font-size:13px">
        من أين جاء الطول والقطر والتباعد — لا رقم افتراضي واحد</h4>
      ${decCards([
        { title: 'طول الركيزة L = ' + nf(g.L, 1) + ' م', on: true, tag: null,
          lines: [['من أين', geo.target ? ('تخترق حتى ' + geo.target.name + ' (' +
            int(geo.target.qa) + ' kPa) بغرزة 3D')
            : 'ركيزة احتكاك — لا طبقة حاملة ضمن المجسوس']] },
        { title: 'القطر D = Ø' + int(g.D * 1000) + ' مم', on: true, tag: null,
          lines: [['السُّلَّم القياسي', (geo.ladder || []).map(x => nf(x, 2)).join(' · ') + ' م'],
            ['المختار', 'أصغر قطر تكفي معه المجموعة — استغلال المجموعة ' +
              nf(g.util * 100, 0) + '% بعد كفاءة التجاور']] },
        { title: 'التباعد s = ' + nf(g.spacing, 2) + ' م', on: true, tag: null,
          lines: [['القاعدة', 's = 3D — تابع للقطر لا رقم ثابت']] },
        { title: 'الترتيب: ' + (g.layout || ''), on: true, tag: null,
          lines: [['الوضع', g.mode === 'raft'
            ? 'ركائز تحت حصيرة (Piled Raft) — الحصيرة تربط الرؤوس فلا هامات'
            : 'مجموعات تحت الأعمدة بهامات'],
            ['العدد الكلي بالمبنى', '<b>' + (g.n_total || 0) + ' ركيزة</b>' +
              (g.n_range ? ' (' + g.n_range[0] + '–' + g.n_range[1] + ' لكل عمود)' : '') +
              ' — الحمل الكلي ' + int(g.P_total || 0) + ' kN ÷ قدرة الركيزة ' +
              int(g.Qall) + ' kN'],
            ['لماذا', g.mode === 'raft'
              ? 'العدد من **الحمل الكلي** لا من حدّ أدنى تحت كل عمود'
              : (g.tri ? 'ثلاث ركائز بمثلث — ثابتة بكل الاتجاهات بلا جسور رابطة'
                 : 'الحمل يحتاج أكثر من ركيزة لكل عمود')]] },
        { title: 'قدرة الركيزة الواحدة ' + int(g.Qall) + ' kN', on: true, tag: null,
          lines: [['المصدر', 'احتكاك جانبي + ارتكاز طرفي ÷ معامل أمان ' + nf(g.FS, 1)]] },
      ])}
      <ul style="font-size:12px;line-height:1.9;color:var(--mut);margin:8px 18px 0 0">
        ${(geo.why || []).map(x => '<li>' + x + '</li>').join('')}</ul>` : ''}
      <div class="note"><b>وإذا لزمت الركائز:</b> لا تُنفَّذ <b>ركيزة مفردة</b> تحت عمود
        أبداً — خطأ موقعها المسموح بالتنفيذ يحوّل الحمل المحوري إلى عزم على رأسها،
        وليس لها بديل إن ظهر بها عيب صبّ. والاثنتان تقاومان العزم بمحور واحد فقط
        فتلزمهما جسور رابطة بالاتجاه العمودي. <b>الحد الأدنى العملي ثلاث ركائز بمثلث</b>،
        والبرنامج يفرضه ولو كان الحمل يحتاج واحدة.</div></div>`;
}

/* ---- أربعة أبواب من ACI 318-19 تُحسب على المشروع: 22.7 · 18.8.4 · 24.2 · 19.3 ---- */
function extraPanel(r) {
  const a = r.aci_extra; if (!a) return '';
  const t = a.torsion, j = a.joint, dd = a.deflection, du = a.durability;
  const y = ok => ok ? '<span class="tag t-ok">مقبول</span>' : '<span class="tag t-bad">راجع</span>';
  return `
    <div class="card"><h3>🌀 الالتواء بالجسر الطرفي — ACI 318-19 الباب 22.7</h3>
      ${t.required ? table(['البند', 'القيمة'], [
        ['الجسر الحاكم', 'باتجاه ' + t.beam + ' — ' + int(t.b) + '×' + int(t.h) + ' مم'],
        ['عزم الالتواء Tu', '<b>' + nf(t.Tu, 2) + ' kN·م</b> — من عزم طرف البلاطة ' +
          nf(t.t_per_m, 2) + ' kN·م/م (معامل ACI 6.5.2 = wu·ℓn²/24)'],
        ['عتبة الإهمال φTth (22.7.1.1)', nf(t.phiTth, 2) + ' kN·م — Tu أكبر منها فالالتواء يُصمَّم'],
        ['عزم التشقق φTcr (22.7.5.1)', nf(t.phiTcr, 2) + ' kN·م — ' + t.case],
        ['حدّ المقطع (22.7.7.1أ)', nf(t.lhs, 2) + ' ≤ ' + nf(t.rhs, 2) + ' ميغا ' + y(t.ok)],
        ['الأساور بعد الالتواء', '<b>' + t.stirrup_new.label + '</b> — التباعد ≤ ph/8 = ' +
          int(t.s_max) + ' مم (9.7.6.3.3)'],
        ['الحديد الطولي للالتواء', '<b>' + t.long_bars.label + '</b> — Aℓ = ' + int(t.Al) +
          ' مم² (الأدنى ' + int(t.Al_min) + ' مم² بالمادة 9.6.4.3)'],
      ]) : `<div class="note">Tu = ${nf(t.Tu, 2)} kN·م أقل من عتبة φTth = ${nf(t.phiTth, 2)} kN·م،
        فالمادة 22.7.1.1 تجيز إهمال الالتواء نصّاً.</div>`}
      <div class="note">البلاطة تستند على الجسر الطرفي من جهة واحدة فقط، فعزم طرفها ينقلب
        <b>التواءً</b> على الجسر — وهذا ما يشقّق الجسور الطرفية والشناشيل. الأساور هنا
        <b>مغلقة</b> لا زوج U متراكب، لأن الغطاء الجانبي ينقشر بالالتواء العالي فتفشل الوصلة
        (تعليق R9.7.6.3.1).</div></div>

    <div class="card"><h3>🔗 قص العقدة جسر–عمود — ACI 318-19 المادة 18.8.4</h3>
      ${table(['العقدة', 'γ', 'Aj (م²)', 'Vu (kN)', 'φVn (kN)', 'النسبة', 'الحالة'],
        j.rows.map(x => [x.name, nf(x.gamma, 1), nf(x.Aj / 1e6, 3), int(x.Vu), int(x.phiVn),
          `<b style="color:${rcol(x.ratio)}">${nf(x.ratio, 2)}</b>`, y(x.ok)]))}
      <div class="note">قوة الحديد العلوي عند وجه العقدة تُحسب بإجهاد <b>1.25·fy</b> لا fy
        (المادة 18.8.2.1) لأن الحديد يتجاوز حدّ الخضوع بالزلزال: T = ${int(j.T)} kN، وقص العمود
        المقابل ${int(j.Vcol)} kN. وطول نشر العكفة داخل العقدة
        <b>ldh = ${int(j.hook.ldh)} مم</b> = fy·db/(5.4λ√f'c) بالمادة 18.8.5.1 — أطول من
        25.4.3.1 لأنه يراعي انعكاس الحمل، والعكفة تُثنى <b>نحو داخل العقدة</b> وداخل لبّ العمود
        المُطوَّق. العقدة أول ما ينهار بالزلزال حين لا تُفحص.</div></div>

    <div class="card"><h3>📉 الترخيم — ACI 318-19 جدول 24.2.2 بحالاته الأربع</h3>
      ${dd.rows.map(c => `<h4 style="margin:8px 0 4px;color:var(--mut);font-size:13px">جسر ${c.beam}
        — بحر ${nf(c.L, 2)} م · عمق ${int(c.h)} مم · λΔ = ${nf(c.long_term.lambda_d, 2)}
        (ξ = ${nf(c.long_term.xi, 1)})</h4>
        ${table(['الحالة', 'ما يُفحص', 'المحسوب (مم)', 'الحدّ (مم)', 'الحالة'],
          c.cases.map(o => [o.label, o.what, nf(Math.abs(o.value), 1),
            'L/' + int(o.den) + ' = ' + nf(o.limit, 1), y(o.ok)]))}`).join('')}
      <div class="note">كان الفحص سابقاً بحدّ واحد (L/240) وبمعامل زمن ثابت 2.0 على الترخيم
        <b>الكلي</b>. الآن: λΔ = ξ/(1+50ρ′) يُضرب بالترخيم الفوري للحمل <b>الدائم وحده</b>
        (المادة 24.2.4.1.1)، ويُقارَن بالحالة الحاكمة. الافتراضي «يحمل عناصر تتضرّر» بحدّ
        <b>L/480</b> لأن القواطع البلوكية بالبناء العراقي تقف على الجسور وتتشقّق فعلاً —
        وهذا الحدّ هو الذي يقرّر عمق الجسر هنا، لا الانحناء.</div></div>

    <div class="card"><h3>🧪 الديمومة وأصناف التعرّض — ACI 318-19 الباب 19.3</h3>
      ${table(['الصنف', 'الفئة', 'الشرط', "أدنى f'c", 'أقصى w/cm', 'شرط إضافي'],
        du.rows.map(x => [`<b>${x.code}</b>`, x.cat, x.desc, x.fc + ' ميغا',
          x.wcm ? nf(x.wcm, 2) : '—', x.note || '—']))}
      <div class="grid g4" style="margin-top:10px">
        ${kpi("f'c المُدخَل", int(du.fc) + ' ميغا', du.ok_fc ? 'ok' : 'bad')}
        ${kpi("أدنى f'c للديمومة", int(du.fc_min) + ' ميغا', du.ok_fc ? 'ok' : 'bad')}
        ${kpi('أقصى w/cm', du.wcm_max ? nf(du.wcm_max, 2) : '—')}
        ${kpi('الصنف الحاكم', du.gov_fc)}</div>
      <div class="note">${du.ok_fc
        ? "المقاومة المُدخَلة تفي بمتطلبات الديمومة لأصناف التعرّض المختارة."
        : `<b style="color:#f87171">المقاومة المُدخَلة أقل من الحدّ الكودي بـ ${int(du.fc_gap)} ميغا.</b>
           ارفع f'c إلى ${int(du.fc_min)} ميغا، أو غيّر أصناف التعرّض من بطاقة «التربة والمناسيب»
           إن كان فحص تربتك يثبت كبريتات أقل.`}
        <br>هذا الباب لا علاقة له بالحمل: الكود يفرض حداً أدنى للمقاومة وحداً أعلى لنسبة
        الماء/الأسمنت <b>بسبب البيئة</b>. وحين تجتمع الأصناف تُؤخذ <b>الأشدّ</b> (المادة 19.3.2.1).
        تربة العراق الجبسية غالباً S2، وهي التي تأكل الأساس من تحت لا الحمل.</div></div>`;
}

/* ============ تبويبات مساحة العمل: تفاصيل · أشعة · سقوف · تجربة · كميات ============ */
const WT = { xr: 0, slabs: 0, boq: 0, lab: 0, plan: 0, movie: 0 };
function wtab(id) {
  $$('#wtabs button').forEach(b => b.classList.toggle('on', b.dataset.t === id));
  $$('.wpanel').forEach(p => { p.hidden = p.dataset.t !== id; });
  if (!WT[id] && TABS[id]) { WT[id] = 1; TABS[id](); }
}
/* ===== خريطة الحديد على طول الجسر — شريط المناطق بالأشعة الإنشائية =====
   الجسر ليس مقطعاً واحداً: على طوله مناطق يختلف فيها ما يجب أن يُنفَّذ، وأخطاء
   الموقع كلها تقع بحدود هذه المناطق لا بالحساب. هنا تُرسم بالمقياس. */
function zoneMapCard(beams) {
  const b = beams.find(m => m.det && m.det.zones);
  if (!b) return '';
  const uniq = {}; beams.forEach(m => { if (m.det && m.det.zones)
    uniq[m.det.zones.span.toFixed(2) + '|' + m.det.zones.h] = m; });
  const list = Object.values(uniq).slice(0, 4);
  return `<div class="card" style="margin-top:14px">
    <h3>🧭 خريطة الحديد على طول الجسر — أين يتغيّر التنفيذ</h3>
    ${list.map(m => zoneMap(m.det.zones, m)).join('')}
    <div class="legend" style="margin-top:10px">
      <span><i style="background:#f97316"></i>تكثيف الأساور (2h من وجه المسند)</span>
      <span><i style="background:#0ea5e9"></i>أساور الوسط</span>
      <span><i style="background:#065f46"></i>وصل الحديد مسموح</span>
      <span><i style="background:#991b1b"></i>وصل الحديد ممنوع</span></div>
    <div class="note">هذا الشريط هو ما ينقص المخططات عادةً: يقول للحدّاد <b>أين</b>
      يغيّر تباعد الأسوار، و<b>أين</b> يجوز أن يضع الوصلة، و<b>أين</b> ينتهي السيخ
      العلوي — كلها بالمتر من مركز المسند، ومحسوبة من أبعاد هذا الجسر بالذات.</div></div>`;
}

function zoneMap(z, m) {
  const W = 100, pct = v => (v / z.span) * 100;
  const sp = z.splice;
  return `
  <div style="margin:14px 0 18px">
    <div style="font-size:12.5px;color:var(--acc2);font-weight:700;margin-bottom:6px">
      جسر بحره ${nf(z.span, 2)} م · عمق ${int(z.h)} مم · صافي ${nf(z.ln, 2)} م
      ${m ? ' · طابق ' + m.story : ''}</div>

    <div style="font-size:10.5px;color:var(--mut);margin:6px 0 2px">صفّ ١ — الأساور</div>
    <div style="position:relative;height:24px;border-radius:5px;overflow:hidden;display:flex">
      ${z.zones.map(x => `<div title="${x.name} — ${x.clause}: ${x.text}"
        style="width:${pct(x.b - x.a)}%;background:${x.color};display:flex;
        align-items:center;justify-content:center;color:#0b1220;font-size:9.5px;
        font-weight:700;overflow:hidden;white-space:nowrap">${x.b - x.a > z.span * 0.15
          ? x.name : ''}</div>`).join('')}
    </div>

    <div style="font-size:10.5px;color:var(--mut);margin:8px 0 2px">صفّ ٢ — أين يجوز وصل الحديد (ACI 18.6.3.3)</div>
    <div style="position:relative;height:24px;border-radius:5px;overflow:hidden;
      background:repeating-linear-gradient(45deg,#7f1d1d,#7f1d1d 7px,#991b1b 7px,#991b1b 14px)">
      ${sp.ok ? `<div style="position:absolute;left:${pct(sp.a)}%;width:${pct(sp.b - sp.a)}%;
        top:0;bottom:0;background:#065f46;display:flex;align-items:center;
        justify-content:center;color:#a7f3d0;font-size:10px;font-weight:700">
        وصل مسموح (${nf(sp.b - sp.a, 2)} م)</div>`
        : `<div style="position:absolute;inset:0;display:flex;align-items:center;
        justify-content:center;color:#fecaca;font-size:10px;font-weight:700">
        البحر قصير — لا وصلة مسموحة، السيخ يعبر كاملاً</div>`}
    </div>

    <div style="font-size:10.5px;color:var(--mut);margin:8px 0 2px">صفّ ٣ — النقاط الحاكمة</div>
    <div style="position:relative;height:46px;background:var(--bg2);border-radius:5px">
      <div style="position:absolute;top:8px;left:0;right:0;height:2px;background:var(--bd)"></div>
      ${z.marks.map((k, i) => `<div title="${k.name} — ${k.clause}: ${k.text}"
        style="position:absolute;left:${pct(k.x)}%;top:0;transform:translateX(-50%)">
        <div style="width:2px;height:16px;background:var(--acc2);margin:0 auto"></div>
        <div style="font-size:8.5px;color:var(--mut);white-space:nowrap;
          transform:translateY(${(i % 2) * 12}px)">${nf(k.x, 2)}<br>${k.name}</div></div>`).join('')}
    </div>

    ${table(['المنطقة', 'من — إلى', 'البند', 'ما يُنفَّذ', 'لماذا'],
      z.zones.filter(x => x.k !== 'conf2').map(x => [x.name,
        nf(x.a, 2) + ' — ' + nf(x.b, 2) + ' م', '<code style="color:var(--acc2)">' + x.clause + '</code>',
        x.text, '<span style="font-size:11px;color:var(--mut)">' + x.why + '</span>'])
      .concat(z.marks.map(k => ['◆ ' + k.name, nf(k.x, 2) + ' م',
        '<code style="color:var(--acc2)">' + k.clause + '</code>', k.text, ''])))}
  </div>`;
}

/* ==================== 🎬 فيديو البناء ====================
   يسجّل تسلسل البناء من التربة إلى المبنى كاملاً **داخل المتصفح**: يلتقط
   تدفّق كانفاس المجسم نفسه بـ captureStream ويسجّله بـ MediaRecorder، فلا
   يُرفع شيء لأي خدمة ولا يحتاج السيرفر أي معالجة فيديو.
   المخرَج WebM (VP9 إن توفّر وإلا VP8) — يُشغَّل بكل المتصفحات ويُحوَّل بسهولة. */
let MOV = null;                 // حالة التسجيل الجارية

const movCodec = () => {
  if (!window.MediaRecorder) return null;
  for (const t of ['video/webm;codecs=vp9', 'video/webm;codecs=vp8',
                   'video/webm', 'video/mp4']) {
    if (MediaRecorder.isTypeSupported(t)) return t;
  }
  return null;
};

/* لوحة النصّ فوق الفيديو: عنوان المشهد وسطره الفرعي وشريط التقدّم.
   تُرسم على كانفاس مستقل يُدمج مع مشهد المجسم بكانفاس ثالث هو الذي يُسجَّل. */
function movOverlay(g, W, H, sc, i, n, tIn, tot, done) {
  g.clearRect(0, 0, W, H);
  const pad = Math.round(W * 0.028), fs = Math.max(18, Math.round(W * 0.030));
  // شريط سفلي متدرّج
  const grd = g.createLinearGradient(0, H - H * .24, 0, H);
  grd.addColorStop(0, 'rgba(6,10,20,0)'); grd.addColorStop(1, 'rgba(6,10,20,.92)');
  g.fillStyle = grd; g.fillRect(0, H - H * .24, W, H * .24);
  g.direction = 'rtl'; g.textAlign = 'right';
  g.fillStyle = '#e8eefc';
  g.font = '700 ' + fs + 'px system-ui, sans-serif';
  g.fillText(sc.title || '', W - pad, H - pad - fs * 1.5, W - pad * 2);
  if (sc.sub) {
    g.fillStyle = '#93a7c4';
    g.font = '500 ' + Math.round(fs * .62) + 'px system-ui, sans-serif';
    g.fillText(sc.sub, W - pad, H - pad - fs * .35, W - pad * 2);
  }
  // شريط التقدّم
  const bw = W - pad * 2, bh = Math.max(3, Math.round(H * .006));
  g.fillStyle = 'rgba(255,255,255,.16)';
  g.fillRect(pad, H - pad * .55, bw, bh);
  g.fillStyle = '#3ba9f0';
  g.fillRect(pad + bw * (1 - Math.min(1, tot)), H - pad * .55, bw * Math.min(1, tot), bh);
  // ترويسة علوية
  g.fillStyle = 'rgba(6,10,20,.62)';
  g.fillRect(0, 0, W, H * .085);
  g.fillStyle = '#cfe0f5';
  g.font = '600 ' + Math.round(fs * .58) + 'px system-ui, sans-serif';
  g.fillText('المنصة الإنشائية · ACI 318-19', W - pad, H * .052);
  g.textAlign = 'left';
  g.fillStyle = '#6f86a8';
  g.fillText((i + 1) + ' / ' + n, pad, H * .052);
  g.textAlign = 'right';
  if (done) {
    g.fillStyle = 'rgba(6,10,20,.55)'; g.fillRect(0, 0, W, H);
    g.fillStyle = '#e8eefc'; g.textAlign = 'center';
    g.font = '800 ' + Math.round(fs * 1.5) + 'px system-ui, sans-serif';
    g.fillText('تم التصميم', W / 2, H / 2 - fs);
    g.fillStyle = '#93a7c4';
    g.font = '500 ' + Math.round(fs * .7) + 'px system-ui, sans-serif';
    g.fillText(done, W / 2, H / 2 + fs * .6, W * .85);
  }
}

async function movieRun(opts) {
  if (!V3 || !WZ) return alert('شغّل المعالج أولاً');
  const mime = movCodec();
  if (!mime) return alert('متصفحك لا يدعم تسجيل الفيديو (MediaRecorder). '
    + 'جرّب Chrome أو Edge أو Firefox حديث.');
  const src = V3.canvas();
  const W = src.width, H = src.height;
  const cv = document.createElement('canvas');
  cv.width = W; cv.height = H;
  const g = cv.getContext('2d');
  const scenes = V3.movieScenes();
  const total = scenes.reduce((a, s2) => a + s2.dur, 0);
  const fps = opts.fps || 30;
  const stream = cv.captureStream(fps);
  const chunks = [];
  const rec = new MediaRecorder(stream, { mimeType: mime,
    videoBitsPerSecond: opts.bitrate || 6e6 });
  rec.ondataavailable = e => { if (e.data && e.data.size) chunks.push(e.data); };
  const doneP = new Promise(res => { rec.onstop = () => res(); });
  MOV = { stop: false };
  rec.start(250);

  const summary = (WZ.summary || []).slice(0, 3).join(' · ');
  let elapsed = 0;
  for (let i = 0; i < scenes.length && !MOV.stop; i++) {
    const s2 = scenes[i];
    V3.playScene(s2, i > 0);
    const t0 = performance.now();
    while (!MOV.stop) {
      const t = (performance.now() - t0) / 1000;
      if (t >= s2.dur) break;
      if (s2.spin) V3.orbit(s2.spin * 0.012);
      g.drawImage(src, 0, 0, W, H);
      movOverlay(g, W, H, s2, i, scenes.length, t / s2.dur,
        (elapsed + t) / total, null);
      if (opts.onTick) opts.onTick((elapsed + t) / total, s2, i, scenes.length);
      await new Promise(r => requestAnimationFrame(r));
    }
    elapsed += s2.dur;
  }
  // خاتمة: لوحة «تم التصميم» بالملخّص
  const tEnd = performance.now();
  while (performance.now() - tEnd < 2600 && !MOV.stop) {
    V3.orbit(0.012);
    g.drawImage(src, 0, 0, W, H);
    movOverlay(g, W, H, scenes[scenes.length - 1], scenes.length - 1,
      scenes.length, 1, 1, summary);
    await new Promise(r => requestAnimationFrame(r));
  }
  rec.stop();
  await doneP;
  MOV = null;
  return new Blob(chunks, { type: mime.split(';')[0] });
}

const MOVIE = {
  run: async () => {
    const btn = $('#movGo'), st = $('#movState'), bar = $('#movBar');
    if (MOV) { MOV.stop = true; return; }
    btn.textContent = '⏹️ إيقاف التسجيل'; btn.classList.add('gh');
    $('#movOut').innerHTML = '';
    try {
      const blob = await movieRun({
        fps: +(txt('movFps') || 30),
        bitrate: +(txt('movQ') || 6000000),
        onTick: (p, s2, i, n) => {
          if (bar) bar.style.width = (p * 100).toFixed(1) + '%';
          if (st) st.textContent = 'مشهد ' + (i + 1) + '/' + n + ' — ' + s2.title;
        } });
      const url = URL.createObjectURL(blob);
      const mb = (blob.size / 1048576).toFixed(1);
      $('#movOut').innerHTML = `
        <video src="${url}" controls style="width:100%;border-radius:10px;
          margin-top:10px;background:#000"></video>
        <div class="row" style="margin-top:8px">
          <a class="btn" href="${url}" download="بناء-${(WZ.input.area | 0)}م²-${WZ.model.floors}طوابق.webm">
            ⬇️ نزّل الفيديو (${mb} ميغا)</a>
          <button class="btn gh" onclick="MOVIE.run()">🎬 سجّل من جديد</button></div>
        <div class="note">الصيغة WebM — تشتغل بكل المتصفحات وبالواتساب والتلغرام مباشرة.
          لتحويلها MP4 استعمل أي محوّل، أو ارفعها كما هي.</div>`;
      if (st) st.textContent = 'تم — ' + mb + ' ميغا';
    } catch (e) {
      if (st) st.textContent = 'فشل التسجيل: ' + e.message;
    }
    btn.textContent = '🎬 سجّل فيديو البناء';
    btn.classList.remove('gh');
    if (bar) bar.style.width = '0%';
  },
  panel: (r) => {
    const n = V3 ? V3.movieScenes().length : 0;
    const dur = V3 ? V3.movieScenes().reduce((a, s2) => a + s2.dur, 0) + 2.6 : 0;
    return `
    <div class="card"><h3>🎬 فيديو البناء — من التربة إلى المبنى كاملاً</h3>
      <div class="note" style="margin-bottom:10px">يسجّل تسلسل البناء من مجسم
        <b>مشروعك أنت</b> — لا قالب جاهز: الطبقات الجيولوجية · الحفر والدكّ · الأساس
        وتسليحه · الأعمدة طابقاً طابقاً · الجسور · السقوف · الدرج · الكانتيليفر ·
        ثم لقطة أشعة تُظهر الحديد داخل الخرسانة، وتنتهي بدوران حول المبنى كاملاً.
        <br><b>التسجيل يتم داخل متصفحك</b> — الفيديو لا يُرفع لأي خدمة.</div>
      <div class="f">
        ${S('عدد الإطارات/ثانية', 'movFps', [['24', '24 — أخفّ حجماً'],
          ['30', '30 — متوازن'], ['60', '60 — أنعم']], '30')}
        ${S('الجودة', 'movQ', [['3000000', 'خفيفة (3 ميغابت)'],
          ['6000000', 'جيدة (6 ميغابت)'], ['12000000', 'عالية (12 ميغابت)']], '6000000')}
      </div>
      <div class="row" style="margin-top:10px">
        <button class="btn" id="movGo" onclick="MOVIE.run()">🎬 سجّل فيديو البناء</button>
        <span id="movState" style="font-size:12px;color:var(--mut);align-self:center">
          ${n} مشهد · ${dur.toFixed(0)} ثانية تقريباً</span></div>
      <div style="height:6px;background:rgba(255,255,255,.08);border-radius:3px;margin-top:8px">
        <div id="movBar" style="height:100%;width:0%;background:var(--acc);
          border-radius:3px;transition:width .2s"></div></div>
      <div id="movOut"></div>
      ${table(['المشهد', 'ماذا يُعرض', 'المدة'], (V3 ? V3.movieScenes() : []).map(s2 =>
        [s2.title, s2.sub || '—', s2.dur.toFixed(1) + ' ث']))}
      <div class="note">أثناء التسجيل تبقى الصفحة مفتوحة والمجسم يتحرّك أمامك — هذا
        هو ما يُسجَّل بالضبط. لا تبدّل التبويب حتى ينتهي.</div></div>`;
  }
};

/* ═══════════ تفاصيل الحسابات: المعادلة فالتعويض فالبند ═══════════

   إضافة خالصة فوق المعالج: لا تُعدّل خطوةً من خطواته ولا رقماً من أرقامه،
   وإنما تأخذ ما صمّمه **هو** وتُظهر كيف خرج — معادلةً رمزية، ثم تعويضاً
   بالأرقام، ثم رقم البند ونصّ ما يفرضه. والحساب يجري في `calcdoc.py`
   وحده، فلا نسختان تتباعدان.                                          */
const CALCTABS = [['col', '🟫 الأعمدة'], ['beam', '🟩 الجسور'],
                  ['fnd', '🟦 الأسس'], ['slab', '🧱 البلاطة']];

function calcPayloads(k) {
  const r = WZ;
  if (!r) return null;
  if (k === 'col') {
    const c = r.model.col, rb = c.rebar, H = r.model.story_h;
    const hb = (r.model.beams && r.model.beams.x ? r.model.beams.x.h : 600) / 1000;
    return { note: 'العمود النموذجي الذي صمّمه المعالج — والأرقام هي أرقامه نفسها.',
      sum: [['المقطع', `${int(c.b)}×${int(c.h)} مم`, 'ltr'],
            ['التسليح', `${rb.n}Ø${rb.db}`, 'ltr'],
            ['الأساور', `Ø${rb.tie_db}@${int(rb.tie_s)}`, 'ltr'],
            ['ارتفاع الطابق', nf(H, 2) + ' م', 'ltr']],
      p: [{ what: 'col_long', b: c.b, h: c.h, db: rb.db, n_bars: rb.n, Ast: rb.Ast,
            fc: r.input.fc, fy: r.input.fy, cover: rb.cover, db_tie: rb.tie_db,
            Pu: r.Pumax, Mu: r.col.Mu, phiPn: rb.phiPn_max, phiMn: rb.phiMn },
          { what: 'col_ties', H: H, b: c.b, h: c.h, db_long: rb.db, db_tie: rb.tie_db,
            s_mid: rb.tie_s, s_conf: rb.tie_s_conf, lo: rb.conf_len,
            ln: Math.max(0.5, H - hb) }] };
  }
  if (k === 'beam') {
    const b = r.beams.x, m = r.model.beams.x, dg = b.design[0], fx = dg.flex;
    const trib = m.sec.trib;
    const wu = 1.2 * (r.floor.D * trib + b.sw) + 1.6 * (r.floor.L * trib);
    const sup = (b.supports || []).filter(s => s.flex)
      .sort((x, y) => Math.abs(y.M) - Math.abs(x.M))[0];
    const p = [
      { what: 'beam_moment', w: wu, L: dg.L, ln: m.detail.ln,
        kind: b.design.length > 1 ? 'end_int' : 'interior', M: dg.Mpos, V: dg.Vu },
      { what: 'beam_steel', b: fx.b, bw: m.b, h: m.h, d: fx.d, Mu: fx.Mu,
        fc: fx.fc, fy: fx.fy, db: fx.bars.db, n_bars: fx.bars.n,
        As_used: fx.bars.As, cover: m.rebar.cover }];
    if (sup) p.push({ what: 'beam_steel', b: sup.flex.b, bw: m.b, h: m.h,
      d: sup.flex.d, Mu: sup.flex.Mu, fc: sup.flex.fc, fy: sup.flex.fy,
      db: sup.flex.bars.db, n_bars: sup.flex.bars.n, As_used: sup.flex.bars.As,
      cover: m.rebar.cover });
    return { note: 'الحمل شريحةٌ كاملة من البلاطة بعرض ' + nf(trib, 2) + ' م '
        + '(الجانب الآمن)، والعزوم من تحليل الجائز المستمر لا من المعاملات — '
        + 'والمعاملات معروضة للمقارنة.',
      sum: [['المقطع', `${int(m.b)}×${int(m.h)} مم`, 'ltr'],
            ['البحر', nf(dg.L, 2) + ' م', 'ltr'],
            ['wu', nf(wu, 1) + ' kN/م', 'ltr'],
            ['السفلي / العلوي', `${m.rebar.bottom.n}Ø${m.rebar.bottom.db}`
              + ` · ${m.rebar.top.n}Ø${m.rebar.top.db}`, 'ltr']],
      p: p };
  }
  if (k === 'fnd') {
    const rf = r.design && r.design.raft;
    if (rf && rf.h) {          // الحصيرة: منطق تصميمها مختلف، فوثيقتها مختلفة
      const c = r.model.col, g = r.grid;
      return { note: 'الحصيرة التي صمّمها المعالج — سماكتها يقرّرها القصّ '
          + 'الثاقب تحت أثقل عمود وحده.',
        sum: [['المساحة', nf(rf.A, 0) + ' م²', 'ltr'],
              ['السماكة', `${int(rf.h)} مم`, 'ltr'],
              ['العلوي / السفلي', `Ø${rf.top.db}@${int(rf.top.s)}`
                + ` · Ø${rf.bottom.db}@${int(rf.bottom.s)}`, 'ltr'],
              ['الخرسانة', nf(rf.conc, 0) + ' م³', 'ltr']],
        p: [{ what: 'raft', total: r.total, Pmax: r.Pumax, Lx: rf.Lx, Ly: rf.Ly,
              h: rf.h, d: rf.d, q_serv: rf.q_serv, q_u: rf.q_u, qa: rf.qa,
              cx: c.b, cy: c.h, span: Math.max(g.sx, g.sy), fc: r.input.fc,
              fy: r.input.fy, cover: rf.cover, top: rf.top, bottom: rf.bottom },
            { what: 'bars', L: rf.Lx, s: rf.top.s / 1000, cover: 0.075,
              label: 'الشبكة العلوية للحصيرة', db: rf.top.db }] };
    }
    const t = r.design && r.design.typical;
    if (!t || !t.B) return { err: 'نظام الأساس المختار هنا ('
      + ((r.design && r.design.name) || '—') + ') لا اشتقاقَ مفصَّلاً له بعد. '
      + 'راجع بطاقة الأساس أعلاه.' };
    return { note: 'الأساس النموذجي (أثقل عمود). كل فحصٍ على البُعد والسماكة '
        + 'اللذين خرج بهما المعالج فعلاً.',
      sum: [['الأبعاد', `${nf(t.B, 2)} × ${nf(t.B, 2)} م`, 'ltr'],
            ['السماكة', `${int(t.h)} مم`, 'ltr'],
            ['التسليح', `Ø${t.bar_db} @ ${int(t.spacing)} مم`, 'ltr'],
            ['P خدمة / مُعامَل', `${int(t.Ps)} / ${int(t.Pu)} kN`, 'ltr']],
      p: [{ what: 'footing', Ps: t.Ps, Pu: t.Pu, B: t.B, h: t.h, d: t.d,
            c1: t.cx, c2: t.cy, fc: t.fc, fy: t.fy, qa: r.input.qa,
            q_net: t.q_net, cover: 75, db: t.bar_db, s_exec: t.spacing,
            Mux: 0, Muy: 0 },
          { what: 'bars', L: t.B, s: t.spacing / 1000, cover: 0.075,
            label: 'الأساس المنفرد', db: t.bar_db }] };
  }
  const s = r.model.slab, me = s.mesh && s.mesh.short;
  if (!me) return { err: 'لا شبكة حديد معروضة لهذا النوع من السقوف.' };
  return { note: 'شبكة السقف: حدّ التباعد الكودي أوّلاً، ثم العدد الذي يفرضه '
      + 'ذلك التباعد على عرض المبنى.',
    sum: [['السقف', s.name || s.kind], ['السماكة', `${int(s.h)} مم`, 'ltr'],
          ['الشبكة', `Ø${me.db} @ ${int(me.s)} مم`, 'ltr'],
          ['عرض المبنى', nf(r.grid.L, 2) + ' م', 'ltr']],
    p: [{ what: 'slab_limits', h: s.h / 1000, cover: 0.02, db: me.db,
          fy: r.input.fy, kind: s.kind === 'two' ? 'two' : 'one' },
        { what: 'bars', L: r.grid.L, s: me.s / 1000, cover: 0.02,
          label: 'شبكة السقف (الاتجاه القصير)', db: me.db }] };
}

const TABS = {
  /* ---------- تفاصيل الحسابات: اشتقاق كل رقم ببنده ---------- */
  calc: () => TABS.cpick('col'),

  cpick: (k) => {
    $$('#cdbar button').forEach(b => b.classList.toggle('hot', b.dataset.c === k));
    const host = $('#cdbody');
    if (!host) return;
    const d = calcPayloads(k);
    if (!d) { host.innerHTML = `<div class="note">شغّل المعالج أولاً.</div>`; return; }
    if (d.err) { host.innerHTML = `<div class="note">${d.err}</div>`; return; }
    if (!window.CALCDOC) {
      host.innerHTML = `<div class="note">وحدة التفاصيل غير محمَّلة (calcdoc.js).</div>`;
      return;
    }
    window.CALCDOC.into(host, d.p, { summary: d.sum, note: d.note });
  },

  /* ---------- الأشعة الإنشائية على هندسة المشروع نفسه ---------- */
  xr: async () => {
    const r = WZ, g = r.grid, m = r.model;
    const x = await post('xray', {
      bays: Array(g.nx).fill(g.sx), heights: Array(m.floors).fill(m.story_h),
      beam_b: m.beams.x.b, beam_h: m.beams.x.h, col_b: m.col.b, col_h: m.col.h,
      db_col: m.col.rebar.db, nb_bars: m.col.rebar.nb, nh_bars: m.col.rebar.nb,
      fc: r.input.fc, fy: r.input.fy, wD: r.floor.D, wL: r.floor.L, trib: g.sy,
      seismic: true, city: r.input.city, site: 'D' });
    const bad = x.members.filter(m2 => m2.ratio > 1), warn = x.members.filter(m2 => m2.ratio > .9 && m2.ratio <= 1);
    const dOK = x.drift.every((d, i) => d <= x.drift_lim[i]);
    const beams = x.members.filter(m2 => m2.kind === 'beam'), cols = x.members.filter(m2 => m2.kind === 'col');
    $('#wp_xr').outerHTML = `<div id="wp_xr"><div class="grid g4">
      ${kpi('عدد العناصر', x.members.length)}
      ${kpi('أعلى نسبة استغلال', nf(x.worst, 2), x.worst <= 1 ? 'ok' : 'bad')}
      ${kpi('عناصر غير كافية', bad.length, bad.length ? 'bad' : 'ok')}
      ${kpi('عناصر حرجة (0.9–1.0)', warn.length, warn.length ? 'warn' : 'ok')}
      ${kpi('قص القاعدة الزلزالي', x.seismic ? nf(x.seismic.V, 1) + ' kN' : '—')}
      ${kpi('أقصى انزياح طابقي', nf(Math.max(...x.drift), 1) + ' مم', dOK ? 'ok' : 'bad')}
      ${kpi('خرسانة الإطار', nf(x.conc, 2) + ' م³')}
      ${kpi('التشخيص', x.worst <= 1 && dOK ? 'سليم ✓' : 'يحتاج معالجة', x.worst <= 1 && dOK ? 'ok' : 'bad')}</div>
    <div class="card" style="margin-top:14px"><h3>خريطة نسبة الاستغلال لكل عنصر</h3>${xraySVG(x)}
      <div class="legend"><span><i style="background:#34d399"></i>آمن ≤ 0.70</span>
        <span><i style="background:#a3e635"></i>0.70–0.90</span><span><i style="background:#fbbf24"></i>حرج 0.90–1.00</span>
        <span><i style="background:#f87171"></i>غير كافٍ > 1.00</span>
        <span>تراكيب الأحمال: ${x.combos.join(' · ')}</span></div>
      <div class="note">التحليل على إطار المشروع نفسه (${g.nx} بحر × ${m.floors} طابق ·
        جسر ${m.beams.x.b}×${m.beams.x.h} · عمود ${m.col.b}×${m.col.h}) — لا حاجة لإدخال الأرقام يدوياً.</div></div>
    ${zoneMapCard(beams)}
    <div class="grid g2" style="margin-top:14px">
      <div class="card"><h3>الجسور</h3><div style="max-height:380px;overflow:auto">
        ${table(['طابق', 'البحر', 'M+', 'M−', 'V', 'سفلي', 'علوي', 'أساور', 'النسبة'],
          beams.map(m2 => [m2.story, m2.pos, nf(m2.det.Mpos, 1), nf(m2.det.Mneg, 1), nf(m2.det.V, 1),
            m2.det.bot, m2.det.top, m2.det.stirrups,
            `<b style="color:${rcol(m2.ratio)}">${nf(m2.ratio, 2)}</b>`]))}</div></div>
      <div class="card"><h3>الأعمدة</h3><div style="max-height:380px;overflow:auto">
        ${table(['طابق', 'المحور', 'Pu', 'Mu', 'φMn', 'التسليح', 'النسبة'],
          cols.map(m2 => [m2.story, m2.pos, nf(m2.det.P, 1), nf(m2.det.M, 1), nf(m2.det.phiMn, 1),
            m2.det.bars, `<b style="color:${rcol(m2.ratio)}">${nf(m2.ratio, 2)}</b>`]))}</div></div>
      <div class="card"><h3>الانزياح الطابقي (Drift)</h3>
        ${table(['الطابق', 'المكبّر (مم)', 'الحد (مم)', 'الحالة'],
          x.drift.map((d, i) => [i + 1, nf(d, 2), nf(x.drift_lim[i], 1), tag(d <= x.drift_lim[i])]))}</div>
      <div class="card"><h3>ملخص النموذج</h3>${table(['البند', 'القيمة'], [
        ['عدد العقد', x.nodes.length], ['البحور × الطوابق', x.nb + ' × ' + x.ns],
        ['حمل الجسر الميت', nf(x.gD, 2) + ' kN/م'], ['حمل الجسر الحي', nf(x.gL, 2) + ' kN/م'],
        ['وزن الإطار W', int(x.W) + ' kN'],
        ['صلابة مشقّقة', 'جسور 0.35Ig · أعمدة 0.70Ig (ACI 6.6.3.1.1)']])}</div></div></div>`;
  },
  /* ---------- أنواع السقوف مع تبديل حي يعيد بناء المجسم ---------- */
  slabs: async () => {
    const r = WZ, g = r.grid;
    const s = await post('slabtypes', { span: Math.max(g.sx, g.sy), span2: Math.min(g.sx, g.sy),
      live: r.floor.L, wD: r.floor.D - r.floor.slab_sw, fc: r.input.fc,
      nspans: Math.max(g.nx, g.ny), hordi: r.input.hordi });
    const lo = Math.min(...s.types.filter(t => t.ok).map(t => t.sw));
    $('#wp_slabs').outerHTML = `<div id="wp_slabs">
      <div class="selbox">النوع الحالي: <b>${r.model.slab.name}</b> · سماكة ${int(r.model.slab.h)} مم ·
        وزن ذاتي ${nf(r.floor.slab_sw, 2)} kN/m² — اضغط أي نوع ليُعاد تصميم المشروع والمجسم عليه فوراً.</div>
      <div class="v3bar">${s.types.map(t => `<button class="${t.kind === r.model.slab.type ? 'hot' : ''}"
        onclick="TABS.pick('${t.kind}')">${t.name}${t.recommended ? ' ✓' : ''}</button>`).join('')}</div>
      <div class="card"><h3>المقارنة على بحر ${nf(s.span, 2)} م</h3>
        ${table(['النوع', 'المدى المناسب', 'السماكة (مم)', 'الوزن الذاتي (kN/m²)', 'مقابل المصمتة', 'الملاحظة'],
          s.types.map(t => [t.name + (t.recommended ? ' <span class="tag t-ok">موصى به</span>' : '')
              + (t.kind === r.model.slab.type ? ' <span class="tag t-warn">المختار</span>' : ''),
            t.span_range, t.ok ? int(t.h) : '—',
            t.ok ? `<b style="color:${t.sw <= lo * 1.05 ? '#34d399' : '#e6edf7'}">${nf(t.sw, 2)}</b>` : '—',
            t.ok ? nf((t.sw - s.types[0].sw) / s.types[0].sw * 100, 0) + '%' : '—', t.note]))}
        <div class="note">${s.note}</div></div>
      <div class="grid g2" style="margin-top:14px">${s.types.filter(t => t.ok && t.rows).map(t =>
        `<div class="card"><h3>${t.name}${t.kind === r.model.slab.type ? ' — المختار ✓' : ''}</h3>
          ${table(['البند', 'القيمة'], t.rows.map(x => [x[0], x[1]]))}
          ${t.detail && t.detail.note ? `<div class="note">${t.detail.note}</div>` : ''}</div>`).join('')}
      </div></div>`;
  },
  pick: async (kind) => {
    $('#w_slab').value = kind;
    const box = $('#w_hordi'); if (box) box.style.display = ['auto', 'hordi'].includes(kind) ? '' : 'none';
    await PAGES.wizard.run();
    setTimeout(() => wtab('slabs'), 400);
  },
  /* ---------- الكميات وجدول الحديد ---------- */
  boq: async () => {
    const r = WZ, b = await post('bbs', r);
    $('#wp_boq').outerHTML = `<div id="wp_boq"><div class="grid g4">
      ${kpi('وزن الحديد الكلي', nf(b.total_ton, 1) + ' طن', 'ok')}
      ${kpi('عدد القطع', int(b.bars) + ' سيخ')}
      ${kpi('هدر الوصلات', nf(b.lap_pct, 1) + '%')}
      ${kpi('طول السيخ بالسوق', int(b.stock) + ' م')}
      ${kpi('الكلفة التقديرية', int(r.boq.total) + ' د.ع', 'ok')}
      ${kpi('خرسانة الأساس', nf(r.design.conc, 1) + ' م³')}
      ${kpi('قاعدة الوصلات', b.lap_mode)}
      ${kpi('حفريات', nf(r.earth.cut_vol, 0) + ' م³')}</div>
      <div class="grid g2" style="margin-top:14px">
      <div class="card"><h3>الكلفة التقديرية</h3>
        ${table(['البند', 'الكمية', 'الوحدة', 'السعر', 'الكلفة (د.ع)'],
          r.boq.rows.map(x => [x.name, nf(x.q, 1), x.unit, int(x.rate), int(x.cost)]))}</div>
      <div class="card"><h3>الحديد حسب القطر</h3>
        ${table(['القطر', 'العدد', 'الطول (م)', 'الوزن (كغم)', 'الوصلات'],
          b.by_db.map(x => ['Ø' + x.db, int(x.count), nf(x.length, 0), nf(x.weight, 0), int(x.laps)]))}
        <div class="row" style="margin-top:10px"><button class="btn gh" onclick="go('bbs')">📊 جدول التقطيع الكامل</button>
          <button class="btn gh" onclick="PAGES.wizard.dxf('rebar')">📐 تفاصيل التسليح DXF</button></div></div>
      </div>
      <div class="card" style="margin-top:14px"><h3>جدول تقطيع الحديد (BBS)</h3>
        <div style="max-height:420px;overflow:auto">${table(
          ['الرمز', 'العنصر', 'Ø', 'الشكل', 'طول السيخ', 'قطع', 'العدد', 'الوصلات', 'الوزن (كغم)'],
          b.rows.map(x => [x.mark, x.elem, x.db ? 'Ø' + x.db : '—', x.shape, nf(x.run, 2),
            x.pieces, int(x.count), int(x.laps), nf(x.weight, 1)]))}</div>
        <div class="note">${b.note}</div></div></div>`;
  },
  /* ---------- الإنشائيات والتجربة: اختيار بالضغط على المجسم ---------- */
  lab: () => { LAB_SEL = null; LAB_MULTI = []; renderLab(null); },
  /* ---------- تقرير مطابقة ACI 318-19 ---------- */
  aci: async () => {
    const r = await post('aci', WZ);
    const IC = { ok: '✓', warn: '⚠', fail: '✗', na: '—', review: '?' };
    const CL = { ok: 'var(--ok)', warn: '#fbbf24', fail: '#f87171',
                 na: 'var(--mut)', review: '#c084fc' };
    $('#wp_aci').innerHTML = `
      <div class="grid g4">
        ${kpi('بنود مفحوصة', r.total)}
        ${kpi('مطابق', r.counts.ok, 'ok')}
        ${kpi('قريب من الحدّ', r.counts.warn, r.counts.warn ? 'warn' : 'ok')}
        ${kpi('مخالف', r.counts.fail, r.counts.fail ? 'bad' : 'ok')}
      </div>
      <div class="rec" style="margin-top:12px"><h3>📕 ${r.code} — ${r.verdict}</h3>
        <div style="font-size:12.5px;color:var(--mut);line-height:1.8">${r.note}</div></div>
      ${r.sections.map(s2 => `
        <div class="card" style="margin-top:12px"><h3>${s2.name} (${s2.rows.length} بند)</h3>
          ${table(['', 'البند', 'الفحص', 'القيمة المحسوبة', 'الحدّ الكودي', 'ملاحظة'],
            s2.rows.map(x => [
              `<b style="color:${CL[x.state]};font-size:15px">${IC[x.state]}</b>`,
              `<code style="color:var(--acc2)">${x.clause}</code>`,
              x.title,
              `<b style="color:${CL[x.state]}">${x.value}</b>`,
              x.limit,
              `<span style="font-size:11.5px;color:var(--mut)">${x.note || ''}</span>`]))}
        </div>`).join('')}
      <div class="note">الخريطة الكاملة لتطبيق الكود — أي بند مطبَّق وأين بالشيفرة
        وبأي معادلة وما لم يُطبَّق بعد — بملف <code>ACI318.md</code> بجذر المشروع.</div>`;
  },
  /* ---------- فيديو البناء ---------- */
  movie: () => { $('#wp_movie').innerHTML = MOVIE.panel(WZ); },
  /* ---------- مخطط DWG/DXF ---------- */
  plan: () => renderPlan(),
};

/* ================= استيراد مخطط DWG/DXF وتطبيقه ================= */
let PLR = null;          // العناصر الخام من المتصفح
let PLD = null;          // نتيجة التحليل من السيرفر
const ROLE_AR = { col: 'أعمدة', wall: 'جدران', axis: 'محاور', other: 'عرض فقط', off: 'تجاهل' };

const planWhy = () => `<ul style="padding-right:18px;font-size:12.5px;color:var(--mut);line-height:1.9">
  <li>القراءة تتم <b>داخل متصفحك</b> — الملف لا يُرفع لأي خدمة خارجية. محرّك DWG
      يُحمَّل مرة واحدة (~2.3 ميغا مضغوط) ثم يُخزَّن بالمتصفح، وإن تعذّر صدّر المخطط DXF.</li>
  <li>يُستخرج منه <b>مواقع الأعمدة</b> و<b>الجسور</b> و<b>المحاور</b> و<b>حدّ البناء</b>
      و<b>الدرج والمصاعد</b>، والمقياس من <b>الأبعاد المكتوبة</b> بالمخطط نفسه.</li>
  <li>الملف الواحد قد يحوي <b>عدة مخططات</b> جنب بعض — تُفصل كلها ويُختار صاحب أكثر أعمدة،
      وتقدر تبدّله من قائمة «المخطط داخل الملف».</li>
  <li>بمجرد الرفع <b>يُعاد تصميم المشروع</b> على أعمدتك الحقيقية — لا حاجة لزر،
      ويبقى المخطط ظاهراً خلفيةً تحت المجسم للمقارنة.</li>
</ul>`;

function planHead(msg) {
  return `<div class="card"><h3>📐 الأوتوكاد</h3>
      <div class="note" style="margin-bottom:8px">عندك ملف إنشائي بعدة لوحات (سقوف · جسور · أعمدة · جداول)؟
        <button class="btn" onclick="go('cad')" style="margin-inline-start:6px">🧩 افتح قسم الأوتوكاد الكامل</button></div>
      <div class="f"><div><label>ملف DWG أو DXF</label>
        <input type="file" id="pl_file" accept=".dwg,.dxf" onchange="loadPlanFile(this)"></div></div>
      <div id="pl_msg" class="note" style="margin-top:10px">${msg || 'لم يُرفع مخطط بعد.'}</div>
      <details class="fold"><summary>ليش المخطط؟ وكيف تُقرأ الملفات</summary>${planWhy()}</details></div>`;
}

// أنواع المخطط: تفضيل يدوي من القائمة يتقدّم دائماً على تخمين plan.py.
// يُصفَّر مع كل ملف جديد لئلا يبقى تفضيل ملفٍ سابق عالقاً على ملف مختلف.
const PLAN_KIND_OPTS = [['struct', 'إنشائي (أعمدة)'], ['arch', 'معماري'], ['found', 'أساس'],
  ['rebar_top', 'تسليح علوي'], ['rebar_bot', 'تسليح سفلي'], ['rebar', 'تسليح'],
  ['facade', 'واجهة'], ['slab', 'سقف / بلاطة'], ['open', 'ساحة فارغة']];
// نص عرض واحد لبند تسليح مستخرَج من ملف الأوتوكاد: القطر ثم التباعد إن وُجد
// ثم الموضع (علوي/سفلي/كلاهما) ثم عدد الأسياخ أو الأتريات بالمجموعة، وأخيراً
// كم مرة تكرر هذا البند بالذات (نفس القطر والتباعد والموضع معاً) بالمخطط.
const REBAR_POS_AR = { T: 'علوي', B: 'سفلي', 'B&T': 'علوي وسفلي' };
function fmtRebar(x) {
  let s = (x.role === 'tie' ? 'أتريات ⌀' : '⌀') + x.d + 'مم';
  if (x.sp) s += '@' + x.sp + 'مم';
  if (x.pos) s += ' ' + (REBAR_POS_AR[x.pos] || x.pos);
  if (x.count) s += ' (' + x.count + ' سيخ)';
  if (x.nset) s += ' (' + x.nset + '/مجموعة)';
  return s + ' — ×' + x.n;
}

async function setPlanKind(i, kind) {
  window.__plan_kinds = window.__plan_kinds || {};
  window.__plan_kinds[i] = kind;
  await replan({ plan_kinds: window.__plan_kinds });
}

// انتماء الطبقة (أساس/سلاب/أعمدة/تسليح/واجهة/أخرى) — نظام منفصل عن «الدور»
// الهندسي (col/wall/axis/...): الدور يقول كيف تُقرأ هندسة الطبقة، والانتماء
// يقول لأي نظام إنشائي بالمبنى تخصّ. تعديل المستخدم هنا يقين دائماً.
const LAYER_SUBSYS_OPTS = [['found', 'أساس'], ['slab', 'سلاب / سقف'], ['col', 'أعمدة'],
  ['rebar', 'تسليح'], ['facade', 'واجهة'], ['other', 'أخرى']];
async function setLayerSubsystem(name, sub) {
  window.__layer_subsystems = window.__layer_subsystems || {};
  window.__layer_subsystems[name] = sub;
  await replan({ layer_subsystems: window.__layer_subsystems });
}

async function loadPlanFile(inp) {
  const f = inp.files && inp.files[0];
  if (!f) return;
  window.__plan_kinds = {};
  window.__layer_subsystems = {};
  const msg = t => { const e = $('#pl_msg'); if (e) e.textContent = t; };
  try {
    msg('قراءة الملف… (' + (f.size / 1048576).toFixed(1) + ' ميغا)');
    PLR = await PlanIO.read(f, msg);
    msg('تحليل ' + PLR.ents.length + ' عنصر…');
    PLD = await post('plan/parse', PLR);
    PLD.name = f.name;
    renderPlan();
    drawPlan();
    // الرفع = التطبيق. لا زر مخفي: إن كان الاستخراج واثقاً يُبنى المشروع على المخطط فوراً
    const fr = PLD.frame;
    // ومقياس غير موثوق = **لا تطبيق تلقائي**. المخطط بلا أبعاد مكتوبة تخرج
    // بحوره ومقاطع أعمدته خطأً، وبناء مشروع عليها خطأ أكبر — فيُعرض ويُقرأ
    // ويبقى القرار للمستخدم، لا أن يُبنى عليه صامتاً.
    if (PLD.scale_trusted === false) {
      msg('⚠️ ' + f.name + ' — قرأتُ الملف وعرضتُه، لكن <b>ما طبّقتُه</b>: '
        + (PLD.n_dims ? 'أبعاده المكتوبة (' + PLD.n_dims + ') لا تكفي للثقة بالمقياس'
                      : 'لا أبعاد مكتوبة فيه إطلاقاً')
        + '. راجع التحذير أدناه — وإن كنت تعرف المقياس أدخِله يدوياً من الشريط '
        + 'ثم اضغط «✅ طبّق على المشروع». المشروع الحالي بقي كما هو.');
    } else if (fr && fr.n_cols >= 4) {
      msg('✓ ' + f.name + ' — يُبنى المشروع على مخططك الآن…'
        + (fr.n_free ? ' (' + fr.n_free + ' عمود غير مرتبط بجسر — معروض منفصلاً)' : ''));
      await applyPlan();
    } else {
      msg('⚠️ قرأت الملف لكن ما تعرّفت على أعمدة كافية (' + ((fr && fr.n_cols) || 0) + ') — '
        + 'صحّح المقياس أو المخطط المختار من الشريط فوق، أو دور طبقة الأعمدة من «🗂️ طبقات المخطط» '
        + 'أدناه، ثم اضغط «✅ طبّق على المشروع». '
        + 'المشروع الحالي بقي كما هو.');
    }
  } catch (e) {
    console.error(e);
    msg('✗ ' + (e.message || e));
  }
}

/* يعيد التحليل بعد تغيير الأدوار أو المقياس أو المخطط المختار */
async function replan(patch) {
  if (!PLR) return;
  const body = Object.assign({}, PLR, {
    roles: Object.fromEntries((PLD.layers || []).map(l => [l.name, l.role])),
    scale: PLD.scale, plan_index: PLD.plan_index, angle: PLD.angle,
    plan_kinds: window.__plan_kinds || {},
    layer_subsystems: window.__layer_subsystems || {} });
  Object.assign(body, patch || {});
  const name = PLD.name;
  PLD = await post('plan/parse', body);
  PLD.name = name;
  renderPlan();
  drawPlan();
}

/* يدير نقاط العناصر −deg مثل rotate_ents ببايثون تماماً — المخطط المائل
   حُلّل بعد تدويره لمحاور المبنى، فخلفيته لازم تُدار بنفس الزاوية وإلا
   رُسمت مائلة فوق مبنى مستقيم. */
function rotEnts(ents, deg) {
  if (!deg) return ents;
  const c = Math.cos(-deg * Math.PI / 180), s = Math.sin(-deg * Math.PI / 180);
  return ents.map(e => {
    const p = e.p, f = Object.assign({}, e);
    if (e.t === 'C' || e.t === 'T') f.p = [p[0] * c - p[1] * s, p[0] * s + p[1] * c, p[2]];
    else if (e.t === 'A') f.p = [p[0] * c - p[1] * s, p[0] * s + p[1] * c, p[2], p[3] - deg, p[4] - deg];
    else {
      const q = [];
      for (let i = 0; i + 1 < p.length; i += 2) q.push(p[i] * c - p[i + 1] * s, p[i] * s + p[i + 1] * c);
      f.p = q;
    }
    return f;
  });
}

function drawPlan() {
  if (!V3 || !PLR || !PLD) return;
  const roles = Object.fromEntries((PLD.layers || []).map(l => [l.name, l.role]));
  const cols = PLD.columns || [];
  const ents = rotEnts(PLR.ents, PLD.angle || 0);
  // نصفّر المخطط على مركز الأعمدة المكتشَفة ليقع تحت المبنى مباشرة
  // (الأعمدة بالفضاء المُدار، والعناصر أعلاه صارت فيه كذلك)
  let ox = 0, oy = 0;
  if (cols.length) {
    ox = (Math.min(...cols.map(c => c.x)) + Math.max(...cols.map(c => c.x))) / 2 / PLD.scale;
    oy = (Math.min(...cols.map(c => c.y)) + Math.max(...cols.map(c => c.y))) / 2 / PLD.scale;
  } else if (PLD.extents) {
    ox = (PLD.extents[0] + PLD.extents[2]) / 2 / PLD.scale;
    oy = (PLD.extents[1] + PLD.extents[3]) / 2 / PLD.scale;
  }
  const st = V3.planBuild({ ents: ents, layers: PLR.layers, roles: roles,
                            scale: PLD.scale, origin: [ox, oy] });
  V3.planXform({ level: +($('#pl_lvl') ? $('#pl_lvl').value : 0),
                 rot: +($('#pl_rot') ? $('#pl_rot').value : 0),
                 op: +($('#pl_op') ? $('#pl_op').value : 0.85) });
  if (!PLAN_ON) { PLAN_ON = true; tgl('btnPlan', true); }
  V3.plan(true);
  if (!XRAY_ON) toggleXray();              // الخلفية تُرى عبر السقوف
  const e = $('#pl_stat');
  if (e) e.textContent = st.layers + ' طبقة مرسومة · ' + int(st.segs) + ' قطعة خطية';
}

function renderPlan() {
  const host = $('#wp_plan');
  if (!host) return;
  if (!PLD) { host.innerHTML = planHead(); return; }
  const g = PLD.grid, b = PLD.boundary, s = PLD.suggested;
  const nfl = (WZ && WZ.model.floors) || 1;
  const applied = !!(window.__frame_override || window.__grid_override);
  const stH = (WZ && WZ.model && WZ.model.story_h) || 3.2;
  host.innerHTML = `
    <!-- ①  شريط القرار: كل ما يُغيّر المشروع بأول الصفحة -->
    <div class="pdec">
      <div class="pdec-r">
        <span class="pdec-f">📄 <b>${PLD.name}</b></span>
        <span class="tag ${applied ? 't-ok' : 't-warn'}">${applied ? 'مطبَّق على المشروع ✓' : 'غير مطبَّق'}</span>
        <span class="sp"></span>
        <button class="btn" onclick="applyPlan()">✅ طبّق على المشروع</button>
        ${applied ? `<button class="btn gh" onclick="clearPlanGrid()">↩️ رجّع التلقائي</button>` : ''}
        <button class="btn gh" onclick="togglePlan()">👁️ الخلفية</button>
        <button class="btn gh" onclick="V3&&V3.reset();$('#v3d').scrollIntoView({behavior:'smooth',block:'center'})">🧊 للمجسم</button>
      </div>
      <div class="pdec-r">
        <label>المخطط داخل الملف</label>
        <select id="pl_ix" onchange="replan({plan_index:+this.value})">
          ${(PLD.plans || []).map(p => `<option value="${p.i}" ${p.i === PLD.plan_index ? 'selected' : ''}>
            #${p.i + 1} ${p.name ? '— ' + p.name : ''} · ${p.n} عمود · ${nf(p.w, 1)}×${nf(p.h, 1)} م</option>`).join('')}
        </select>
        <label>المقياس</label>
        <select id="pl_sc" onchange="replan({scale:+this.value})">
          ${(PLD.scales || []).map(x => `<option value="${x.v}" ${Math.abs(x.v - PLD.scale) < 1e-9 ? 'selected' : ''}>
            ${x.name} (1 وحدة = ${x.v} م)</option>`).join('')}
        </select>
        <span class="pdec-s">مصدره: <b style="color:${PLD.scale_src === 'الأبعاد المكتوبة' ? 'var(--ok)' : 'var(--mut)'}">${PLD.scale_src}</b></span>
        <label>ميل المخطط</label>
        <input type="number" id="pl_ang" value="${nf(PLD.angle || 0, 2)}" step="0.5" min="0" max="89.9"
          style="width:78px;padding:5px 8px;font-size:11.5px"
          onchange="replan({angle:+this.value})">
        <span class="pdec-s">درجة</span>
        <span class="sp"></span>
        <label>بدّل الملف</label>
        <input type="file" id="pl_file" accept=".dwg,.dxf" onchange="loadPlanFile(this)"
          style="width:auto;font-size:11.5px">
      </div>
      <div id="pl_msg" class="pdec-m">✓ ${int(PLD.n_ents)} عنصر · ${PLD.layers.length} طبقة ·
        ${(PLD.plans || []).length} مخطط بالملف</div>
      ${(PLD.warnings || []).length ? `<div class="pdec-m" style="color:#fde68a">
        ${PLD.warnings.map(w => '⚠️ ' + w).join(' · ')}</div>` : ''}
    </div>

    <!-- ②  ملخّص الاستخراج -->
    <div class="grid g4" style="margin-top:12px">
      ${kpi('أعمدة مكتشَفة', (PLD.columns || []).length, (PLD.columns || []).length >= 4 ? 'ok' : 'bad')}
      ${kpi('الجسور المستخرَجة', PLD.frame ? PLD.frame.n_beams : '—')}
      ${kpi('مساحة البناء', b ? nf(b.area, 1) + ' م²' : '—')}
      ${kpi('مقطع العمود الوسيط', (() => {      // من الأعمدة المكتشَفة لا من معايرة المقياس
        const cs = (PLD.columns || []).map(c => (c.b + c.h) / 2).sort((a, b2) => a - b2);
        return cs.length ? int(cs[cs.length >> 1]) + ' مم' : (s ? int(s.median) + ' مم' : '—');
      })())}
      ${kpi('درج ونوى مصاعد', (PLD.stairs || []).length + ' درج · ' + (PLD.shafts || []).length
            + ((PLD.shafts || []).some(v => v.kind === 'C') ? ' نواة C' : ' مصعد'))}
      ${kpi('أشكال الأعمدة', (() => {
        const m = {}; (PLD.columns || []).forEach(c => m[c.shape || 'rect'] = (m[c.shape || 'rect'] || 0) + 1);
        const AR = { rect: 'مستطيل', circ: 'دائري', L: 'زاوية L', T: 'تي T' };
        const k = Object.keys(m).sort((a, b2) => m[b2] - m[a]);
        return k.length ? k.map(x => m[x] + ' ' + (AR[x] || x)).join(' · ') : '—';
      })(), (PLD.columns || []).some(c => c.shape === 'circ') ? 'ok' : '')}
      ${kpi('مساحة القطعة', PLD.plot ? nf(PLD.plot.area, 0) + ' م² = ' + nf(PLD.plot.L, 2)
            + ' × ' + nf(PLD.plot.B, 2) : '—')}
      ${kpi('المقياس', (PLD.dim_scale ? PLD.dim_scale.name : (s ? s.name : PLD.unit)),
            PLD.scale_src === 'الأبعاد المكتوبة' ? 'ok' : '')}
      ${kpi('اتجاه المخطط', PLD.angle ? nf(PLD.angle, 1) + '° — دُوِّر للمحاور' : 'محاذٍ للمحاور',
            PLD.angle ? 'warn' : 'ok')}
      ${kpi('مخططات بالملف', (PLD.plans || []).length, 'ok')}
      ${kpi('أعمدة مرتبطة / غير مرتبطة',
        (PLD.frame ? PLD.frame.n_linked : 0) + ' / ' + (PLD.frame ? PLD.frame.n_free : 0),
        (PLD.frame && PLD.frame.n_free) ? 'warn' : 'ok')}
      ${kpi('المقياس موثوق؟', PLD.scale_trusted === false
        ? '✗ لا — ' + (PLD.n_dims || 0) + ' بُعد مكتوب'
        : '✓ نعم — ' + (PLD.n_dims || 0) + ' بُعد مكتوب',
        PLD.scale_trusted === false ? 'bad' : 'ok')}
    </div>

    ${g ? `<div class="rec" style="margin-top:12px">
      <h3>🧭 ما استُخرج من مخططك وبُني عليه</h3>
      <ul>
        <li>بحور X الحقيقية: <b>${g.spans_x.map(v => nf(v, 2)).join(' · ')}</b> م ·
            Y: <b>${g.spans_y.map(v => nf(v, 2)).join(' · ')}</b> م</li>
        ${PLD.frame ? `<li>الهيكل: <b>${PLD.frame.n_cols}</b> عمود بمواقعها الحقيقية و<b>${PLD.frame.n_beams}</b> جسر
          على المحاور الحقيقية — وعليه تُبنى الأسس والسقوف.</li>
        <li>الارتباط: <b style="color:#34d399">${PLD.frame.n_linked}</b> عمود <b>مرتبط</b> بجسور${
          PLD.frame.n_free ? ` · <b style="color:#fbbf24">${PLD.frame.n_free}</b> عمود
          <b>غير مرتبط</b>` : ''} —
          ${PLD.frame.link_note ? PLD.frame.link_note.replace(/\*\*(.+?)\*\*/g, '<b>$1</b>') : ''}</li>` : ''}
        <li>أقرب شبكة منتظمة للمقارنة: ${g.nx} × ${g.ny} بحر بمسافة ${nf(g.sx, 2)} × ${nf(g.sy, 2)} م ·
            انحراف أعمدتك عنها أقصى <b style="color:${g.regular ? '#34d399' : '#fbbf24'}">${int(g.max_dev * 1000)} مم</b>
            (متوسط ${int(g.rms_dev * 1000)} مم) —
            ${g.regular ? 'أعمدتك منتظمة فعلاً ✓'
              : '<b>التصميم لا يُبنى على هذه الشبكة</b> بل على مواقع أعمدتك الحقيقية.'}</li>
        ${(PLD.dim_spans && PLD.dim_spans.x.length) ? `<li>بحور مكتوبة بالمخطط —
          X: ${PLD.dim_spans.x.slice(-6).map(v => nf(v, 2)).join(' · ')} ·
          Y: ${PLD.dim_spans.y.slice(-6).map(v => nf(v, 2)).join(' · ')}</li>` : ''}
      </ul></div>` : `<div class="note" style="margin-top:12px">
      ما قدرت أستخرج شبكة — حدّد طبقة الأعمدة الصحيحة من «طبقات المخطط» أدناه، أو صحّح المقياس فوق.</div>`}

    <!-- ③  التفاصيل الطويلة مطوية -->
    <details class="fold" style="margin-top:12px"><summary>🎛️ ضبط عرض الخلفية (دوران · شفافية · منسوب)</summary>
      <div class="v3bar" style="margin-top:8px">
        <b style="font-size:12px;color:var(--mut)">دوران:</b>
        <input type="range" id="pl_rot" min="-180" max="180" step="1" value="0" style="width:120px"
          oninput="V3&&V3.planXform({rot:+this.value});$('#pl_rotv').textContent=this.value+'°'">
        <span id="pl_rotv" style="font-size:11px;color:var(--acc2)">0°</span>
        <b style="font-size:12px;color:var(--mut)">شفافية:</b>
        <input type="range" id="pl_op" min="0.15" max="1" step="0.05" value="0.85" style="width:100px"
          oninput="V3&&V3.planXform({op:+this.value})">
        <b style="font-size:12px;color:var(--mut)">المنسوب:</b>
        <select id="pl_lvl" onchange="V3&&V3.planXform({level:+this.value})" style="width:auto;padding:6px 10px">
          <option value="0">الأرضي</option>
          ${Array.from({ length: nfl }, (_, i) => `<option value="${(i + 1) * stH}">سقف طابق ${i + 1}</option>`).join('')}
        </select>
        <button class="btn gh" style="padding:6px 12px" onclick="drawPlan()">↻ أعد الرسم</button>
        <span id="pl_stat" style="font-size:11px;color:var(--acc2)"></span>
      </div></details>

    <!-- قسم واحد: مخططات الملف وطبقاته، بشرح صريح للفرق بين «النوع/الانتماء» و«الدور» -->
    <div class="rec" style="margin-top:12px">
      <h3>🛠️ الأوتوكاد — مخططات الملف وطبقاته</h3>
      <div class="note" style="margin-bottom:8px">ملف الأوتوكاد الواحد يحوي عادةً عدة مخططات:
        أساس، وربما فرعين للتسليح (علوي وسفلي)، وواجهات، وسقوف، وساحات فارغة بلا بناء —
        وأحياناً كلها مرسومة فوق بصمة المبنى نفسها، كل جانب على طبقته الخاصة (لا جنب بعض
        بالورقة). فيه هنا نظامان منفصلان تماماً، لا تعارض بينهما: <b>«الدور»</b> يقول للطبقة
        هندسة الرسم (أعمدة/جدران/محاور/تجاهل) وتُبنى عليه كل عمليات الاستخراج، و<b>«ينتمي لـ»</b>
        يقول لأي نظام إنشائي بالمبنى تخصّ الطبقة (أساس/سلاب/أعمدة/تسليح/واجهة). كلاهما تلقائي
        من اسم الطبقة، وتقدر تصحّح أيّهما يدوياً من القوائم أدناه — تصحيحك يُعتمد يقيناً دائماً،
        وتخمين النظام حين لا يجد دليلاً («تخمين — تأكد») لا يُستعمل لاستثناء أي طبقة من حساب
        قائم، فلا يخرّب نتيجة موثوقة.</div>

      <details class="fold" open><summary>📚 المخططات الموجودة بالملف (${(PLD.plans || []).length})</summary>
        ${table(['#', 'الاسم بالمخطط', 'النوع', 'الأعمدة', 'الأبعاد', ''],
          (PLD.plans || []).map(p => [p.i + 1, p.name || '—',
            `<select onchange="setPlanKind(${p.i},this.value)"
               style="width:auto;padding:3px 8px;font-size:11px">
              ${PLAN_KIND_OPTS.map(([k, t]) => `<option value="${k}" ${k === p.kind ? 'selected' : ''}>${t}</option>`).join('')}
             </select> ${p.kind_trusted ? '<span class="tag t-ok" style="font-size:10px">تلقائي ✓</span>'
               : '<span class="tag t-warn" style="font-size:10px">تخمين — تأكد</span>'}
             ${(p.rebar || []).length ? '<div class="note" style="margin-top:4px">أقطار مكتشَفة: '
               + p.rebar.slice(0, 10).map(fmtRebar).join(' · ') + '</div>' : ''}`,
            `<b style="color:${p.n >= 4 ? '#34d399' : 'var(--mut)'}">${p.n}</b>`,
            nf(p.w, 1) + ' × ' + nf(p.h, 1) + ' م',
            p.i === PLD.plan_index ? '<span class="tag t-ok">المختار ✓</span>' : '']))}
        <div class="note">اختيار المخطط المبني عليه المشروع من قائمة «المخطط داخل الملف» بالشريط
          أعلاه — هذا الجدول للتصفّح وتصحيح نوع كلٍّ فقط.</div></details>

      <details class="fold"><summary>🗂️ طبقات الملف: دورها وانتماؤها (${PLD.layers.length})</summary>
        <div style="max-height:340px;overflow:auto">${table(['الطبقة', 'العناصر', 'الدور', 'ينتمي لـ'],
          PLD.layers.map(l => [l.name, int(l.n),
            `<select onchange="setRole('${l.name.replace(/'/g, "\\'")}',this.value)"
               style="width:auto;padding:3px 8px;font-size:11.5px">
              ${(PLD.roles || []).map(r => `<option value="${r.k}" ${r.k === l.role ? 'selected' : ''}>${r.name}</option>`).join('')}
             </select>`,
            `<select onchange="setLayerSubsystem('${l.name.replace(/'/g, "\\'")}',this.value)"
               style="width:auto;padding:3px 8px;font-size:11.5px">
              ${LAYER_SUBSYS_OPTS.map(([k, t]) => `<option value="${k}" ${k === l.subsystem ? 'selected' : ''}>${t}</option>`).join('')}
             </select> ${l.subsystem_trusted ? '<span class="tag t-ok" style="font-size:10px">تلقائي ✓</span>'
               : '<span class="tag t-warn" style="font-size:10px">تخمين</span>'}`]))}</div>
        <div class="note">«الدور» يُعاد التحليل عند تغييره تلقائياً (أعمدة/جدران/محاور). «ينتمي لـ»
          وصفي فقط حالياً: يوضّح أي نظام إنشائي تخصّ كل طبقة (أساس/سلاب/أعمدة/تسليح/واجهة)
          بلا تغيير أي حساب قائم — تصحيحه يبقى محفوظاً طالما الملف مفتوحاً.</div></details>
    </div>

    <details class="fold"><summary>🪜 الدرج والمصاعد المكتشَفة (${(PLD.stairs || []).length} · ${(PLD.shafts || []).length})</summary>
      ${(PLD.stairs || []).length ? table(['#', 'الاتجاه', 'الدرجات', 'النائمة', 'عرض القلبة', 'طول القلبة', ''],
        PLD.stairs.map((t, i) => [i + 1, t.dir === 'x' ? 'أفقي' : 'رأسي', t.steps,
          int(t.tread * 100) + ' سم', nf(t.width, 2) + ' م', nf(t.run, 2) + ' م',
          `<button class="btn gh" style="padding:3px 9px;font-size:11px"
             onclick="dropStair(${i})">احذفه</button>`]))
        : '<div class="note">ما لقيت درجاً — الكشف هندسي (تتابع درجات متوازية متساوية التباعد).</div>'}
      ${(PLD.shafts || []).length ? table(['النواة', 'الشكل', 'المقاس', 'سماكة الجدار'],
        PLD.shafts.map((v, i) => ['#' + (i + 1),
          v.kind === 'C' ? 'حرف C (مفتوحة عند الباب)' : 'مستطيلة مغلقة',
          nf(v.w, 2) + ' × ' + nf(v.h, 2) + ' م',
          v.wall ? int(v.wall * 1000) + ' مم — مقروءة من المخطط' : 'مفترضة 200 مم'])) : ''}
      <div class="note">الدرج يُصمَّم كبلاطة مائلة، وتُفتح له فتحة بالسقف بحديد تطويق حولها،
        وحمله ينتقل للجسور المحيطة. بئر المصعد يُعامل كجدران قص.</div></details>

    <details class="fold"><summary>🟦 الأعمدة المكتشَفة (${(PLD.columns || []).length})</summary>
      <div style="max-height:340px;overflow:auto">${table(['#', 'X (م)', 'Y (م)', 'المقطع (مم)'],
        (PLD.columns || []).map((c, i) => [i + 1, nf(c.x - (g ? g.x0 : 0), 2),
          nf(c.y - (g ? g.y0 : 0), 2), int(c.b) + ' × ' + int(c.h)]))}</div>
      <div class="note">${PLD.note}</div></details>`;
}

async function clearPlanGrid() {
  window.__grid_override = null; window.__footprint_override = null;
  window.__frame_override = null; window.__stairs = null; window.__shafts = null;
  if (window.__area_before != null) {
    $('#w_area').value = window.__area_before; $('#w_cov').value = window.__cov_before;
    window.__area_before = window.__cov_before = null;
  }
  await PAGES.wizard.run();
  setTimeout(() => { if (PLD) { wtab('plan'); drawPlan(); } showChange(); }, 500);
}

/* بعد أي إعادة بناء: انقل المستخدم للمجسم ووَمِّض شريط الحالة ليرى التغيير بعينه */
function showChange() {
  const v = $('#v3d'), s = $('#pstrip');
  if (v) v.scrollIntoView({ behavior: 'smooth', block: 'center' });
  if (s) { s.classList.add('flash'); setTimeout(() => s.classList.remove('flash'), 2200); }
}

async function setRole(name, role) {
  const l = (PLD.layers || []).find(x => x.name === name);
  if (l) l.role = role;
  await replan();
}

function dropStair(i) { PLD.stairs.splice(i, 1); renderPlan(); }

async function applyPlan() {
  const f = PLD && PLD.frame, g = PLD && PLD.grid;
  if (!f && !g) return alert('ما في هيكل مستخرَج — صحّح طبقة الأعمدة أو المقياس أولاً');
  const area = (PLD.boundary && PLD.boundary.area) || (g ? g.L * g.B : 0);
  // نحفظ مدخلات المستخدم الأصلية ليرجعها زر «رجّع التلقائي» كما كانت بالضبط
  if (window.__area_before == null) {
    window.__area_before = $('#w_area').value; window.__cov_before = $('#w_cov').value;
  }
  $('#w_area').value = Math.round(area);
  $('#w_cov').value = 1;
  // الهيكل الحقيقي: أعمدة وجسور بمواقعها من المخطط
  window.__frame_override = f ? { nodes: f.nodes, beams: f.beams, lines: f.spans,
    axes_x: f.axes_x, axes_y: f.axes_y,
    boundary: (PLD.boundary && PLD.boundary.poly) || null } : null;
  window.__grid_override = f ? null : { L: g.L, B: g.B, nx: g.nx, ny: g.ny, sx: g.sx, sy: g.sy,
    max_dev: g.max_dev, rms_dev: g.rms_dev, spans_x: g.spans_x, spans_y: g.spans_y };
  window.__footprint_override = Math.round(area * 100) / 100;
  window.__stairs = PLD.stairs || [];
  window.__shafts = PLD.shafts || [];
  await PAGES.wizard.run();
  setTimeout(() => { wtab('plan'); drawPlan(); showChange(); }, 500);
}

/* ---------------- مختبر التجربة داخل نفس المجسم ---------------- */
let LAB_SEL = null, LAB_RES = null;
const MODE_IC = { bending: '🌀 انحناء', shear: '✂️ قص', torsion: '🔃 التواء',
  buckling: '⬇️ ضغط وانبعاج', tension: '↔️ شد' };
const KIND_AR = { col: 'عمود', bx: 'جسر باتجاه X', by: 'جسر باتجاه Y' };

/* تحديد متعدد: كل ضغطة على عنصر تضيفه للقائمة أو تشيله منها، فتقدر تحذف
   عدة أعمدة معاً — وهذا هو السيناريو الحقيقي (انفجار · اصطدام · حريق موضعي). */
let LAB_MULTI = [];
function labSelect(u) {                     // يُستدعى عند الضغط على عنصر بالمجسم
  if (!u || !u.gk) return false;
  const k = u.gk;
  const at = LAB_MULTI.indexOf(k);
  if (at >= 0) LAB_MULTI.splice(at, 1); else LAB_MULTI.push(k);
  LAB_SEL = LAB_MULTI.length ? LAB_MULTI[LAB_MULTI.length - 1].split('|') : null;
  if (V3 && V3.labMark) V3.labMark(LAB_MULTI);
  labSelBox();
  return true;
}
function labSelBox() {
  const box = $('#lb_sel');
  if (!box) return;
  if (!LAB_MULTI.length) {
    box.innerHTML = 'اضغط على أي <b>عمود</b> أو <b>جسر</b> بالمجسم أعلاه لاختياره — '
      + 'والضغط على أكثر من عنصر يجمعها كلها لحذفها <b>معاً</b>. أو اختره من القوائم:';
    return;
  }
  box.innerHTML = `<b>المحدَّد (${LAB_MULTI.length}):</b> `
    + LAB_MULTI.map((k, i) => { const a = k.split('|');
        return `<span class="tag t-warn" style="cursor:pointer" onclick="labUnpick(${i})">
          ${KIND_AR[a[0]] || a[0]} (${a[1]}, ${a[2]}) ط${a[3]} ✕</span>`; }).join(' ')
    + ` <button class="btn" style="padding:5px 12px" onclick="runLab()">🧪 احذفها كلها وحلّل</button>
        <button class="btn gh" style="padding:5px 12px" onclick="labClearSel()">أفرغ التحديد</button>
        <button class="btn gh" style="padding:5px 12px" onclick="V3&&V3.zoomSel()">🔍 قرّب الأخير</button>`;
}
function labUnpick(i) { LAB_MULTI.splice(i, 1);
  if (V3 && V3.labMark) V3.labMark(LAB_MULTI); labSelBox(); }
function labClearSel() { LAB_MULTI = []; LAB_SEL = null;
  if (V3 && V3.labMark) V3.labMark([]); labSelBox(); }
function renderLab(r) {
  const nfl = (WZ && WZ.model.floors) || 1;
  const head = `<div class="selbox" id="lb_sel">
      اضغط على أي <b>عمود</b> أو <b>جسر</b> بالمجسم أعلاه لاختياره — والضغط على أكثر من
      عنصر يجمعها كلها لحذفها <b>معاً</b>. أو اختره من القوائم:</div>
    <div class="v3bar">
      <select id="lb_tag" style="width:auto;padding:6px 10px">
        <option value="col">عمود</option><option value="bx">جسر باتجاه X</option>
        <option value="by">جسر باتجاه Y</option></select>
      <select id="lb_i" style="width:auto;padding:6px 10px">${
        Array.from({ length: (WZ ? WZ.grid.nx : 1) + 1 }, (_, i) => `<option>${i}</option>`).join('')}</select>
      <select id="lb_j" style="width:auto;padding:6px 10px">${
        Array.from({ length: (WZ ? WZ.grid.ny : 1) + 1 }, (_, i) => `<option>${i}</option>`).join('')}</select>
      <select id="lb_k" style="width:auto;padding:6px 10px">${
        Array.from({ length: nfl }, (_, i) => `<option>${i + 1}</option>`).join('')}</select>
      <button class="btn" style="padding:6px 14px" onclick="runLab(1)">🧪 احذف وحلّل</button>
      <button class="btn gh" style="padding:6px 14px" onclick="runLab(0,1)">↩️ رجّع العنصر</button>
      <button class="btn gh" style="padding:6px 14px" onclick="runSweep()">🗺️ مسح شامل — أي عمود هو الأحرج؟</button>
      <button class="btn gh" style="padding:6px 14px" onclick="runSweep(1)">🗺️ مسح كل الأعمدة (أبطأ)</button>
    </div>
    <div id="lb_sweep"></div>
    <div class="hint">المحاور i بالاتجاه X و j بالاتجاه Y وتبدأ من 0 — العمود الركني (0,0).
      بعد التحليل تتلوّن كل العناصر بالمجسم حسب نسبة استغلالها، ويختفي العنصر المحذوف،
      واضغط أي عنصر لترى نسبه الخمس قبل الحذف وبعده.</div>`;
  if (!r) { $('#wp_lab').innerHTML = head +
    `<div class="note">لم تُجرَ تجربة بعد — اختر عنصراً واضغط «احذف وحلّل».
      المنهجية: حذف عنصر رئيسي وإعادة التحليل الفراغي لدراسة المسار البديل للأحمال
      (Alternate Load Path — GSA / UFC 4-023-03).</div>`; return; }
  const rows = r.rows || [], byMode = {};
  rows.filter(x => x.fail).forEach(x => { byMode[x.mode] = (byMode[x.mode] || 0) + 1; });
  const worst = rows[0];
  $('#wp_lab').innerHTML = head + `
    <div class="rec" style="margin-top:12px"><h3>${r.removed ? '🧪 نتيجة الحذف' : '↩️ الحالة الأصلية'}</h3>
      <ul>${r.summary.map(x => `<li>${x}</li>`).join('')}</ul></div>
    <div class="grid g4" style="margin-top:14px">
      ${Object.keys(MODE_IC).map(m => kpi(MODE_IC[m], (byMode[m] || 0) + ' عنصر',
        byMode[m] ? 'bad' : 'ok')).join('')}
      ${kpi('عناصر تجاوزت مقاومتها', r.fails || 0, r.fails ? 'bad' : 'ok')}
      ${kpi('أقصى انزياح بعد الحذف', nf(Math.max(...(r.drift || [0]).map(Math.abs)), 1) + ' مم')}
      ${kpi('قبل الحذف', nf(Math.max(...(r.drift_before || [0]).map(Math.abs)), 1) + ' مم')}
      ${kpi('أشد عنصر متأثر', worst ? (KIND_AR[worst.tag] || worst.tag) + ' ' + nf(worst.after, 2) : '—',
        worst && worst.after > 1 ? 'bad' : 'ok')}</div>
    <div class="note" style="margin-top:12px">${r.base_note || ''}</div>
    ${worst ? `<div class="card" style="margin-top:14px">
      <h3>🧱 ماذا يحصل للعنصر — أنواع الإجهادات الخمسة</h3>
      <div class="note" style="margin-bottom:10px">أشدّ عنصر متأثر:
        <b>${KIND_AR[worst.tag] || worst.tag}</b> عند المحور (${worst.key[1]}, ${worst.key[2]})
        طابق ${worst.story} — النمط الحاكم بعد الحذف <b>${worst.mode_ar}</b>${
          worst.mode_before && worst.mode_before !== worst.mode
            ? ' (وكان قبله ' + worst.mode_before_ar + ' — <b>تغيّر نمط الفشل نفسه</b>)' : ''}.</div>
      ${stressCards(worst.mode, worst.modes)}</div>` : ''}
    ${worst ? `<div class="card" style="margin-top:14px">
      <h3>📈 كيف تغيّرت العزوم والقوى فعلاً — بالأرقام لا بالنسب</h3>
      ${table(['العنصر', 'المحور', 'طابق', 'العزم M (kN·م)', 'القص V (kN)',
               'الالتواء T (kN·م)', 'المحوري N (kN)'],
        rows.slice(0, 14).map(x => [KIND_AR[x.tag] || x.tag,
          '(' + x.key[1] + ', ' + x.key[2] + ')', x.story,
          `${nf(x.M0, 1)} ← <b style="color:${x.dM > 0 ? '#f87171' : '#34d399'}">${nf(x.M, 1)}</b>` +
            (x.xM ? ` <span style="color:var(--mut);font-size:11px">(×${nf(x.xM, 2)})</span>` : ''),
          `${nf(x.V0, 1)} ← <b>${nf(x.V, 1)}</b>`,
          `${nf(x.T0, 2)} ← <b>${nf(x.T, 2)}</b>`,
          `${nf(x.N0, 0)} ← <b>${nf(x.N, 0)}</b>`]))}
      <div class="note"><b>لماذا تقفز العزوم:</b> العمود المحذوف كان مسنداً، وبزواله
        يصير البحران المجاوران بحراً واحداً طوله الضعف. وعزم الانحناء يتناسب مع
        <b>مربّع</b> البحر، فمضاعفة البحر تُربّع العزم تقريباً — ولهذا ترى أضعافاً لا
        نسباً مئوية. والحمل نفسه لم يزد ولم ينقص، بل <b>انتقل</b>: مجموع العزوم
        يرتفع لأن المسار البديل أطول وأقل كفاءة.</div></div>` : ''}
    <div class="card" style="margin-top:14px"><h3>العناصر الأكثر تأثراً (${rows.length})</h3>
      <div style="max-height:430px;overflow:auto">${table(
        ['العنصر', 'المحور', 'طابق', 'قبل', 'بعد', 'الفرق', 'النمط الحاكم',
         'انحناء', 'قص', 'التواء', 'انبعاج', 'شد', ''],
        rows.map(x => [KIND_AR[x.tag] || x.tag, '(' + x.key[1] + ', ' + x.key[2] + ')', x.story,
          nf(x.before, 2), `<b style="color:${rcol(x.after)}">${nf(x.after, 2)}</b>`,
          (x.delta >= 0 ? '+' : '') + nf(x.delta, 2), x.mode_ar,
          ...['bending', 'shear', 'torsion', 'buckling', 'tension'].map(m =>
            `<span style="color:${rcol(x.modes[m])}">${nf(x.modes[m], 2)}</span>`),
          `<button class="btn gh" style="padding:3px 9px;font-size:11px"
            onclick="labFocus('${x.key.join('|')}')">اعرضه</button>`]))}</div>
      <div class="note">${r.note}</div></div>`;
}
function labFocus(gk) {
  if (!V3 || !V3.focus) return;
  V3.focus(gk);
}
/* مسح شامل: يحذف كل عمود على حدة ويرتّب المبنى حسب هشاشته */
async function runSweep(full) {
  const box = $('#lb_sweep');
  box.innerHTML = '<div class="note">جارٍ حذف كل عمود على حدة وإعادة التحليل الفراغي… قد يستغرق ثوانٍ.</div>';
  const r = await post('lab/sweep', Object.assign({}, WZ.input, { full: !!full, story: 1 }));
  const mx = Math.max(...r.rows.map(x => x.worst), 1);
  box.innerHTML = `<div class="rec" style="margin-top:12px"><h3>🗺️ خريطة الهشاشة — أي عمود هو الأحرج؟</h3>
      <ul>${r.summary.filter(Boolean).map(x => `<li>${x}</li>`).join('')}</ul></div>
    <div class="card" style="margin-top:12px"><h3>ترتيب الأعمدة حسب أثر حذفها</h3>
      ${table(['#', 'العمود', 'المحور', 'Pu (kN)', 'عناصر تنهار', 'أعلى نسبة بعد الحذف',
               'الانزياح (مم)', 'أنماط الفشل', 'الحكم', ''],
        r.rows.map((x, i) => [i + 1,
          `<span class="tag ${x.kind === 'داخلي' ? 't-ok' : 't-warn'}">${x.kind}</span>`,
          '(' + x.i + ', ' + x.j + ')', int(x.Pu),
          `<b style="color:${x.fails ? '#f87171' : '#34d399'}">${x.fails}</b>`,
          `<div style="display:flex;align-items:center;gap:6px">
             <div style="flex:1;height:7px;background:#1b2942;border-radius:4px;overflow:hidden">
               <div style="width:${Math.min(100, x.worst / mx * 100)}%;height:100%;background:${rcol(x.worst)}"></div>
             </div><b style="color:${rcol(x.worst)}">${nf(x.worst, 2)}</b></div>`,
          nf(x.drift, 1),
          x.modes.length ? x.modes.map(m => m.name + ' ×' + m.n).join(' · ') : '—',
          x.ok ? '<span class="tag t-ok">ينجو</span>' : '<span class="tag t-bad">' + x.verdict + '</span>',
          `<button class="btn gh" style="padding:3px 9px;font-size:11px"
            onclick="labRemoveAt('${x.i}','${x.j}')">افحصه بالتفصيل</button>`]))}
      <div class="note">${r.note}<br>أعلى نسبة استغلال قبل أي حذف = ${nf(r.base_max, 2)} ·
        الانزياح الجانبي قبل الحذف = ${nf(r.drift_before, 1)} مم.</div></div>`;
}
function labRemoveAt(i, j) {
  LAB_MULTI = ['col|' + i + '|' + j + '|1'];
  runLab();
}
async function runLab(fromForm, restore) {
  if (restore) {
    LAB_RES = null; LAB_MULTI = [];
    if (V3 && V3.lab) V3.lab(null);
    return renderLab(null);
  }
  let sels = LAB_MULTI.map(k => k.split('|'));
  if (fromForm || !sels.length) sels = [[txt('lb_tag'), txt('lb_i'), txt('lb_j'), txt('lb_k')]];
  const p = Object.assign({}, WZ.input, { removes: sels });
  const r = await post('lab', p);
  LAB_RES = r; LAB_SEL = sels[sels.length - 1];
  LAB_MULTI = sels.map(a => a.join('|'));
  renderLab(r);
  if (V3 && V3.lab) V3.lab(r.rows, r.removed);
  labSelBox();
}

/* -------------------------------- المعالج -------------------------------- */
PAGES.wizard = {
  ic: '🪄', name: 'معالج المشروع', grp: 'المشروع',
  ttl: 'معالج المشروع — من مساحة القطعة إلى حزمة الأساسات',
  sub: 'اكتب المساحة وعدد الطوابق ونوع التربة — والباقي يُحسب تلقائياً',
  desc: 'كل شي تلقائي من رقم واحد',
  html: () => `<div class="steps"><div><b>١</b> القطعة والطوابق</div><div><b>٢</b> التربة والمناسيب</div>
    <div><b>٣</b> شبكة الأعمدة والأحمال</div><div><b>٤</b> الأساس والركائز</div>
    <div><b>٥</b> الحفر والردم والكميات</div></div>
  <div class="grid g2">
    <div class="card"><h3>١ · القطعة والبناء</h3><div class="f">
      ${F('مساحة القطعة', 'w_area', 200, 10, 'م²')}
      ${F('عدد الطوابق', 'w_floors', 2, 1)}
      ${F('نسبة البناء من القطعة', 'w_cov', 1.0, .05, '0.3 – 1.0')}
      ${F('ارتفاع الطابق', 'w_hs', 3.2, .1, 'م')}
      ${S('الاستعمال', 'w_use', META.live.map(x => x.name), 'سكني / غرف نوم')}
      ${F("f'c", 'w_fc', 31, 1, 'MPa')}${F('fy', 'w_fy', 420, 10, 'MPa')}
      ${S('المحافظة', 'w_city', META.cities.map(c => c.name), 'بغداد')}</div>
      <div class="hint">الافتراضي f'c = <b>31 ميغا</b> لا 25، لأن أصناف التعرّض الافتراضية
        (كبريتات S2 — تربة العراق الجبسية) توجبه بجدول ACI 19.3.2.1. أنزله إلى 25 فقط إن
        كان فحص تربتك يثبت كبريتات أقل، وغيّر صنف S معه من بطاقة «التربة والمناسيب».</div></div>
    <div class="card"><h3>٢ · التربة والمناسيب</h3><div class="f">
      ${S('نوع التربة', 'w_soil', (META.soils || []).map(s => [s.name, s.name + ' — ' + s.qa + ' kPa']), 'طين قاسي')}
      ${F('تحمّل التربة qa (0=حسب النوع)', 'w_qa', 0, 5, 'kPa')}
      ${F('منسوب الأرض الطبيعية', 'w_ground', -0.30, .05, 'م من البنج مارك')}
      ${F('عمق الهدم/الحفر القديم', 'w_old', 0, .1, 'م تحت الأرض')}
      ${F('عمق التأسيس Df', 'w_df', 1.50, .05, 'م')}
      ${F('منسوب الماء الجوفي (0=بلا ماء)', 'w_gwt', 0, .25, 'م من البنج مارك')}
      ${F('سُمك الطبقة الحاملة (0=غير معروف)', 'w_bthk', 0, .5, 'م من تقرير الجسّات')}
      ${F('سُمك التربة الضعيفة (0=يُقدَّر)', 'w_wdep', 0, .5, 'م تحت منسوب التأسيس')}</div>
      <div class="chips" style="margin-top:8px">
        ${C('طبقة ضعيفة تحت الطبقة الحاملة', 'w_weak', false)}
        ${C('طين انتفاخي (Expansive)', 'w_exsw', false)}
        ${C('تربة جبسية انهيارية', 'w_gyp', false)}
        ${C('أملاح/كبريتات عالية', 'w_salt', false)}
        ${C('قوى شدّ أو قلب على الأعمدة', 'w_upl', false)}</div>
      <div class="hint"><b>سُمك التربة الضعيفة هو الذي يقرّر: إحلال أم ركائز.</b>
        إن كان الضعيف سطحياً (٣ أمتار فأقل) يُحفر ويُستبدل بسبيس مدكوك ويُبنى
        عليه أساس سطحي — وهذا الحلّ المنفَّذ لأغلب بيوت العراق، وأرخص من الركائز
        بمراتب. والركائز لا تلزم إلا حين يعمق الضعيف أو يثقل المبنى.
        <br><b>وهذه الخمس تفصل بين «قواعد سطحية» و«ركائز» على التربة نفسها.</b> تربة 180 kPa قد تُبنى عليها قواعد منفصلة وقد توجب ركائز،
        والفارق سُمك الطبقة الحاملة وما تحتها، والانتفاخ، والماء والأملاح — لا رقم
        التحمّل وحده. اتركها فارغة إن لم يكن عندك تقرير جسّات، وسيقول الجدول صراحةً
        إن الشرط لم يُفحص.</div>
      <h3 style="margin-top:14px">أصناف التعرّض — ACI 318-19 جدول 19.3.1.1</h3>
      <div class="f">${expSelects()}
      ${F('نسبة الماء/الأسمنت w/cm (0=غير محدّدة)', 'w_wcm', 0, .01, '')}</div>
      <div class="hint">الكود يفرض حدّاً أدنى لـ f'c وحدّاً أعلى لنسبة الماء/الأسمنت
        <b>بسبب البيئة لا الحمل</b> (جدول 19.3.2.1). تربة العراق الجبسية غالباً
        صنف كبريتات S2 فتوجب f'c ≥ 31 ميغا و w/cm ≤ 0.45 — هذا هو الباب الذي
        يقرّر عمر المبنى، لا مقاومته.</div></div>
    <div class="card"><h3>٣ · نوع السقف</h3><div class="f">
      ${S('نوع السقف', 'w_slab', [['auto', 'تلقائي — حسب التوصية']].concat(
        (META.slab_types || []).map(t => [t.k, t.name + ' (' + t.span + ')'])), 'auto')}
      ${S('درجة التعرّض (للغطاء)', 'w_exp', (META.exposures || []).map(e => [e.k, e.name]), 'interior')}</div>
      <div id="w_hordi" class="f" style="display:none;margin-top:8px">
        ${F('عرض البلوك ⊥ العصب', 'w_bw', (META.hordi || {}).block_W || 400, 10, 'مم')}
        ${F('طول البلوك مع العصب', 'w_bl', (META.hordi || {}).block_L || 200, 10, 'مم')}
        ${F('ارتفاع البلوك', 'w_bh', (META.hordi || {}).block_H || 240, 10, 'مم')}
        ${F('عرض العصب', 'w_rw', (META.hordi || {}).rib_w || 120, 10, 'مم')}
        ${F('طبقة التغطية', 'w_tp', (META.hordi || {}).topping || 70, 5, 'مم')}
        ${F('وزن البلوكة', 'w_bk', (META.hordi || {}).block_kg || 12, .5, 'كغم')}</div>
      <div class="hint">الهوردي هو الأشيع بالعراق — أدخل مقاسات البلوك المتوفرة عندك.</div></div>
    <div class="card"><h3>٣-ب · نوع الجسور</h3><div class="f">
      ${S('النوع العام', 'w_bt', (META.beam_types || []).map(t => [t.k, t.name]), 'drop')}
      ${S('جسور المحور X', 'w_btx', [['', 'كالنوع العام']].concat(
        (META.beam_types || []).map(t => [t.k, t.name])), '')}
      ${S('جسور المحور Y', 'w_bty', [['', 'كالنوع العام']].concat(
        (META.beam_types || []).map(t => [t.k, t.name])), '')}</div>
      <div class="hint"><b>نوع الجسر ليس شكلاً بالمجسم.</b> موضع البلاطة من
        المقطع يقرّر لأي إشارة عزم تعمل شفةً ضاغطة، والعمق يقرّر الحديد،
        والعرض يقرّر عدد أرجل الأساور — والمقلوب يلزمه حديد تعليق لا وجود له
        بغيره. غيّر النوع وسترى المقطع والحديد والأساور تتغيّر بالتقرير
        وبالمجسم معاً.</div></div>
    <div class="card"><h3>٤ · تفاصيل التنفيذ</h3><div class="f">
      ${S('شكل العمود', 'w_shape', [['auto', 'تلقائي — مستطيل أو من المخطط'],
        ['rect', 'مستطيل'], ['sq', 'مربع'], ['circ', 'دائري (O) — حلزون'],
        ['L', 'زاوية (L)'], ['T', 'تي (T)']], 'auto')}
      ${F('قطر العمود الدائري (0=تلقائي)', 'w_colD', 0, 50, 'مم')}
      ${S('قاعدة الأوفرلاب', 'w_lap', (META.lap_modes || []).map(m => [m.k, m.name]), '60db')}
      ${S('قاعدة الدولات (Dowels)', 'w_dow', (META.dowel_modes || []).map(m => [m.k, m.name]), '16db')}
      ${S('نوع الكرسي', 'w_chair', (META.chairs || []).map(c => [c.k, c.name]), 'z90')}
      ${C('ثني الحديد السفلي 45° عند L/7', 'w_bent', true)}</div>
      <h3 style="margin-top:14px">الكانتيليفر — الشناشيل والبلكونات</h3>
      <div class="f">
        ${F('طول البروز (0 = بلا بروز)', 'w_cL', 0, .1, 'م')}
        ${F('حمل الدرابزين على الطرف الحرّ', 'w_cP', 0, .5, 'kN/م')}
        ${F('سماكة البروز (0 = تلقائي)', 'w_cH', 0, 10, 'مم')}</div>
      <div class="chips" style="margin-top:8px">${(META.canti_sides || []).map(o =>
        `<label><input type="checkbox" id="w_cs_${csid(o.k)}"> ${o.name}</label>`).join('')}</div>
      <div class="hint"><b>البروز أكثر عنصر يُنفَّذ خطأً:</b> حديده الرئيسي
        <b>كله علوي</b> لأن عزمه سالب على طوله كله — والحدّاد المعتاد على الجسور
        يضعه بالأسفل فينهار عند فكّ القالب. وأدنى سماكة له <b>ℓ/8</b> لا ℓ/16
        (جدول ACI 9.3.1.1). حدّد الجهات وسيُصمَّم ويُرسم بالمجسم بلونين:
        <b style="color:#facc15">أصفر للعلوي (شدّ)</b> و<b style="color:#60a5fa">أزرق
        للسفلي (انكماش)</b>.</div>
      <div class="row"><button class="btn" onclick="PAGES.wizard.run()">🚀 صمّم المشروع</button>
        <button class="btn gh" onclick="window.print()">🖨️ تقرير PDF</button>
        <button class="btn gh" onclick="PAGES.wizard.dxf()">📐 مخطط الأسس DXF</button>
        <button class="btn gh" onclick="PAGES.wizard.dxf('rebar')">📐 تفاصيل التسليح DXF</button>
        <button class="btn gh" onclick="go('bbs')">📊 جدول تقطيع الحديد</button>
        <button class="btn gh" onclick="PAGES.wizard.save()">💾 حفظ المشروع</button></div>
      <div class="hint">البنج مارك 0.00 = منسوب أرضية الطابق الأرضي بعد التشطيب.</div></div></div>
  <div id="w_out" style="margin-top:16px"></div>`,
  payload: () => ({ area: val('w_area'), floors: val('w_floors'), coverage: val('w_cov'),
    story_h: val('w_hs'), use: txt('w_use'), fc: val('w_fc'), fy: val('w_fy'), city: txt('w_city'),
    soil: txt('w_soil'), qa: val('w_qa') || null, ground: val('w_ground'), old_depth: val('w_old'),
    gwt: val('w_gwt') || null, bear_thk: val('w_bthk') || 0,
    weak_depth: val('w_wdep') || 0,
    weak_below: chk('w_weak'), expansive: chk('w_exsw'), gypseous: chk('w_gyp'),
    salts: chk('w_salt'), uplift: chk('w_upl'),
    Df: val('w_df'), slab_type: txt('w_slab'), exposure: txt('w_exp'), lap_mode: txt('w_lap'),
    beam_type: txt('w_bt') || 'drop', beam_type_x: txt('w_btx') || null,
    beam_type_y: txt('w_bty') || null,
    exposure_classes: expPick(), wcm: val('w_wcm') || null,
    cantilever: { L: val('w_cL'), parapet: val('w_cP'), h: val('w_cH') || null,
      sides: (META.canti_sides || []).map(o => o.k).filter(k => chk('w_cs_' + csid(k))) },
    dowel_mode: txt('w_dow'), chair_kind: txt('w_chair'), bent: chk('w_bent'),
    col_shape: txt('w_shape'), col_D: val('w_colD') || null,
    added_cols: window.__added_cols || null,
    elevator: window.__elevator || null,
    hordi: { block_W: val('w_bw'), block_L: val('w_bl'), block_H: val('w_bh'),
      rib_w: val('w_rw'), topping: val('w_tp'), block_kg: val('w_bk') },
    grid_override: window.__grid_override || null,
    frame_override: window.__frame_override || null,
    stairs: window.__stairs || null, shafts: window.__shafts || null,
    footprint_override: window.__footprint_override || null }),
  dxf: async (kind) => {
    if (!WZ) return alert('شغّل المعالج أولاً');
    const r = await fetch('/api/dxf' + (kind === 'rebar' ? '?kind=rebar' : ''),
      { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(WZ) });
    const b = await r.blob(), a = document.createElement('a');
    a.href = URL.createObjectURL(b);
    a.download = kind === 'rebar' ? 'rebar-details.dxf' : 'foundation.dxf'; a.click();
  },
  save: async () => {
    if (!WZ) return alert('شغّل المعالج أولاً');
    const name = prompt('اسم المشروع:', 'مشروع ' + WZ.input.area + 'م²');
    if (!name) return;
    await post('project/save', { name, input: WZ.input });
    alert('تم الحفظ ✓');
  },
  run: async () => {
    const r = await post('wizard', PAGES.wizard.payload());
    WZ = r;
    const a = r.advisor, d = r.design, ew = r.earth, g = r.grid;
    let des = '';
    if (d.mode === 'isolated') {
      const t = d.typical;
      des = `<div class="grid g4">${kpi('الأساس النموذجي', nf(t.B, 2) + '×' + nf(t.B, 2) + ' م')}
        ${kpi('السماكة', int(t.h) + ' مم')}${kpi('التسليح', t.bars_label)}
        ${kpi('قص الثقب', nf(t.punch_ratio, 2), t.punch_ratio <= 1 ? 'ok' : 'bad')}</div>
        <div style="margin-top:12px">${table(['الأساس', 'الموقع', 'حمل الخدمة (kN)', 'الأبعاد (م)', 'ضغط التربة (kPa)'],
          d.sizes.map((s, i) => ['F' + (i + 1), s.kind, nf(s.P, 0), nf(s.B, 2) + ' × ' + nf(s.B, 2),
            nf(s.P / (s.B * s.B), 1)]))}</div>`;
    } else if (d.mode === 'raft') {
      const t = d.raft;
      des = `<div class="grid g4">${kpi('أبعاد الحصيرة', nf(t.Lx, 1) + ' × ' + nf(t.Ly, 1) + ' م')}
        ${kpi('السماكة', int(t.h) + ' مم')}${kpi('ضغط التربة', nf(t.q_serv, 1) + ' / ' + nf(t.qa, 0) + ' kPa', t.ok_press ? 'ok' : 'bad')}
        ${kpi('قص الثقب', t.punch_ok ? 'مقبول ✓' : 'زد السماكة', t.punch_ok ? 'ok' : 'bad')}
        ${kpi('التسليح العلوي', t.top.label)}${kpi('التسليح السفلي', t.bottom.label)}
        ${kpi('الخرسانة', nf(t.conc, 1) + ' م³')}${kpi('الحديد التقريبي', nf(t.steel, 1) + ' طن')}</div>
        <div class="note">${t.note}</div>`;
    } else {
      const t = d.pile;
      des = `<div class="grid g4">${kpi('قطر الركيزة', int(t.D * 1000) + ' مم')}${kpi('طول الركيزة', nf(t.L, 0) + ' م')}
        ${kpi('قدرة الركيزة المفردة', nf(t.Qall, 0) + ' kN')}${kpi('عدد الركائز/عمود', t.n)}
        ${kpi('العدد الكلي', d.total_piles, 'ok')}${kpi('كفاءة المجموعة', nf(t.eff, 2))}
        ${kpi('هامة الركائز', nf(t.cap.B, 2) + '×' + nf(t.cap.L, 2) + '×' + nf(t.cap.h, 2) + ' م')}
        ${kpi('النوع الموصى به', (t.types.find(x => x.key === t.recommended) || {}).name || '—')}</div>
        <div class="grid g2" style="margin-top:12px">
        <div class="card"><h3>خطوات حساب القدرة الحاملة</h3>${table(['الخطوة', 'القيمة'], t.steps)}
          ${table(['البند', 'القيمة'], [['القدرة القصوى Qu', nf(t.Qu, 0) + ' kN'],
            ['وزن الركيزة', nf(t.W, 0) + ' kN'], ['معامل الأمان', nf(t.FS, 1)],
            ['القدرة المسموحة', nf(t.Qall, 0) + ' kN'], ['التباعد', nf(t.spacing, 2) + ' م (3D)'],
            ['قدرة المجموعة', nf(t.Qgroup, 0) + ' kN مقابل حمل ' + nf(t.P, 0) + ' kN']])}</div>
        <div class="card"><h3>أنواع الركائز ومتى تُستعمل</h3>${t.types.map(x => `<div style="margin-bottom:9px">
          <b style="color:${x.key === t.recommended ? 'var(--ok)' : '#fff'}">${x.name}${x.key === t.recommended ? ' ✓ موصى به' : ''}</b>
          <div style="font-size:11.5px;color:var(--mut)">قطر ${x.D} · ${x.when}<br>+ ${x.pros}<br>− ${x.cons}</div></div>`).join('')}</div></div>
        <div class="note">${t.notes.join(' · ')}</div>`;
    }
    $('#w_out').innerHTML = `
    <div class="grid g4">${kpi('مساحة البناء', nf(r.footprint, 0) + ' م²')}
      ${kpi('شبكة الأعمدة', g.nx + ' × ' + g.ny + ' بحر')}${kpi('عدد الأعمدة', g.cols, 'ok')}
      ${kpi('البحر', nf(g.sx, 2) + ' × ' + nf(g.sy, 2) + ' م')}
      ${kpi('مقطع العمود', r.col.b + '×' + r.col.h + ' مم')}${kpi('سماكة السقف المقترحة', int(r.floor.slab) + ' مم')}
      ${kpi('الحمل الكلي على التربة', int(r.total) + ' kN')}${kpi('أثقل عمود', int(r.Pmax) + ' kN')}</div>

    <div class="card" style="margin-top:16px"><h3>🩻 مساحة العمل ثلاثية الأبعاد — X-Ray · التسليح · التحليل · التجربة</h3>
      ${v3bar({ floors: r.model.floors, analysis: true })}
      <div class="v3d"><div id="v3d" style="min-height:500px"></div>
        <div class="chips" id="v3groups">
          ${v3chips([['layers', 'طبقات الردم', 1], ['raft', 'حصيرة', 1], ['isolated', 'أسس منفردة', 1],
             ['piles', 'ركائز', r.recommended === 'piles' ? 1 : 0], ['columns', 'أعمدة', 1],
             ['beams', 'جسور', 1], ['slabs', 'سقوف', 1], ['extra', 'تسليح إضافي', 1],
             ['chairs', 'كراسي', 1],
             ['canti', 'كانتيليفر (شناشيل)', (r.canti && r.canti.on) ? 1 : 0],
             ['walls', 'نواة المصعد', (r.model && r.model.elevator) ? 1 : 0],
             ['stairs', 'الدرج وتسليحه',
               (r.stairs && (r.stairs.flights || []).length) ? 1 : 0]])}
        </div>
        <div class="row" id="siteBar" hidden style="gap:10px;align-items:stretch;
          margin-top:8px;padding:9px 11px;background:var(--bg2);border-radius:10px"></div>
        <div class="info" id="v3info"></div>
        <div class="slider"><span style="font-size:11px;color:var(--mut)">قص المقطع</span>
          <input type="range" id="v3clip" min="-30" max="40" step="0.2">
          <span id="v3stats" style="font-size:11px;color:var(--acc2)"></span></div>
      </div>
      ${addColPanel()}${addLiftPanel()}
      ${v3legend()}
      <div class="hint">اسحب للتدوير · العجلة للتكبير · <b>ضغطة واحدة = اختيار وعرض التفاصيل (بلا تحريك الكاميرا)
        · ضغطتان أو «تقريب المحدد» = تقريب متحرك.</b> زر «🧍 إنسان 1.85 م» يضع شخصاً بالحجم الطبيعي للمقارنة،
        ويتنقل معك بين الطوابق من قائمة الطوابق.</div>

      <div class="wtabs" id="wtabs">
        ${[['detail', '🧵 التسليح والتفاصيل'], ['calc', '🧮 تفاصيل الحسابات'],
           ['aci', '📕 مطابقة ACI 318-19'],
           ['xr', '🩻 الأشعة الإنشائية'], ['movie', '🎬 فيديو البناء'],
           ['slabs', '🧱 نوع السقف'], ['lab', '🧪 الإنشائيات والتجربة'],
           ['plan', '📐 الأوتوكاد'], ['boq', '📋 الكميات والحديد']].map(([k, t], i) =>
          `<button data-t="${k}" class="${i ? '' : 'on'}" onclick="wtab('${k}')">${t}</button>`).join('')}
      </div>
      <div class="wpanel" data-t="detail">${detailPanel(r)}</div>
      <div class="wpanel" data-t="calc" hidden>
        <div class="selbox">كل رقمٍ صمّمه المعالج، مشتقّاً خطوةً خطوة: المعادلة
          الرمزية، ثم التعويض بالأرقام، ثم <b>رقم البند الكودي ونصّ ما يفرضه</b> —
          حدٌّ أعلى مقطوع أم يحدّده التصميم. كلّها <b>ACI 318-19</b>.</div>
        <div class="v3bar" id="cdbar">${CALCTABS.map(([k, t], i) =>
          `<button data-c="${k}" class="${i ? '' : 'hot'}"
            onclick="TABS.cpick('${k}')">${t}</button>`).join('')}</div>
        <div id="cdbody"><div class="note">جارٍ اشتقاق الحساب…</div></div>
      </div>
      <div class="wpanel" data-t="aci" hidden><div id="wp_aci" class="note">جارٍ الفحص…</div></div>
      <div class="wpanel" data-t="xr" hidden><div id="wp_xr" class="note">جارٍ التحليل…</div></div>
      <div class="wpanel" data-t="movie" hidden><div id="wp_movie" class="note">جارٍ التحضير…</div></div>
      <div class="wpanel" data-t="slabs" hidden><div id="wp_slabs" class="note">جارٍ التحميل…</div></div>
      <div class="wpanel" data-t="lab" hidden><div id="wp_lab"></div></div>
      <div class="wpanel" data-t="plan" hidden><div id="wp_plan"></div></div>
      <div class="wpanel" data-t="boq" hidden><div id="wp_boq" class="note">جارٍ التحميل…</div></div>
    </div>

    <div class="rec" style="margin-top:16px"><h3>🏗️ التوصية: ${a.name}</h3>
      <ul>${a.reasons.map(x => `<li>${x}</li>`).join('')}</ul>
      ${a.alts.length ? `<ul class="alt"><b style="color:var(--mut);font-size:12px">بدائل وملاحظات:</b>
        ${a.alts.map(x => `<li>${x}</li>`).join('')}</ul>` : ''}
      <div style="margin-top:8px;font-size:12px;color:var(--mut)">تحمّل التربة الصافي ${nf(a.q_net, 0)} kPa ·
        مجموع مساحات الأسس ${nf(a.sum_area, 1)} م² (${nf(a.ratio * 100, 0)}% من مساحة البناء)</div></div>
    ${bandPanel(a)}

    <div class="card" style="margin-top:16px"><h3>مقارنة بدائل الأساس</h3>
      ${table(['البديل', 'الوصف', 'الخرسانة (م³)', 'الحديد (طن)', 'الحالة', ''],
        Object.entries(r.alts).map(([k, v]) => [
          v.name + (k === r.recommended ? ' <span class="tag t-ok">موصى به ✓</span>' : ''),
          k === 'isolated' ? (v.sizes.length + ' أساس · أكبرها ' + nf(Math.max(...v.sizes.map(s => s.B)), 2) + ' م')
            : k === 'raft' ? (nf(v.raft.Lx, 1) + '×' + nf(v.raft.Ly, 1) + ' م · سماكة ' + int(v.raft.h) + ' مم')
            : (v.total_piles + ' ركيزة Ø' + int(v.pile.D * 1000) + ' طول ' + int(v.pile.L) + ' م'),
          nf(v.conc, 1), nf(v.steel, 2),
          v.ok ? '<span class="tag t-ok">صالح</span>' : '<span class="tag t-warn">غير مناسب هنا</span>',
          k === 'isolated' ? nf(v.area / r.footprint * 100, 0) + '% من المساحة' : ''
        ]))}</div>
    <div class="card" style="margin-top:16px"><h3>تصميم الأساس الموصى به</h3>${des}</div>
    <div class="grid g2" style="margin-top:16px">
      <div class="card"><h3>السقف — ${r.slab.kind_name}</h3>
        ${table(['البند', 'القيمة'], [['السماكة', int(r.slab.h) + ' مم (الدنيا ' + nf(r.slab.hmin, 0) + ')'],
          ['سبب الاختيار', r.slab.why], ['wu', nf(r.slab.wu, 2) + ' kN/m²'],
          ['الوزن الذاتي', nf(r.floor.slab_sw, 2) + ' kN/m²'],
          ['فرش (الاتجاه القصير)', r.model.slab.mesh.short.label + ' — d = ' + int(r.model.slab.mesh.short.d) + ' مم'],
          ['غطاء (الاتجاه الطويل)', r.model.slab.mesh.long.label + ' — d = ' + int(r.model.slab.mesh.long.d) + ' مم'],
          ['علوي فوق المساند', r.model.slab.mesh.top.label],
          ['الغطاء الخرساني', int(r.model.slab.cover) + ' مم'],
          ['خرسانة السقف الواحد', nf(r.footprint * r.slab.h / 1000, 1) + ' م³']].concat(
          (r.slab.rows || []).map(x => [x[0], x[1]])))}</div>
      <div class="card"><h3>الأعمدة</h3>
        ${table(['البند', 'القيمة'], [
          ['الشكل', ({ rect: 'مستطيل', circ: 'دائري (O)', L: 'زاوية (L)', T: 'تي (T)' })[r.col.rebar.shape] || 'مستطيل'],
          ['المقطع', r.col.rebar.spiral ? ('Ø' + int(r.col.rebar.D) + ' مم')
            : (r.col.b + ' × ' + r.col.h + ' مم')],
          ['التسليح الطولي', r.col.rebar.label + ' (ρ = ' + nf(r.col.rebar.rho * 100, 2) + '%)'],
          [r.col.rebar.spiral ? 'الحلزون' : 'الأتاري بالوسط', r.col.rebar.tie_label],
          ['التطويق عند الأطراف', r.col.rebar.conf_label],
          ['Pu المصمم', nf(r.Pumax, 0) + ' kN'], ['Mu التقديري', nf(r.col.Mu, 1) + ' kN·m'],
          ['φMn عند Pu', nf(r.col.rebar.phiMn, 1) + ' kN·m'],
          ['نسبة الاستغلال', nf(r.col.rebar.ratio, 2) + (r.col.rebar.ok ? ' ✓' : ' ✗')]].concat(
          r.col.rebar.mix ? [['أشكال أعمدة المخطط', Object.entries(r.col.rebar.mix)
            .sort((a, b2) => b2[1] - a[1])
            .map(([k, v]) => v + ' ' + (({ rect: 'مستطيل', circ: 'دائري', L: 'زاوية L', T: 'تي T' })[k] || k))
            .join(' · ')]] : []).concat(
          r.col.rebar.from_plan ? [['المقطع مقابل المخطط', r.col.rebar.from_plan]] : []))}</div>
      ${['x', 'y'].map(d => { const bm = r.beams[d], sc2 = bm.section; return `
      <div class="card"><h3>جسور الاتجاه ${d.toUpperCase()} — ${nf(sc2.span, 2)} م × ${sc2.nspan} فضاء</h3>
        ${table(['البند', 'القيمة'], [['المقطع', int(sc2.b) + ' × ' + int(sc2.h) + ' مم'],
          ['العرض المؤثر', nf(sc2.trib, 2) + ' م'],
          ['أقصى عزم موجب', nf(Math.max(...bm.design.map(x => x.Mpos)), 1) + ' kN·m'],
          ['أقصى عزم سالب', nf(Math.min(...bm.supports.map(x => x.M)), 1) + ' kN·m'],
          ['التسليح السفلي', bm.rebar.bottom.label], ['التسليح العلوي', bm.rebar.top.label],
          ['الأساور', bm.rebar.stirrup.label],
          ['الهطول', nf(Math.abs(Math.min(...bm.design.map(x => x.d_long))), 1) + ' مم / الحد ' +
            nf(bm.design[0].d_limit, 1) + ' مم']])}</div>`; }).join('')}
    </div>
    <div class="card" style="margin-top:16px"><h3>مقطع الطبقات والمناسيب</h3>${sectionSVG2(ew)}</div>

    <div class="grid g2" style="margin-top:16px">
      <div class="card"><h3>المناسيب وخطوات العمل</h3>${table(['البند', 'القيمة'], ew.steps)}
        <div class="note">${ew.notes[0]}</div></div>
      <div class="card"><h3>كميات الحفر والردم</h3>${table(['البند', 'الكمية'], [
        ['عمق الحفر', nf(ew.cut_depth, 2) + ' م'], ['حجم الحفر', nf(ew.cut_vol, 1) + ' م³'],
        ['الحفر بعد الانتفاش (نقل)', nf(ew.cut_loose, 1) + ' م³'],
        ['ردم هندسي تحت الأساس', nf(ew.fill_to_found, 2) + ' م'],
        ['جلمود/ردم مختار (مدكوك)', nf(ew.boulder, 1) + ' م³ — يُشترى ' + nf(ew.boulder_buy, 1) + ' م³'],
        ['عدد طبقات الجلمود', ew.boulder_layers + ' طبقة × 30 سم'],
        ['سبيس (مدكوك)', nf(ew.subbase, 1) + ' م³ — يُشترى ' + nf(ew.subbase_buy, 1) + ' م³'],
        ['عدد طبقات السبيس', ew.subbase_layers + ' طبقة × 25 سم'],
        ['خرسانة نظافة', nf(ew.blinding, 1) + ' م³'],
        ['سبيس ساحات القطعة', nf(ew.yard_subbase, 1) + ' م³']])}</div>
      <div class="card"><h3>الكلفة التقديرية</h3>${table(['البند', 'الكمية', 'الوحدة', 'السعر', 'الكلفة (د.ع)'],
        r.boq.rows.map(x => [x.name, nf(x.q, 1), x.unit, int(x.rate), int(x.cost)]))}
        <div class="grid g2" style="margin-top:10px">${kpi('الإجمالي', int(r.boq.total) + ' د.ع', 'ok')}
          ${kpi('قص القاعدة الزلزالي', nf(r.seismic.V, 0) + ' kN')}</div></div>
      <div class="card"><h3>أحمال الأعمدة</h3><div style="max-height:340px;overflow:auto">
        ${table(['#', 'الموقع', 'المساحة المؤثرة (م²)', 'حمل الخدمة (kN)', 'Pu (kN)'],
          r.loads.map((l, i) => [i + 1, l.kind, nf(l.area, 2), nf(l.P, 0), nf(l.Pu, 0)]))}</div></div>
      <div class="card"><h3>تركيب الطابق</h3>${table(['المكوّن', 'kN/m²'],
        r.floor.items.map(i => [i.name, nf(i.v)]).concat([['بدل وزن الجسور', nf(r.floor.beams)],
          ['<b>الحمل الميت D</b>', '<b>' + nf(r.floor.D) + '</b>'], ['الحمل الحي L', nf(r.floor.L)]]))}
        <div class="note">${r.summary.join(' · ')}</div></div></div>`;
    Object.keys(WT).forEach(k => WT[k] = 0);   // التبويبات تُعاد بناؤها مع النتيجة
    setTimeout(() => mount3D(WZ, 'v3d'), 60);
  },
  init: () => {
    const sel = $('#w_slab'), box = $('#w_hordi');
    const sync = () => { box.style.display = ['auto', 'hordi'].includes(sel.value) ? '' : 'none'; };
    sel.onchange = sync; sync();
    PAGES.wizard.run();
  }
};

/* -------------------------------- المساحة -------------------------------- */
function ptRow(n, e, nn) {
  return `<div class="sp" style="grid-template-columns:1fr 1fr 1fr auto">
    <input value="${n}" data-k="name" placeholder="اسم النقطة">
    <input type="number" step="0.001" value="${e}" data-k="E" placeholder="E شرقي">
    <input type="number" step="0.001" value="${nn}" data-k="N" placeholder="N شمالي">
    <button class="btn gh" onclick="this.parentNode.remove()">✕</button></div>`;
}
function polySVG(r) {
  const W = 620, H = 360, m = 46;
  const E = r.points.map(p => p.E), N = r.points.map(p => p.N);
  const x0 = Math.min(...E), x1 = Math.max(...E), y0 = Math.min(...N), y1 = Math.max(...N);
  const s = Math.min((W - 2 * m) / ((x1 - x0) || 1), (H - 2 * m) / ((y1 - y0) || 1));
  const X = v => m + (v - x0) * s, Y = v => H - m - (v - y0) * s;
  const pts = r.points.map(p => `${X(p.E)},${Y(p.N)}`).join(' ');
  let g = `<polygon points="${pts}" fill="#38bdf822" stroke="#38bdf8" stroke-width="2"/>`;
  r.points.forEach(p => { g += `<circle cx="${X(p.E)}" cy="${Y(p.N)}" r="4" fill="#fbbf24"/>
    <text x="${X(p.E) + 7}" y="${Y(p.N) - 6}" fill="#e6edf7" font-size="11">${p.name}</text>`; });
  r.sides.forEach(s2 => {
    const a = r.points.find(p => p.name === s2.frm), b = r.points.find(p => p.name === s2.to);
    g += `<text x="${(X(a.E) + X(b.E)) / 2}" y="${(Y(a.N) + Y(b.N)) / 2 - 5}" fill="#93a4c0"
      font-size="10.5" text-anchor="middle">${nf(s2.L, 2)} م</text>`;
  });
  g += `<circle cx="${X(r.centroid.E)}" cy="${Y(r.centroid.N)}" r="3" fill="#34d399"/>`;
  return `<svg viewBox="0 0 ${W} ${H}">${g}</svg>`;
}
PAGES.survey = {
  ic: '📐', name: 'المساحة', grp: 'ما تحت الصفر', ttl: 'أعمال المساحة',
  sub: 'مساحة ومحيط من الإحداثيات · دفتر المناسيب · حساب القطع والردم',
  desc: 'إحداثيات ومناسيب وقطع وردم',
  html: () => `<div class="grid g2">
    <div class="card"><h3>حدود القطعة بالإحداثيات</h3>
      <div class="hint" style="margin-bottom:6px">أدخل النقاط بالتسلسل حول المضلع (اسم · E · N)</div>
      <div id="sv_pts">${ptRow('A', 0, 0) + ptRow('B', 20, 0) + ptRow('C', 20, 10) + ptRow('D', 0, 10)}</div>
      <div class="row"><button class="btn gh" onclick="$('#sv_pts').insertAdjacentHTML('beforeend', ptRow('P',0,0))">+ نقطة</button>
        <button class="btn" onclick="PAGES.survey.run()">احسب المساحة</button>
        <button class="btn gh" onclick="PAGES.survey.toWizard()">↗ استعمل المساحة بالمعالج</button></div>
      <div id="sv_out" style="margin-top:12px"></div></div>
    <div class="card"><h3>دفتر المناسيب (ارتفاع الجهاز HI)</h3><div class="f">
      ${F('منسوب البنج مارك BM', 'lv_bm', 10.000, .001, 'م')}</div>
      <div class="hint" style="margin:8px 0 6px">النقطة · خلفية BS · وسطية IS · أمامية FS (اترك الفارغ صفراً)</div>
      <div id="lv_rows">${['BM,1.500,,', 'A,,1.200,', 'B,2.100,,0.800', 'C,,,1.900'].map(r => {
        const [n, bs, is_, fs] = r.split(',');
        return `<div class="sp" style="grid-template-columns:1fr 1fr 1fr 1fr auto">
          <input value="${n}" data-k="point"><input type="number" step="0.001" value="${bs}" data-k="bs" placeholder="BS">
          <input type="number" step="0.001" value="${is_}" data-k="is" placeholder="IS">
          <input type="number" step="0.001" value="${fs}" data-k="fs" placeholder="FS">
          <button class="btn gh" onclick="this.parentNode.remove()">✕</button></div>`; }).join('')}</div>
      <div class="row"><button class="btn gh" onclick="$('#lv_rows').insertAdjacentHTML('beforeend',
        $('#lv_rows').lastElementChild.outerHTML.replace(/value=\\"[^\\"]*\\"/g,'value=\\"\\"'))">+ رصدة</button>
        <button class="btn" onclick="PAGES.survey.levels()">احسب المناسيب</button></div>
      <div id="lv_out" style="margin-top:12px"></div></div>
    <div class="card"><h3>القطع والردم — طريقة الشبكة</h3><div class="f">
      ${F('ضلع الخلية', 'cf_cell', 5, .5, 'م')}${F('المنسوب التصميمي', 'cf_des', 0.5, .05, 'م')}</div>
      <label style="margin-top:8px">مناسيب الأرض (كل سطر = صف، الأرقام مفصولة بفراغ)</label>
      <textarea id="cf_grid" rows="5" style="width:100%;background:var(--bg2);border:1px solid var(--line);
        color:var(--tx);border-radius:8px;padding:8px;font:inherit">0.00 0.20 0.40 0.35
0.10 0.30 0.50 0.45
0.20 0.40 0.60 0.55</textarea>
      <div class="row"><button class="btn" onclick="PAGES.survey.cf()">احسب القطع والردم</button></div>
      <div id="cf_out" style="margin-top:12px"></div></div></div>`,
  pts: () => $$('#sv_pts .sp').map(r => { const o = {}; $$('input', r).forEach(i => o[i.dataset.k] =
    i.dataset.k === 'name' ? i.value : parseFloat(i.value) || 0); return o; }),
  run: async () => {
    const r = await post('survey', { points: PAGES.survey.pts() });
    window.__area = r.area;
    $('#sv_out').innerHTML = `<div class="grid g3">${kpi('المساحة', nf(r.area, 2) + ' م²', 'ok')}
      ${kpi('بالدونم', nf(r.area_donum, 3) + ' دونم')}${kpi('المحيط', nf(r.perimeter, 2) + ' م')}</div>
      <div style="margin-top:10px">${polySVG(r)}</div>
      <div style="margin-top:10px">${table(['الضلع', 'الطول (م)', 'الاتجاه', 'ΔE', 'ΔN'],
        r.sides.map(s => [s.frm + ' → ' + s.to, nf(s.L, 3), s.quad, nf(s.dE, 3), nf(s.dN, 3)]))}</div>
      <div style="margin-top:10px">${table(['الزاوية عند', 'القيمة'], r.angles.map(a => [a.at, a.dms]))}</div>
      <div class="note">مجموع الزوايا الداخلية ${nf(r.sum_internal, 4)}° والنظري ${nf(r.theoretical, 0)}°
        — الفرق ${nf(r.ang_error, 4)}° · ${r.note}</div>`;
  },
  toWizard: () => { if (!window.__area) return alert('احسب المساحة أولاً');
    go('wizard'); setTimeout(() => { $('#w_area').value = Math.round(window.__area); PAGES.wizard.run(); }, 200); },
  levels: async () => {
    const obs = $$('#lv_rows .sp').map(r => { const o = {}; $$('input', r).forEach(i =>
      o[i.dataset.k] = i.dataset.k === 'point' ? i.value : (i.value === '' ? null : parseFloat(i.value))); return o; });
    const r = await post('levels', { bm: val('lv_bm'), obs });
    $('#lv_out').innerHTML = table(['النقطة', 'BS', 'IS', 'FS', 'HI', 'المنسوب RL'],
      r.rows.map(x => [x.point, x.bs ?? '—', x.is_ ?? '—', x.fs ?? '—',
        x.hi ? nf(x.hi, 3) : '—', nf(x.rl, 3)])) +
      `<div class="note">ΣBS − ΣFS = ${nf(r.check_a, 3)} · آخر − أول = ${nf(r.check_b, 3)} ·
        ${r.ok ? '<b style="color:var(--ok)">التدقيق صحيح ✓</b>' : '<b style="color:var(--bad)">خطأ حسابي ✗</b>'}</div>`;
  },
  cf: async () => {
    const grid = $('#cf_grid').value.trim().split('\n').map(l => l.trim().split(/\s+/).map(Number));
    const r = await post('cutfill', { grid, cell: val('cf_cell'), design: val('cf_des') });
    $('#cf_out').innerHTML = `<div class="grid g3">${kpi('قطع (حفر)', nf(r.cut, 1) + ' م³')}
      ${kpi('ردم', nf(r.fill, 1) + ' م³')}${kpi('الصافي', nf(Math.abs(r.net), 1) + ' م³', r.net > 0 ? 'warn' : 'ok')}</div>
      <div class="note">${r.balance} · المساحة ${nf(r.area, 0)} م² · ${r.note}</div>`;
  },
  init: () => { PAGES.survey.run(); PAGES.survey.levels(); PAGES.survey.cf(); }
};

/* ---------------------------- الحفريات والردم ---------------------------- */
PAGES.earth = {
  ic: '⛏️', name: 'الحفر والردم', grp: 'ما تحت الصفر', ttl: 'الحفريات والردم والمناسيب',
  sub: 'الجلمود والسبيس وعدد الطبقات والكميات — قياساً على البنج مارك 0.00',
  desc: 'مناسيب وطبقات وكميات',
  html: () => `<div class="grid g2"><div class="card"><h3>المناسيب</h3><div class="f">
      ${F('مساحة القطعة', 'e_plot', 250, 10, 'م²')}${F('مساحة البناء', 'e_fp', 200, 10, 'م²')}
      ${F('منسوب الأرض الطبيعية', 'e_ground', -0.30, .05, 'م')}
      ${F('عمق الهدم/الحفر القديم', 'e_old', 1.6, .1, 'م تحت الأرض')}
      ${F('عمق التأسيس Df', 'e_df', 1.50, .05, 'م')}${F('سماكة الأساس', 'e_fh', 0.50, .05, 'م')}
      ${F('مجموع مساحات الأسس', 'e_fa', 70, 5, 'م²')}
      ${F('سماكة السبيس تحت الأرضية', 'e_sub', 0.25, .05, 'م')}</div>
      <div class="row"><button class="btn" onclick="PAGES.earth.run()">احسب</button>
        <button class="btn gh" onclick="window.print()">🖨️ طباعة</button></div></div>
    <div class="card"><h3>مقطع الطبقات</h3><div id="e_sec"></div></div></div>
    <div id="e_out" style="margin-top:16px"></div>`,
  run: async () => {
    const r = await post('earthwork', { plot: val('e_plot'), footprint: val('e_fp'), ground: val('e_ground'),
      old_depth: val('e_old'), Df: val('e_df'), foot_h: val('e_fh'), foot_area: val('e_fa'),
      subbase: val('e_sub'), dig_mode: 'trench' });
    $('#e_sec').innerHTML = sectionSVG2(r);
    $('#e_out').innerHTML = `<div class="grid g4">
      ${kpi('عمق الحفر', nf(r.cut_depth, 2) + ' م')}${kpi('حجم الحفر', nf(r.cut_vol, 1) + ' م³')}
      ${kpi('ردم تحت الأساس', nf(r.fill_to_found, 2) + ' م', r.fill_to_found > 0 ? 'warn' : 'ok')}
      ${kpi('الأساس يأخذ', nf(val('e_fh') + 0.1, 2) + ' م')}
      ${kpi('جلمود (شراء)', nf(r.boulder_buy, 1) + ' م³')}${kpi('طبقات الجلمود', r.boulder_layers + ' × 30 سم')}
      ${kpi('سبيس (شراء)', nf(r.subbase_buy, 1) + ' م³')}${kpi('طبقات السبيس', r.subbase_layers + ' × 25 سم')}</div>
      <div class="grid g2" style="margin-top:16px">
      <div class="card"><h3>خطوات العمل والمناسيب</h3>${table(['البند', 'القيمة'], r.steps)}</div>
      <div class="card"><h3>جدول الطبقات</h3>${table(['الطبقة', 'من', 'إلى', 'السماكة', 'الطبقات', 'الحجم (م³)'],
        r.stack.slice().sort((a, b) => a.bottom - b.bottom).map(s => [s.name, nf(s.bottom, 2), nf(s.top, 2),
          nf(s.t, 2), s.layers || '—', nf(s.volume, 1)]))}</div>
      <div class="card"><h3>ملاحظات التنفيذ</h3><ul style="padding-right:18px;font-size:12.5px;color:var(--mut)">
        ${r.notes.map(n => `<li style="margin:6px 0">${n}</li>`).join('')}</ul></div></div>`;
  },
  init: () => PAGES.earth.run()
};

/* --------------------------- التربة والركائز ----------------------------- */
PAGES.soil = {
  ic: '🪨', name: 'التربة والركائز', grp: 'ما تحت الصفر', ttl: 'تحمّل التربة والركائز',
  sub: 'قدرة التحمّل بمعادلة Terzaghi/Vesic · قدرة الركيزة بطريقة α و Meyerhof',
  desc: 'تحمّل التربة وحساب الخوازيق',
  html: () => `<div class="grid g2">
    <div class="card"><h3>قدرة تحمّل التربة</h3><div class="f">
      ${F('التماسك c (cu)', 'bc_c', 100, 5, 'kPa')}${F('زاوية الاحتكاك φ', 'bc_phi', 0, 1, 'درجة')}
      ${F('كثافة التربة γ', 'bc_g', 18, .5, 'kN/m³')}${F('عرض الأساس B', 'bc_b', 2.0, .1, 'م')}
      ${F('طول الأساس L', 'bc_l', 2.0, .1, 'م')}${F('عمق التأسيس Df', 'bc_df', 1.5, .1, 'م')}
      ${F('معامل الأمان', 'bc_fs', 3, .5)}</div>
      <div class="row"><button class="btn" onclick="PAGES.soil.bc()">احسب</button></div>
      <div id="bc_out" style="margin-top:12px"></div></div>
    <div class="card"><h3>تصميم الركائز (الخوازيق)</h3><div class="f">
      ${S('نوع التربة', 'pl_soil', [['clay', 'طينية (طريقة α)'], ['sand', 'رملية (Meyerhof-SPT)']], 'clay')}
      ${F('cu للطين', 'pl_cu', 60, 5, 'kPa')}${F('N للرمل (SPT)', 'pl_n', 20, 1)}
      ${F('قطر الركيزة D', 'pl_d', 0.6, .1, 'م')}${F('طول الركيزة L', 'pl_l', 15, 1, 'م')}
      ${F('حمل العمود', 'pl_p', 1200, 50, 'kN')}${F('معامل الأمان', 'pl_fs', 2.5, .1)}
      ${S('نوع التنفيذ', 'pl_kind', [['bored', 'مصبوبة بالموقع'], ['driven', 'مدقوقة']], 'bored')}</div>
      <div class="row"><button class="btn" onclick="PAGES.soil.pile()">احسب الركائز</button></div></div></div>
    <div id="pl_out" style="margin-top:16px"></div>
    <div class="card" style="margin-top:16px"><h3>جدول تحمّل التربة الاسترشادي</h3>
      ${table(['نوع التربة', 'qa (kPa)', 'التصنيف'], (META.soils || []).map(s => [s.name, nf(s.qa, 0),
        ({ clay: 'طينية', sand: 'رملية', rock: 'صخرية', fill: 'ردم' })[s.kind] || s.kind]))}
      <div class="note">قيم استرشادية للاستئناس فقط — الاعتماد على التقرير الجيوتقني وفحص التربة للموقع.</div></div>`,
  bc: async () => {
    const r = await post('bearing', { c: val('bc_c'), phi: val('bc_phi'), gamma: val('bc_g'),
      B: val('bc_b'), L: val('bc_l'), Df: val('bc_df'), FS: val('bc_fs') });
    $('#bc_out').innerHTML = `<div class="grid g3">${kpi('qu النهائية', nf(r.qu, 0) + ' kPa')}
      ${kpi('qa الصافية', nf(r.qa_net, 0) + ' kPa', 'ok')}${kpi('qa الإجمالية', nf(r.qa_gross, 0) + ' kPa')}</div>
      <div style="margin-top:10px">${table(['المعامل', 'القيمة'], [['Nc', nf(r.Nc, 2)], ['Nq', nf(r.Nq, 2)],
        ['Nγ', nf(r.Ng, 2)], ['sc · sq · sγ', nf(r.sc, 2) + ' · ' + nf(r.sq, 2) + ' · ' + nf(r.sg, 2)],
        ['ضغط التربة فوق منسوب التأسيس', nf(r.q_overburden, 1) + ' kPa']])}</div>
      <div class="note">${r.note}</div>`;
  },
  pile: async () => {
    const r = await post('pile', { soil: txt('pl_soil'), cu: val('pl_cu'), N: val('pl_n'), D: val('pl_d'),
      L: val('pl_l'), P: val('pl_p'), FS: val('pl_fs'), kind: txt('pl_kind') });
    $('#pl_out').innerHTML = `<div class="grid g4">
      ${kpi('Qs مقاومة الجانب', nf(r.Qs, 0) + ' kN')}${kpi('Qb مقاومة القاعدة', nf(r.Qb, 0) + ' kN')}
      ${kpi('Qu القصوى', nf(r.Qu, 0) + ' kN')}${kpi('Qall المسموحة', nf(r.Qall, 0) + ' kN', 'ok')}
      ${kpi('عدد الركائز', r.n, 'ok')}${kpi('كفاءة المجموعة', nf(r.eff, 2))}
      ${kpi('قدرة المجموعة', nf(r.Qgroup, 0) + ' kN', r.ok ? 'ok' : 'bad')}
      ${kpi('التباعد', nf(r.spacing, 2) + ' م')}</div>
      <div class="grid g2" style="margin-top:16px">
      <div class="card"><h3>خطوات الحساب</h3>${table(['الخطوة', 'القيمة'], r.steps)}
        ${table(['البند', 'القيمة'], [['هامة الركائز', nf(r.cap.B, 2) + ' × ' + nf(r.cap.L, 2) + ' × ' + nf(r.cap.h, 2) + ' م'],
          ['خرسانة الهامة', nf(r.cap.conc, 1) + ' م³'],
          ['خرسانة الركائز', nf(r.n * Math.PI * r.D * r.D / 4 * r.L, 1) + ' م³']])}</div>
      <div class="card"><h3>أنواع الركائز</h3>${r.types.map(x => `<div style="margin-bottom:10px">
        <b>${x.name}</b><div style="font-size:11.5px;color:var(--mut)">قطر ${x.D} · ${x.when}<br>
        <span style="color:var(--ok)">+</span> ${x.pros}<br><span style="color:var(--bad)">−</span> ${x.cons}</div></div>`).join('')}</div></div>
      <div class="note">${r.notes.join('<br>')}</div>`;
  },
  init: () => { PAGES.soil.bc(); PAGES.soil.pile(); }
};

/* ------------------------------- المشاريع -------------------------------- */
PAGES.projects = {
  ic: '💾', name: 'المشاريع', grp: 'المشروع', ttl: 'المشاريع المحفوظة',
  sub: 'استرجاع مشروع محفوظ وإعادة تشغيل المعالج عليه',
  desc: 'حفظ واسترجاع',
  html: () => `<div class="card"><h3>القائمة</h3><div id="pr_out">…</div></div>`,
  run: async () => {
    const r = await post('project/list', {});
    $('#pr_out').innerHTML = r.projects.length ? table(['المشروع', 'التاريخ', 'المساحة', 'الطوابق', 'التربة', ''],
      r.projects.map(p => [p.name, p.saved, nf(p.input.area, 0) + ' م²', p.input.floors, p.input.soil,
        `<button class="btn" onclick="PAGES.projects.open('${p.file}')">فتح</button>
         <button class="btn gh" onclick="PAGES.projects.del('${p.file}')">حذف</button>`]))
      : '<div class="hint">لا توجد مشاريع محفوظة — احفظ من صفحة المعالج.</div>';
  },
  open: async (file) => {
    const d = await post('project/load', { file });
    go('wizard');
    setTimeout(() => {
      const i = d.input;
      const set = (id, v) => { const e = $('#' + id); if (e && v !== undefined && v !== null) e.value = v; };
      set('w_area', i.area); set('w_floors', i.floors); set('w_cov', i.coverage); set('w_hs', i.story_h);
      set('w_use', i.use); set('w_fc', i.fc); set('w_fy', i.fy); set('w_city', i.city);
      set('w_soil', i.soil); set('w_qa', i.qa); set('w_ground', i.ground); set('w_old', i.old_depth);
      set('w_df', i.Df); set('w_gwt', i.gwt); set('w_bthk', i.bear_thk);
      set('w_wdep', i.weak_depth_in);
      const ck = (id, v) => { const e = $('#' + id); if (e) e.checked = !!v; };
      ck('w_weak', i.weak_below); ck('w_exsw', i.expansive); ck('w_gyp', i.gypseous);
      ck('w_salt', i.salts); ck('w_upl', i.uplift);
      PAGES.wizard.run();
    }, 200);
  },
  del: async (file) => { if (!confirm('حذف المشروع؟')) return; await post('project/delete', { file }); PAGES.projects.run(); },
  init: () => PAGES.projects.run()
};

/* --------- التحليل الإنشائي المتطور (وحدة مستقلّة في fem3d.js) ---------- */
PAGES.fem = {
  ic: '🧮', name: 'التحليل المتطور', ttl: 'التحليل الإنشائي المتطور',
  sub: 'إطار فراغي بطريقة الصلابة المباشرة وفق ACI 318-19 — مصفوفة 12×12 · مخططات M₃₃ و M₂₂ و T و V بالفضاء · إثبات كامل للحساب',
  desc: 'تحليل مصفوفي فراغي بمخططات ثلاثية الأبعاد وإثبات رياضي',
  html: () => (window.FEM3D ? FEM3D.page.html()
    : `<div class="card">وحدة التحليل المتطور غير محمَّلة — تأكّد من تحميل <code>/fem3d.js</code>.</div>`),
  init: () => { if (window.FEM3D) FEM3D.page.init(); }
};

/* --- تحليل المشروع: نفس محرّك fem3d لكن بنيتُه من معالج المشروع (قراءةً فقط) --- */
PAGES.femproj = {
  ic: '🏗️', name: 'تحليل المشروع', ttl: 'التحليل الإنشائي لمشروعك',
  sub: 'الإطار الفراغي لمشروعك كما بناه المعالج — ببحوره ومقاطعه وأحماله الحقيقية · عزوم كاملة وتراكيب ACI 318-19 وأساسات',
  desc: 'يحلّل مشروع المعالج بالمصفوفة الكاملة بدل المعاملات التقريبية',
  html: () => (window.FEM3D && FEM3D.projPage ? FEM3D.projPage.html()
    : `<div class="card">وحدة التحليل غير محمَّلة.</div>`),
  init: () => { if (window.FEM3D && FEM3D.projPage) FEM3D.projPage.init(); }
};

PAGES.cad = {
  ic: '🧩', name: 'الأوتوكاد', ttl: 'قسم الأوتوكاد — من مجموعة المخططات إلى مبنى كامل',
  sub: 'يقرأ لوحات DWG الإنشائية كلها: المحاور والعناوين والجداول والأعمدة والجسور والفتحات، ثم يركّب المبنى طابقاً طابقاً بحديده',
  desc: 'ارفع ملف المخططات فيُركَّب المبنى ثلاثي الأبعاد بمقاسات وحديد كل عنصر',
  html: () => (window.CADPAGE ? CADPAGE.html() : `<div class="card">وحدة الأوتوكاد غير محمَّلة.</div>`),
  init: () => { if (window.CADPAGE) CADPAGE.init(); }
};

/* ------------------------- الترتيب والمجموعات ---------------------------- */
/* فحص سريع مستقلّ: نسبة استغلال الأرض ونوع الأساس. منطقه كلّه في
   `fndpick.js` ليعمل فورياً بلا طلب خادم — وهنا تسجيلٌ فقط. */
PAGES.fndpick = {
  ic: '📐', name: 'نوع الأساس السريع', ttl: 'نسبة استغلال الأرض ونوع الأساس',
  sub: 'ثلاثة مدخلات ونتيجة فورية: A_req = P ÷ σ ثم R = A_req ÷ المسقط — '
     + 'فحص أولي قبل التصميم (والتصميم نفسه بـ ACI 318-19 الفصل 13)',
  desc: 'استغلال الأرض + توصية النوع',
  html: () => (window.FNDPICK ? FNDPICK.html()
    : '<div class="note">وحدة الفحص غير محمَّلة (fndpick.js).</div>'),
  init: () => { if (window.FNDPICK) FNDPICK.init(); }
};

/* ---------- طبقة الفهم: المختبر الفيزيائي وخريطة المنصة والقاموس (وحدات مستقلة) ---------- */
PAGES.phys = {
  ic: '🔬', name: 'المختبر الفيزيائي', ttl: 'المختبر الفيزيائي والميكانيكي التفاعلي',
  sub: 'شوف الفيزياء خلف كل حساب: جسر · عمود · مقطع · زلزال · مسار الحمل · درج — بطبقات تُفعَّل فوق بعضها',
  desc: 'محاكاة تفاعلية بالرسم الحي — عناصر محدّدة، أنماط ذاتية، نيومارك، بوسينسك',
  html: () => (window.PHYSLAB ? PHYSLAB.html() : '<div class="card">وحدة المختبر غير محمَّلة (physlab.js).</div>'),
  init: () => { if (window.PHYSLAB) PHYSLAB.init(); }
};
PAGES.rebar = {
  ic: '🧵', name: 'حديد التسليح', ttl: 'مركز حديد التسليح — ACI 318-19',
  sub: 'طول التماسك · العكفات · الوصلات · ترتيب الأسياخ · التطويق · القطع — مختبرات تفاعلية بطبقات، والقواعد نفسها المستعملة بدليل كل عنصر بالمعالج',
  desc: 'كل تفاصيل الحديد بالمختبر: ld و ldh والوصلات والعكفات والتطويق والقطع',
  html: () => (window.REBARPOSTER && window.REBAR ? REBARPOSTER.card() : '') +
    (window.PHYSLAB ? PHYSLAB.html({ key: 'rebar', cats: ['rebar'] }) : '<div class="card">وحدة المختبر غير محمَّلة.</div>'),
  init: () => { if (window.REBARPOSTER) REBARPOSTER.init(); if (window.PHYSLAB) PHYSLAB.init(); }
};
PAGES.ai = {
  ic: '🤖', name: 'المساعد الذكي', ttl: 'المساعد الهندسي الذكي — مخصّص لمشروعك',
  sub: 'اسأل مباشرة · يجاوب عن المنصة ومشروعك وACI 318-19 والكود العراقي فقط · الأرقام من حاسبات المنصة نفسها',
  desc: 'اسأل عن مشروعك وأي بند بالكود — بأرقام دقيقة من محرّك المنصة',
  html: () => (window.AIASK ? AIASK.pageHtml() : '<div class="card">وحدة المساعد غير محمَّلة.</div>'),
  init: () => { if (window.AIASK) AIASK.pageInit(); }
};
PAGES.mega = {
  ic: '🏙️', name: 'المشاريع الكبيرة', ttl: 'المشاريع الكبيرة في الهندسة — شوف وافهم',
  sub: 'مجسمات تعليمية للعرض فقط: دوّر، اضغط أي عنصر، واعرف ليش هو هنا وشلون ينتقل الحمل — بأرقام منشورة ومصادرها',
  desc: 'برج خليفة ومركز حيدر علييف: النظام الإنشائي ومسار الحمل',
  html: () => (window.MEGA ? MEGA.pageHtml() : '<div class="card">وحدة المشاريع الكبيرة غير محمَّلة.</div>'),
  init: () => { if (window.MEGA) MEGA.init(); }
};
PAGES.map = {
  ic: '🗺️', name: 'خريطة المنصة', ttl: 'خريطة المنصة — طبقات العمل الهندسي',
  sub: 'من المدخلات إلى القراءة والتحليل والتصميم والمخرجات — اضغط أي قسم لتتبّع مساره',
  desc: 'كيف ترتبط أقسام المنصة ببعض',
  html: () => (window.LAYERS ? LAYERS.mapHtml() : ''), init: () => { if (window.LAYERS) LAYERS.mapInit(); }
};
PAGES.terms = {
  ic: '📖', name: 'القاموس الهندسي', ttl: 'القاموس الهندسي — الرموز والمصطلحات',
  sub: 'كل رمز بالعربي والإنكليزي مع تعريفه وبند الكود ومختبر يوضّحه',
  desc: 'Mu، φ، εt، Pcr، T₁… بمعنى واضح',
  html: () => (window.LAYERS ? LAYERS.termsHtml() : ''), init: () => { if (window.LAYERS) LAYERS.termsInit(); }
};

const ORDER = [
  ['المشروع', ['wizard', 'femproj', 'cad', 'room', 'bbs', 'detail66', 'projects']],
  ['التحليل الإنشائي', ['fem']],
  ['الفهم والتعلّم', ['ai', 'mega', 'phys', 'rebar', 'map', 'terms']],
  ['ما تحت الصفر', ['survey', 'earth', 'soil', 'fndpick']],
  ['حاسبات منفردة', ['loads', 'seismic', 'wind', 'beam', 'column', 'footing']],
  ['مرجع', ['ref', 'home']],
];
PAGES.home.name = 'عن المنصة';
PAGES.home.ttl = 'عن المنصة';

(async function boot() {
  try { META = await (await fetch('/api/meta')).json(); } catch (e) { console.error(e); }
  $('#nav').innerHTML = ORDER.map(([g, ids]) => `<div class="grp">${g}</div>` + ids.filter(k => PAGES[k])
    .map(k => `<button data-id="${k}" onclick="go('${k}')" title="${PAGES[k].desc || ''}">
      <span class="ic">${PAGES[k].ic}</span>${PAGES[k].name}</button>`).join('')).join('');
  const want = (location.hash || '#wizard').slice(1);
  go(want in PAGES ? want : 'wizard');
  window.addEventListener('hashchange', () => {          // دعم زر الرجوع وتغيير العنوان
    const id = (location.hash || '#wizard').slice(1);
    const btn = $('#nav button[data-id="' + id + '"]');
    if (id in PAGES && (!btn || !btn.classList.contains('on'))) go(id);
  });
})();

/* ------------------------------ تصميم غرفة ------------------------------- */
let RMD = null;
PAGES.room = {
  ic: '🚪', name: 'تصميم غرفة', grp: 'المشروع', ttl: 'تصميم غرفة — معماري وإنشائي',
  sub: 'الجدران والفتحات وأحمالها + البلاطة والجسور والأعمدة والأسس + مجسم وتسليح',
  desc: 'غرفة واحدة بجدرانها وفتحاتها',
  html: () => `<div class="grid g2">
    <div class="card"><h3>أبعاد الغرفة والمواد</h3><div class="f">
      ${F('الطول', 'rm_L', 5.0, .1, 'م')}${F('العرض', 'rm_W', 4.0, .1, 'م')}
      ${F('ارتفاع الطابق', 'rm_h', 3.2, .1, 'م')}
      ${S('نوع الجدار', 'rm_wall', (META.walls || []).map(w => [w.name, w.name]), 'طابوق 240 مم')}
      ${S('الاستعمال', 'rm_use', META.live.map(x => x.name), 'سكني / غرف نوم')}
      ${F("f'c", 'rm_fc', 25, 1, 'MPa')}${F('fy', 'rm_fy', 420, 10, 'MPa')}
      ${F('تحمّل التربة qa', 'rm_qa', 150, 5, 'kPa')}
      ${F('طوابق فوق العمود', 'rm_fl', 1, 1)}</div></div>
    <div class="card"><h3>الفتحات</h3><div class="f">
      ${F('عدد الأبواب', 'rm_dn', 1, 1)}${F('عرض الباب', 'rm_dw', 1.0, .1, 'م')}
      ${F('ارتفاع الباب', 'rm_dh', 2.1, .1, 'م')}
      ${F('عدد الشبابيك', 'rm_wn', 2, 1)}${F('عرض الشباك', 'rm_ww', 1.5, .1, 'م')}
      ${F('ارتفاع الشباك', 'rm_wh', 1.2, .1, 'م')}${F('منسوب الجلسة', 'rm_ws', 0.9, .1, 'م')}</div>
      <div class="row"><button class="btn" onclick="PAGES.room.run()">🚪 صمّم الغرفة</button>
        <button class="btn gh" onclick="window.print()">🖨️ تقرير</button></div></div></div>
    <div id="rm_out" style="margin-top:16px"></div>`,
  run: async () => {
    const r = await post('room', { L: val('rm_L'), W: val('rm_W'), h: val('rm_h'), wall: txt('rm_wall'),
      use: txt('rm_use'), fc: val('rm_fc'), fy: val('rm_fy'), qa: val('rm_qa'), floors: val('rm_fl'),
      doors: [{ w: val('rm_dw'), h: val('rm_dh'), n: val('rm_dn') }],
      windows: [{ w: val('rm_ww'), h: val('rm_wh'), n: val('rm_wn'), sill: val('rm_ws') }] });
    RMD = r;
    const s = r.slab;
    $('#rm_out').innerHTML = `<div class="grid g4">
      ${kpi('نوع البلاطة', s.two_way ? 'ثنائية الاتجاه' : 'أحادية الاتجاه', 'ok')}
      ${kpi('السماكة', int(s.h) + ' مم')}${kpi('نسبة البحور', nf(s.ratio, 2))}
      ${kpi('wu', nf(s.wu, 2) + ' kN/m²')}
      ${kpi('العمود', r.col.b + '×' + r.col.h + ' مم')}${kpi('تسليح العمود', r.col.rebar.label)}
      ${kpi('الأساس', nf(r.foot.B, 2) + '×' + nf(r.foot.B, 2) + ' م')}
      ${kpi('حديد تقريبي', nf(r.quantities[7].q, 2) + ' طن')}</div>

    <div class="card" style="margin-top:16px"><h3>🩻 مجسم الغرفة — جدران وفتحات وتسليح</h3>
      <div class="v3bar">
          <button onclick="V3&&V3.reset()">إعادة الزاوية</button>
          <button onclick="V3&&V3.top()">مسقط علوي</button>
          <button id="btnRebar" onclick="toggleRebar()">🧵 إظهار التسليح</button>
          <button id="btnXray" onclick="toggleXray()">🩻 وضع الأشعة</button>
          <button onclick="V3&&V3.zoomSel()">🔍 تقريب المحدد</button>
          <button onclick="V3SET&&V3SET.toggle('#rm3d')">⚙️ العرض والأداء</button>
      </div>
      <div class="v3d"><div id="rm3d" style="min-height:430px"></div>
        <div class="chips" id="v3groups">
          ${[['walls', 'جدران', 1], ['slabs', 'سقف', 1], ['beams', 'جسور', 1],
             ['columns', 'أعمدة', 1], ['isolated', 'أسس', 1], ['chairs', 'كراسي', 1]].map(([k, t, o]) =>
            `<label><input type="checkbox" data-g="${k}" ${o ? 'checked' : ''}
              onchange="V3&&V3.group('${k}',this.checked);refreshStats()"> ${t}</label>`).join('')}
        </div>
        <div class="row" id="siteBar" hidden style="gap:10px;align-items:stretch;
          margin-top:8px;padding:9px 11px;background:var(--bg2);border-radius:10px"></div>
        <div class="info" id="v3info"></div>
        <div class="slider"><span style="font-size:11px;color:var(--mut)">قص المقطع</span>
          <input type="range" id="v3clip" min="-20" max="20" step="0.1">
          <span id="v3stats" style="font-size:11px;color:var(--acc2)"></span></div>
      </div>
      <div class="hint">ضغطة = اختيار · ضغطتان = تقريب · «إظهار التسليح» يبيّن حديد البلاطة والجسور
        والأعمدة والأسس مع الكراسي والوصلات.</div></div>

    <div class="grid g2" style="margin-top:16px">
      <div class="card"><h3>البلاطة</h3>${table(['البند', 'القيمة'], [
        ['الطريقة', s.method], ['السماكة', int(s.h) + ' مم'],
        ['العزم بالاتجاه القصير', nf(s.short.M, 1) + ' kN·m/م'],
        ['العزم بالاتجاه الطويل', nf(s.long.M, 1) + ' kN·m/م'],
        ['تسليح سفلي (قصير)', s.short.label], ['تسليح سفلي (طويل)', s.long.label],
        ['تسليح علوي فوق الجسور', s.top.label],
        ['الكراسي', r.chairs.label + ' — ' + int(r.chairs.n) + ' كرسي'],
        ['البسكويت', int(r.chairs.spacers) + ' قطعة']])}</div>
      <div class="card"><h3>الجدران والفتحات</h3>${table(['الجدار', 'الطول', 'الفتحات', 'المساحة الصافية', 'الحمل (kN/م)', 'الطابوق'],
        r.walls.map(w => [w.i, nf(w.L, 2) + ' م',
          w.openings.map(o => o.kind + ' ' + nf(o.w, 2) + '×' + nf(o.h, 2)).join(' · ') || '—',
          nf(w.area_net, 1) + ' م²', nf(w.udl, 2), int(w.blocks)]))}
        <div class="note">نوع الجدار: ${r.wall_type.name} · كثافة ${nf(r.wall_type.gamma, 0)} kN/m³ ·
          ${nf(r.wall_type.blocks_m2, 0)} قطعة/م² · اللبخ محسوب على الوجهين.</div></div>
      <div class="card"><h3>الجسور الأربعة</h3>${table(['الجسر', 'البحر', 'المقطع', 'نوع الحمل', 'Mu', 'سفلي', 'أساور', 'هطول/الحد'],
        r.beams.map(b => [b.i, nf(b.span, 2) + ' م', int(b.b) + '×' + int(b.h),
          b.share, nf(b.Mu, 1), b.bottom.label, b.stirrup.label,
          nf(Math.abs(b.defl), 1) + '/' + nf(b.defl_lim, 1)]))}</div>
      <div class="card"><h3>الأعمدة والأسس والكميات</h3>${table(['البند', 'القيمة'], [
        ['حمل العمود Pu', nf(r.col.Pu, 0) + ' kN'], ['المقطع', r.col.b + '×' + r.col.h + ' مم'],
        ['التسليح', r.col.rebar.label + ' (ρ=' + nf(r.col.rebar.rho * 100, 2) + '%)'],
        ['الأتاري', r.col.rebar.tie_label], ['الأساس', nf(r.foot.B, 2) + '×' + nf(r.foot.B, 2) + ' م سماكة ' + int(r.foot.h) + ' مم'],
        ['تسليح الأساس', r.foot.bars_label]].concat(
        r.quantities.map(q => [q.name, nf(q.q, q.unit === 'قطعة' ? 0 : 2) + ' ' + q.unit])))}</div></div>`;
    setTimeout(() => mount3D(r, 'rm3d'), 60);
  },
  init: () => PAGES.room.run()
};

/* --------------------------- جدول تقطيع الحديد --------------------------- */
PAGES.bbs = {
  ic: '📊', name: 'جدول تقطيع الحديد', grp: 'المشروع', ttl: 'جدول تقطيع الحديد (BBS)',
  sub: 'الأطوال بعد التقطيع على أسياخ 12 م · الوصلات والهدر · الأوزان لكل قطر',
  desc: 'BBS كامل مع الوصلات والهدر',
  html: () => `<div class="card"><h3>المصدر</h3>
    <div class="hint">يُبنى من آخر تشغيل لمعالج المشروع — غيّر المعطيات من صفحة المعالج ثم ارجع هنا.</div>
    <div class="row"><button class="btn" onclick="PAGES.bbs.run()">🔄 تحديث الجدول</button>
      <button class="btn gh" onclick="PAGES.bbs.csv()">⬇️ تنزيل CSV</button>
      <button class="btn gh" onclick="window.print()">🖨️ طباعة</button>
      <button class="btn gh" onclick="go('wizard')">↩︎ المعالج</button></div></div>
    <div id="bb_out" style="margin-top:16px"></div>`,
  payload: () => (WZ ? WZ : (document.getElementById('w_area')
    ? PAGES.wizard.payload()
    : { area: 200, floors: 2, soil: 'طين قاسي', fc: 25, fy: 420 })),
  run: async () => {
    const r = await post('bbs', PAGES.bbs.payload());
    $('#bb_out').innerHTML = `<div class="grid g4">
      ${kpi('الوزن الكلي', nf(r.total_ton, 2) + ' طن', 'ok')}
      ${kpi('عدد القطع', int(r.bars))}${kpi('هدر الوصلات', int(r.lap_weight) + ' كغم')}
      ${kpi('نسبة الهدر', nf(r.lap_pct, 1) + '%')}</div>
    <div class="card" style="margin-top:16px"><h3>الملخص حسب القطر</h3>
      ${table(['القطر', 'الطول الكلي (م)', 'الوزن (كغم)', 'الوزن (طن)', 'عدد الوصلات'],
        r.by_db.map(b => ['Ø' + b.db, int(b.length), int(b.weight), nf(b.weight / 1000, 2), int(b.laps)]))}</div>
    <div class="card" style="margin-top:16px"><h3>الجدول التفصيلي</h3>
      ${table(['الرمز', 'العنصر', 'القطر', 'الشكل', 'طول السيخ (م)', 'قطع', 'طول القطعة (م)',
        'العدد', 'وصلات', 'الطول الكلي (م)', 'الوزن (كغم)', 'ملاحظات'],
        r.rows.map(x => [x.mark, x.elem, 'Ø' + x.db, x.shape, nf(x.run, 2), x.pieces, nf(x.piece, 2),
          int(x.count), int(x.laps), int(x.total_len), int(x.weight), x.note || '—']))}
      <div class="note">${r.note}</div></div>`;
  },
  csv: async () => {
    const res = await fetch('/api/bbs/csv', { method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(PAGES.bbs.payload()) });
    const b = await res.blob(), a = document.createElement('a');
    a.href = URL.createObjectURL(b); a.download = 'bar-bending-schedule.csv'; a.click();
  },
  init: () => PAGES.bbs.run()
};

/* ==========================================================================
   صفحة التفصيل حسب ACI Detailing Manual MNL-66(20)
   --------------------------------------------------------------------------
   صفحة **مستقلّة** لا تمسّ المعالج ولا لوحته ثلاثية الأبعاد بشيء: تقرأ ناتج
   المعالج نفسه وتعيد تقديمه بلغة **التفصيل** لا بلغة التصميم — رقم نوع الثني،
   وأبعاده بالحروف، والطول من الطرف للطرف، وطول القطع بعد خصم الثنيات، وقوائم
   فحص أشكال الدليل. وعارض المجسّم هنا عارضٌ ثانٍ خاصّ بها (`bar3d.js`).
   ========================================================================== */
let M66 = null, B3D = null, M66SEL = 0;

PAGES.detail66 = {
  ic: '📐', name: 'تفصيل الحديد MNL-66', grp: 'المشروع',
  ttl: 'تفصيل حديد التسليح — ACI Detailing Manual MNL-66(20)',
  sub: 'نوع الثني وأبعاده بالحروف · الطول من الطرف للطرف · طول القطع بعد خصم الثنيات · قوائم أشكال الدليل',
  desc: 'طبقة التفصيل: ما يُرسَم ويُطلَب، لا ما يُحسَب',
  html: () => `<div class="card">
    <h3>المرجعان معاً — لا بديلاً عن الآخر</h3>
    <div class="grid g2">
      <div class="note" style="border-right:3px solid var(--acc2)"><b>ACI 318-19</b> يقول
        <b>كم</b> حديداً يلزم: المساحة والقطر والتباعد وطول النشر. وهو مطبَّق كما هو
        بصفحة المعالج وتقرير المطابقة — <b>لم يتغيّر منه شيء</b>.</div>
      <div class="note" style="border-right:3px solid #facc15"><b>MNL-66(20)</b> يقول
        <b>كيف</b> يُفصَّل ويُطلَب ويُرسَم: رقم نوع الثني وأبعاده بالحروف، والطول من
        الطرف للطرف، وطول القطع بعد خصم الثنيات، وما يجب أن يظهر بالمخطط ليقرأه
        الحدّاد بلا سؤال.</div></div>
    <div class="row"><button class="btn" onclick="PAGES.detail66.run()">🔄 تحديث من المعالج</button>
      <button class="btn gh" onclick="go('wizard')">↩︎ المعالج</button>
      <button class="btn gh" onclick="go('bbs')">📊 جدول التقطيع</button>
      <button class="btn gh" onclick="window.print()">🖨️ طباعة</button></div></div>
    <div id="m66" style="margin-top:16px"><div class="hint">…يُحسب</div></div>`,
  payload: () => (WZ ? WZ : (document.getElementById('w_area')
    ? PAGES.wizard.payload()
    : { area: 200, floors: 2, soil: 'طين قاسي', fc: 25, fy: 420 })),
  run: async () => {
    M66 = await post('mnl66', PAGES.detail66.payload());
    m66Render();
  },
  init: () => PAGES.detail66.run()
};

function m66Render() {
  const r = M66; if (!r) return;
  const B = r.bars, C = r.checks;
  const st = s => s === 'ok' ? '<span class="tag t-ok">مطابق</span>'
    : s === 'fail' ? '<span class="tag t-bad">مخالف</span>'
      : '<span class="tag t-warn">للمراجعة</span>';
  $('#m66').innerHTML = `
  <div class="grid g4">
    ${kpi('عائلات الحديد', B.rows.length)}
    ${kpi('الوزن الكلي', nf(B.total_t, 2) + ' طن')}
    ${kpi('بنود التفصيل', C.total)}
    ${kpi('مخالف', C.counts.fail || 0, (C.counts.fail || 0) ? 'bad' : 'ok')}
    ${kpi('تصنيع خاصّ', B.special.length ? B.special.join(' · ') : 'لا شيء',
      B.special.length ? 'warn' : 'ok')}</div>

  <div class="card" style="margin-top:16px"><h3>١ · جدول التفصيل — كل سيخ بأبعاده بالحروف</h3>
    <div style="max-height:520px;overflow:auto">${table(
      ['الرمز', 'العنصر', 'Ø', 'نوع الثني', 'الأبعاد من الطرف للطرف (مم)', 'ثنيات',
       'الطول المفصَّل (م)', 'خصم الثنيات (مم)', 'طول القطع (م)', 'العدد', 'الوزن (كغم)', ''],
      B.rows.map((b, i) => [
        `<b>${b.mark}</b>`, b.elem, 'Ø' + b.db,
        b.type_no ? `<b>${b.type_name}</b>` : 'مستقيم',
        b.dims.map(d => `<b>${d.k}</b>=${d.mm}`).join(' + '),
        b.bends, nf(b.detailed, 3), int(b.deduct), `<b>${nf(b.cut, 3)}</b>`,
        int(b.count), int(b.total_kg),
        `<button class="btn gh" style="padding:3px 9px;font-size:11px"
           onclick="m66Pick(${i})">عرض</button>`]))}</div>
    <div class="note">${B.note}</div>
    <div class="note" style="border-right:3px solid #facc15">${B.scope}
      <button class="btn gh" style="margin-right:8px;padding:3px 9px;font-size:11px"
        onclick="go('bbs')">افتح جدول التقطيع</button></div></div>

  <div class="card" style="margin-top:16px"><h3>٢ · شكل السيخ المحدَّد بأبعاده</h3>
    <div class="row" style="flex-wrap:wrap;gap:6px;margin-bottom:8px">${B.rows.map((b, i) =>
      `<button class="btn ${i === M66SEL ? '' : 'gh'}" style="padding:4px 10px;font-size:11.5px"
        onclick="m66Pick(${i})">${b.mark}</button>`).join('')}</div>
    <div id="m66d" style="height:320px;background:var(--bg2);border-radius:12px"></div>
    <div id="m66i" class="note"></div></div>

  <div class="card" style="margin-top:16px"><h3>٣ · أنواع الثني وأبعادها بالحروف</h3>
    ${table(['النوع', 'الأبعاد', 'ثنيات', 'مستويات', 'ما هو', 'أين يُستعمل'],
      r.types.map(t => [t.no ? `<b>النوع ${t.no}</b>` : 'مستقيم',
        t.dims.join(' · '), t.bends, t.planes > 1
          ? `<span class="tag t-warn">${t.planes} — تصنيع خاصّ</span>` : t.planes,
        t.what, t.use]))}</div>

  <div class="card" style="margin-top:16px"><h3>٤ · خصم انحناء الثنية — المعادلة مقابل الجدول المرجعي</h3>
    <div class="note">السيخ يُقصّ <b>أقصر</b> من مجموع أبعاده المفصَّلة لأن قوس الثنية
      أقصر من مماسَّيه. والمقدار <b dir="ltr">${r.deduct.formula}</b> — ${r.deduct.note}</div>
    ${table(['Ø', 'قطر الثني (مم)', 'خصم 45° مرجع', 'محسوب', 'الفرق',
      'خصم 90° مرجع', 'محسوب', 'الفرق', ''],
      r.deduct.rows.map(x => ['Ø' + x.db, int(x.dia), int(x.ref45), nf(x.calc45, 1), nf(x.d45, 1),
        int(x.ref90), nf(x.calc90, 1), nf(x.d90, 1), st(x.ok ? 'ok' : 'fail')]))}
    <div class="note">الفروق ضمن تقريب الجدول المرجعي نفسه (يُقرَّب لأقرب ربع إنش).</div></div>

  <div class="card" style="margin-top:16px"><h3>٥ · قواعد التفصيل المطبَّقة</h3>
    ${table(['المادة', 'القاعدة', 'ماذا تعني عملياً'],
      r.rules.map(x => [x.c, `<b>${x.t}</b>`, x.w.replace(/\*\*(.+?)\*\*/g, '<b>$1</b>')]))}</div>

  ${C.sections.map(s => `<div class="card" style="margin-top:16px">
    <h3>${s.name} — الشكل <span style="color:var(--acc2)">${s.fig}</span></h3>
    ${table(['البند', 'الفحص', 'المحسوب', 'المطلوب', 'الحالة', 'لماذا'],
      s.rows.map(x => [x.clause, x.title, x.value, x.need, st(x.state),
        (x.why || '').replace(/\*\*(.+?)\*\*/g, '<b>$1</b>') || '—']))}</div>`).join('')}

  <div class="note" style="margin-top:14px">${C.ref}</div>`;
  m66Pick(Math.min(M66SEL, B.rows.length - 1));
}

function m66Pick(i) {
  if (!M66) return;
  M66SEL = i;
  const b = M66.bars.rows[i]; if (!b) return;
  const host = $('#m66d');
  if (host && window.BAR3D) {
    // إعادة رسم الصفحة تُتلف العنصر القديم، فيُتخلَّص من عارضه ولا يُترك
    // يدور بالخلفية — وإلا تراكمت عارضات WebGL بكل تحديث.
    if (!B3D || B3D.host !== host) {
      if (B3D) B3D.dispose();
      B3D = window.BAR3D.make(host);
      if (B3D) B3D.host = host;
    }
    if (B3D) B3D.show(b);
  }
  const inf = $('#m66i');
  if (inf) inf.innerHTML = `<b>${b.mark}</b> — ${b.elem} · Ø${b.db} ·
    ${b.type_no ? 'نوع الثني <b>' + b.type_name + '</b>' : 'مستقيم بلا ثنيات'} ·
    ${b.bends} ثنية بقطر ثني <b>${int(b.bend_dia)} مم</b><br>
    الأبعاد: ${b.dims.map(d => `<b>${d.k}</b> = ${d.mm} مم`).join(' · ')}<br>
    الطول المفصَّل <b>${nf(b.detailed, 3)} م</b> ناقص خصم الثنيات <b>${int(b.deduct)} مم</b>
    = طول القطع <b>${nf(b.cut, 3)} م</b> (سماحية ±${int(b.tol)} مم)<br>
    ${b.why ? '<span style="color:var(--mut)">' + b.why.replace(/\*\*(.+?)\*\*/g, '<b>$1</b>') + '</span>' : ''}
    ${b.note ? '<br><span class="tag t-warn">' + b.note + '</span>' : ''}`;
}
